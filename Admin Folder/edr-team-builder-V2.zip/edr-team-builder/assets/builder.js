/* EDR Team Builder (generated). Front-end logic adapted from EDR-Team-Builder.html. */
(function(){
const LOGO=(window.EDR_TB&&EDR_TB.logo)||'';
const APP_HTML=`
<div class="header">
  <img src="${LOGO}" alt="Endurotech Racing">
  <div>
    <div class="head" style="letter-spacing:.18em;font-size:11px;color:var(--yellow);text-transform:uppercase">Endurotech Racing</div>
    <h1 style="font-size:26px;margin:2px 0;letter-spacing:.04em;text-transform:uppercase;color:#fff">Endurance Team Builder</h1>
    <div id="evheading" style="margin-top:2px"></div>
    <div class="meta" id="summary" style="display:flex;gap:16px;flex-wrap:wrap;margin-top:4px"></div>
  </div>
  <div id="rolebar" style="margin-left:auto;display:flex;gap:10px;align-items:center"></div>
</div>
<div class="controls">
  <div class="ctl"><label>PACE weight <b id="lpace" style="color:var(--amber)"></b></label><input type="range" id="pace" min="0" max="100" style="accent-color:var(--amber)"></div>
  <div class="ctl"><label>CLEAN weight <b id="lclean" style="color:var(--steel)"></b></label><input type="range" id="clean" min="0" max="100" style="accent-color:var(--steel)"></div>
  <div class="ctl"><label>PREP weight <b id="lprep" style="color:var(--green)"></b></label><input type="range" id="prep" min="0" max="100" style="accent-color:var(--green)"></div>
  <div class="ctl" style="flex:1 1 160px"><label>PRO = top <b id="lpro" style="color:var(--gold)"></b>% of each class</label><input type="range" id="propct" min="0" max="100" step="5" style="accent-color:var(--gold)"></div>
  <button class="btn btn-amber" id="gen">Generate</button>
  <button class="btn btn-ghost" id="imp">Import JSON</button>
  <button class="btn btn-ghost" id="reset">Reset</button>
  <span class="status" id="status"></span>
</div>
<div class="tabs">
  <button class="tab active" data-tab="setup">Setup</button>
  <button class="tab" data-tab="instructions">Instructions</button>
  <button class="tab" data-tab="event">Event</button>
  <button class="tab" data-tab="availability">Availability</button>
  <button class="tab" data-tab="drivers">Drivers</button>
  <button class="tab" data-tab="teams">Teams</button>
  <button class="tab" data-tab="stints">Stints</button>
  <button class="tab" data-tab="weekly">Weekly</button>
</div>
<div class="wrap"><div class="importbox hide" id="importbox">
  <div class="meta" style="margin-bottom:8px">Paste a roster JSON (advanced / manual fallback), then Load.</div>
  <textarea id="importtext" placeholder='[{"name":"...","cars":{"Ferrari 296 GT3":{"laps":168,"medianLap":105.21,"cleanPct":0.91}}}]'></textarea>
  <button class="btn btn-green" id="load" style="margin-top:8px">Load</button>
</div><div id="content"></div></div>
`;
const _app=document.getElementById('edr-tb-app'); if(!_app){return;} _app.innerHTML=APP_HTML;

const KEY = 'edrTeamBuilder_spa_v15'; /* Spa 24h — S3 pace, survey 2307 availability; v15 = 2-hour blocks */

// --- Spa 24h event timing (for the Stints tab) ---
// Availability window starts 2026-07-10 22:00 UTC (= 11 Jul 08:00 Brisbane). All offsets in minutes from there.
// 4 candidate start slots (iRacePlan survey 2307 session_times).
let WIN_START_MS = Date.parse('2026-07-10T22:00:00Z');
let START_OFFSETS = {1:0, 2:540, 3:840, 4:1080};
let START_LABELS = {1:'Sat 08:00 · 22:00Z', 2:'Sat 17:00 · 07:00Z', 3:'Sat 22:00 · 12:00Z', 4:'Sun 02:00 · 16:00Z'};

// Spa 24h: Garage 61 pace (iRacing 2026 Season 3 only, from 2026-06-16; age=-1) for the 18 drivers in iRacePlan survey 2307.
// Availability merged from iRacePlan survey 2307 timeline (green = available). Empty cars = no Spa data shared.
const SAMPLE = [];

let state = { drivers:[], w:{pace:50,clean:30,prep:20}, proPct:40, tab:'event', teams:{}, stint:{window:1,len:60,race:1440}, stintAssign:{}, stintWin:{}, stintSig:'', evsel:null, role:'driver', me:'', pass:'', availStore:{}, evWinMin:0, evTiming:{}, teamsLocked:false, stintsLocked:false, teamNames:{}, fuelCfg:{pitLossSec:60,byCar:{},byClass:{}}, customEvents:[], irEvents:[], evWeather:{}, prefStore:{}, swapNote:'' };
/* Per-user timezone (F10) is device-local, never in the shared plan. Auto-detect, override persisted in edrTB_tz. */
let TZ = 'auto';   // default: auto-detect the viewer's zone; picker override persists per device
try{ TZ = localStorage.getItem('edrTB_tz') || 'auto'; }catch(e){}
const TZ_ZONES = [['auto','Auto (detected)'],['Australia/Brisbane','Brisbane'],['Europe/London','London'],['Europe/Berlin','Berlin / Amsterdam'],['Europe/Helsinki','Helsinki'],['America/New_York','US East'],['America/Los_Angeles','US West'],['UTC','UTC']];
function tzZone(){ if(TZ==='auto'){ try{ return Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC'; }catch(e){ return 'UTC'; } } return TZ||'Australia/Brisbane'; }
function tzLabel(){ const m=TZ_ZONES.find(x=>x[0]===TZ); if(m&&m[0]!=='auto')return m[1]; const z=tzZone(); return (z.split('/').pop()||z).replace(/_/g,' ')+' (auto)'; }
function setTZ(z){ TZ=z; try{ localStorage.setItem('edrTB_tz', z); }catch(e){} if(typeof START_OFFSETS!=='undefined') relabelStarts(); }
function relabelStarts(){ try{ if(typeof START_OFFSETS==='undefined') return; Object.keys(START_OFFSETS).forEach(w=>{ START_LABELS[w]=fmtClock(START_OFFSETS[w]); }); }catch(e){} }

function fastestCar(cars){
  let best=null, bt=Infinity;
  Object.keys(cars||{}).forEach(c=>{ const m=cars[c]&&cars[c].medianLap; if(m!=null&&m<bt){ bt=m; best=c; } });
  return best||Object.keys(cars||{})[0];
}
function lastCar(cars){   // most recently driven car (lastDriven ISO from the G61 import); falls back to fastest
  let best=null, bt='';
  Object.keys(cars||{}).forEach(c=>{ const t=cars[c]&&cars[c].lastDriven; if(t && t>bt){ bt=t; best=c; } });
  return best || fastestCar(cars);
}
function seed(list){
  let id=1;
  state.drivers = list.map(d => ({ id:id++, name:d.name, cars:d.cars||{}, assignedCar:lastCar(d.cars), avail:d.avail||null }));
  seedSpaAvail();
}

function save(){ try{ localStorage.setItem(KEY, JSON.stringify({drivers:state.drivers,w:state.w,proPct:state.proPct,teams:state.teams,stint:state.stint,stintAssign:state.stintAssign,stintWin:state.stintWin,stintSig:state.stintSig,evsel:state.evsel,role:state.role,me:state.me,pass:state.pass,availStore:state.availStore,evTiming:state.evTiming,teamsLocked:state.teamsLocked,stintsLocked:state.stintsLocked,teamNames:state.teamNames,fuelCfg:state.fuelCfg,customEvents:state.customEvents,irEvents:state.irEvents,evWeather:state.evWeather,prefStore:state.prefStore,swapNote:state.swapNote,evWinMin:EV_WIN_MIN,winStart:WIN_START_MS,startOffsets:START_OFFSETS,startLabels:START_LABELS})); }catch(e){} }
function load(){
  try{
    const s = JSON.parse(localStorage.getItem(KEY));
    if(s && s.drivers && s.drivers.length){
      state.drivers=s.drivers; state.w=s.w||state.w; state.proPct=(typeof s.proPct==='number')?s.proPct:state.proPct; state.teams=s.teams||{}; state.stint=Object.assign(state.stint, s.stint||{}); state.stintAssign=s.stintAssign||{}; state.stintWin=s.stintWin||{}; state.stintSig=s.stintSig||'';
      state.evsel=s.evsel||null; state.role=s.role||'driver'; state.me=s.me||''; state.pass=s.pass||''; state.availStore=s.availStore||{}; state.evTiming=s.evTiming||{}; state.teamsLocked=!!s.teamsLocked; state.stintsLocked=!!s.stintsLocked;
      state.teamNames=s.teamNames||{}; state.fuelCfg=s.fuelCfg||state.fuelCfg; state.customEvents=s.customEvents||[]; state.irEvents=s.irEvents||[]; state.evWeather=s.evWeather||{}; state.prefStore=s.prefStore||{}; state.swapNote=s.swapNote||'';
      if(s.evWinMin) EV_WIN_MIN=s.evWinMin;
      if(s.winStart) WIN_START_MS=s.winStart;
      if(s.startOffsets&&Object.keys(s.startOffsets).length){ START_OFFSETS=s.startOffsets; START_LABELS=s.startLabels||START_LABELS; }
      /* migrate pre-2.1 saves: no event selected + availability living only on the driver
         objects (survey windows). Default to Spa and fold the windows into the per-event
         store so the pool/stints keep working without re-ticking anything. */
      if(!state.evsel) state.evsel='Spa 24HR|2026-07-10';
      const st=state.availStore[state.evsel]=state.availStore[state.evsel]||{};
      state.drivers.forEach(d=>{ if(d.avail&&d.avail.windows&&d.avail.windows.length&&!(st[d.name]&&st[d.name].length)) st[d.name]=windowsToSlots(d.avail.windows); });
      return true;
    }
  }catch(e){}
  return false;
}

function classOf(name){
  const n=(name||'').toUpperCase();
  if(n.includes('GTP')||n.includes('HYBRID')||n.includes('LMDH'))return 'GTP';
  if(n.includes('LMP2')||n.includes('P217')||n.includes('LMP'))return 'LMP2';
  if(/(911|992|PORSCHE)[^A-Z]*CUP|CUP[^A-Z]*\(?99/.test(n))return 'Porsche Cup';
  if(n.includes('TCR'))return 'TCR';
  if(n.includes('BMW M2'))return 'M2';
  if(n.includes('GT4'))return 'GT4';
  if(n.includes('GT3'))return 'GT3';
  return 'Other';
}
/* Classes an event runs, parsed from its cars string ("GTP & HYP // LMP2 // GT3"). Canonical
   labels double as the team/model class keys, so a declared class groups correctly. */
function evClasses(ev){
  const raw=(ev&&ev.cars)||''; if(!raw||/TBD/i.test(raw)) return [];
  const out=[]; raw.split('//').forEach(seg=>{
    const t=seg.trim(); if(!t) return; const u=t.toUpperCase(); let c;
    if(u.includes('GTP')||u.includes('HYP'))c='GTP';
    else if(u.includes('LMP2'))c='LMP2';
    else if(u.includes('CUP'))c='Porsche Cup';
    else if(u.includes('TCR'))c='TCR';
    else if(u.includes('M2'))c='M2';
    else if(u.includes('GT4'))c='GT4';
    else if(u.includes('GT3'))c='GT3';
    else c=t;
    if(out.indexOf(c)<0) out.push(c);
  });
  return out;
}
function fmtLap(s){ if(s==null)return '—'; const m=Math.floor(s/60); const sec=(s%60).toFixed(3); return m+':'+String(sec).padStart(6,'0'); }

/* with an event selected, the pool is drivers with availability for THAT event
   (hours > 0) — same rule as the old survey flow. No event = everyone. */
function eventPool(){
  if(!state.evsel) return state.drivers;
  return state.drivers.filter(d=>d.avail && d.avail.hours>0);
}
function computeModel(){
  const enriched = eventPool().map(d=>{
    const car = (d.cars && d.cars[d.assignedCar]) ? d.assignedCar : ((d.carLock && d.assignedCar) ? d.assignedCar : lastCar(d.cars));   // a hand-picked (locked) car sticks; otherwise default to the car they drove most recently
    const st = (d.cars && d.cars[car]) || {laps:0,medianLap:null,cleanPct:0};
    const _dcls=prefsFor(d.name).cls;
    return Object.assign({}, d, {_car:car,_class:_dcls||classOf(car),_laps:st.laps,_median:st.medianLap,_clean:st.cleanPct});
  });
  const groups={};
  enriched.forEach(d=>{(groups[d._class]=groups[d._class]||[]).push(d);});
  const sum=state.w.pace+state.w.clean+state.w.prep||1;
  const wp=state.w.pace/sum, wc=state.w.clean/sum, wr=state.w.prep/sum;
  Object.values(groups).forEach(grp=>{
    const med=grp.map(d=>d._median).filter(x=>x!=null&&isFinite(x));
    const laps=grp.map(d=>d._laps).filter(x=>isFinite(x)), cl=grp.map(d=>d._clean).filter(x=>isFinite(x));
    const minM=Math.min.apply(null,med), maxM=Math.max.apply(null,med);
    const minL=Math.min.apply(null,laps), maxL=Math.max.apply(null,laps);
    const minC=Math.min.apply(null,cl), maxC=Math.max.apply(null,cl);
    grp.forEach(d=>{
      const md=isFinite(d._median)?d._median:null, lp=isFinite(d._laps)?d._laps:minL, cn=isFinite(d._clean)?d._clean:minC;
      const pace=md==null?0:(maxM===minM?0.5:(maxM-md)/(maxM-minM));
      const prep=(!isFinite(minL)||maxL===minL)?0.5:(lp-minL)/(maxL-minL);
      const clean=(!isFinite(minC)||maxC===minC)?0.5:(cn-minC)/(maxC-minC);
      d._score=wp*pace+wc*clean+wr*prep;
    });
    grp.sort((a,b)=>b._score-a._score);
    const proN=Math.max(0,Math.round((state.proPct/100)*grp.length));
    grp.forEach((d,i)=>{d._tier=i<proN?'pro':'casual'; d._rank=i;});
  });
  return groups;
}

function teamSizes(n){ if(n<=0)return[]; if(n<=3)return[n]; const t=Math.ceil(n/3); const s=Array(t).fill(2); let rem=n-2*t,i=0; while(rem>0){s[i%t]++;rem--;i++;} return s; }
function buildPool(pool){
  if(!pool.length)return[];
  const sizes=teamSizes(pool.length);
  const sorted=pool.slice().sort((a,b)=>b._score-a._score);
  const teams=sizes.map(()=>[]);
  let i=0,round=0;
  while(i<sorted.length){
    let order=teams.map((_,k)=>k); if(round%2===1)order.reverse();
    for(const ti of order){ if(teams[ti].length<sizes[ti]&&i<sorted.length)teams[ti].push(sorted[i++]); }
    round++;
  }
  return teams.map(t=>t.map(d=>d.id));
}
const PRESET_TEAMS = {"GTP":[["Jake Lennox-Bradley","John Nyhouse","Erik van der Bijl"]],"GT3":[["Chris Wilson","Matt Halden","Sam Millar","Tom Williams"],["Thomaz Hernandes","Valentin Ozhiganov","Jarrod Williams"],["Dominic Bou-Samra","Michael Cullen","Sam Mackenzie","Joey Tavora"]]};
function applyPreset(){
  const byName={}; state.drivers.forEach(d=>byName[d.name]=d.id);
  const next={};
  Object.keys(PRESET_TEAMS).forEach(cls=>{ next[cls]={pro:PRESET_TEAMS[cls].map(car=>car.map(n=>byName[n]).filter(x=>x!=null)).filter(c=>c.length),casual:[]}; });
  state.teams=next; state.stintAssign={}; state.stintSig=''; save();
}
function generate(){
  if(state.teamsLocked && Object.keys(state.teams||{}).length) return;   // locked line-up: never overwrite the manual teams
  const model=computeModel(); const next={};
  Object.keys(model).forEach(cls=>{
    const grp=model[cls];
    next[cls]={pro:buildPool(grp.filter(d=>d._tier==='pro')), casual:buildPool(grp.filter(d=>d._tier==='casual'))};
  });
  state.teams=next;
  if(!state.stintsLocked){ state.stintAssign={}; state.stintSig=''; }   // full regenerate invalidates the stint plan (the sig no longer watches teams)
}

function esc(s){ return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }

/* ===== Season calendar =====
   iRacing specials + endurance events (team calendar + iRacePlan surveys). Edit here to
   add or correct events. target = special OR (endurance AND dur>=3h). Optional per-event
   overrides: winStart (ISO — when the availability window opens), winMin (window length,
   minutes), offsets/labels (candidate race starts), raceMin (race length, minutes). */
const CAL_EVENTS=[
  {n:"iRacing ROAR", s:"2026-01-09", e:"2026-01-10", track:"Daytona International Speedway", cars:"LMP3 // GT4 // Touring Cars", cat:"other"},
  {n:"Daytona 24", s:"2026-01-16", e:"2026-01-18", track:"Daytona International Speedway", cars:"GTP & HYP // LMP2 // GT3", cat:"endurance", dur:24, special:true, g61Tracks:[105]},
  {n:"Daytona 500", s:"2026-02-11", e:"2026-02-18", track:"Daytona International Speedway", cars:"NASCAR Cup Series", cat:"nascar", special:true},
  {n:"Bathurst 12 Hour", s:"2026-02-20", e:"2026-02-22", track:"Mount Panorama Circuit", cars:"GT3", cat:"endurance", dur:12, special:true, g61Tracks:[79]},
  {n:"NEC Round 1", s:"2026-03-21", e:"2026-03-22", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"1 / 10", dur:4, g61Tracks:[94]},
  {n:"Sebring 12HR", s:"2026-03-27", e:"2026-03-29", track:"Sebring International Raceway", cars:"GTP & HYP // LMP2 // GT3", cat:"endurance", dur:12, special:true, g61Tracks:[35]},
  {n:"NEC Round 2", s:"2026-04-04", e:"2026-04-05", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"2 / 10", dur:4, g61Tracks:[94]},
  {n:"IMSA Classic 500", s:"2026-04-10", e:"2026-04-11", track:"WeatherTech Raceway Laguna Seca", cars:"Nissan GTP // Audi 90", cat:"endurance", dur:4, g61Tracks:[504, 34]},
  {n:"NEC Round 3", s:"2026-04-25", e:"2026-04-26", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"3 / 10", dur:4, g61Tracks:[94]},
  {n:"Nürburgring 24h", s:"2026-05-01", e:"2026-05-03", track:"Nürburgring Combined", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", dur:24, special:true, g61Tracks:[93]},
  {n:"INDY 500", s:"2026-05-05", e:"2026-05-18", track:"Indianapolis Motor Speedway", cars:"Dallara IR-18 INDYCAR", cat:"other", special:true},
  {n:"World 600", s:"2026-05-20", e:"2026-05-25", track:"Charlotte Motor Speedway", cars:"NASCAR Cup Series", cat:"nascar", special:true},
  {n:"NEC Round 4", s:"2026-05-23", e:"2026-05-24", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"4 / 10", dur:4, g61Tracks:[94]},
  {n:"4 Hours at Thruxton", s:"2026-05-29", e:"2026-05-31", track:"Thruxton Circuit", cars:"Touring Cars", cat:"endurance", dur:4, g61Tracks:[453]},
  {n:"NEC Round 5", s:"2026-06-06", e:"2026-06-07", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"5 / 10", dur:4, g61Tracks:[94]},
  {n:"Creventic Round 1 — 12H Mugello", s:"2026-06-13", e:"2026-06-14", track:"Autodromo Internazionale del Mugello", cars:"GT3 // Cup // GT4", cat:"endurance", series:"Creventic", round:"1 / 5", dur:12, g61Tracks:[418]},
  {n:"Watkins Glen 6 Hour", s:"2026-06-19", e:"2026-06-21", track:"Watkins Glen International", cars:"GTP & HYP // LMP2 // GT3", cat:"endurance", dur:6, special:true, g61Tracks:[324]},
  {n:"Dale Jr Charity Event", s:"2026-06-25", e:"2026-06-25", track:"Iowa Speedway", cars:"TBD", cat:"other", tbd:true},
  {n:"Firecracker 400", s:"2026-06-30", e:"2026-07-06", track:"Daytona International Speedway", cars:"1987 NASCAR Cup (historic)", cat:"other", special:true, g61Tracks:[39]},
  {n:"NEC Round 6", s:"2026-07-04", e:"2026-07-05", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"6 / 10", dur:4, g61Tracks:[94]},
  {n:"Spa 24HR", s:"2026-07-10", e:"2026-07-12", track:"Circuit de Spa-Francorchamps", cars:"GT3", cat:"endurance", dur:24, special:true,
    winStart:"2026-07-10T22:00:00Z", winMin:2568, raceMin:1440, g61Tracks:[444,446],
    offsets:{1:0,2:540,3:840,4:1080}, labels:{1:"Sat 08:00 · 22:00Z",2:"Sat 17:00 · 07:00Z",3:"Sat 22:00 · 12:00Z",4:"Sun 02:00 · 16:00Z"}},
  {n:"Global Endurance Tour", s:"2026-07-11", e:"2026-07-12", track:"TBD", cars:"GT3 // GTP", cat:"endurance", dur:6},
  {n:"Creventic Round 2 — 12H Spa", s:"2026-07-18", e:"2026-07-19", track:"Circuit de Spa-Francorchamps", cars:"GT3 // Cup // GT4", cat:"endurance", series:"Creventic", round:"2 / 5", dur:12, g61Tracks:[444, 446]},
  {n:"Brickyard 400", s:"2026-07-22", e:"2026-07-27", track:"Indianapolis Motor Speedway", cars:"NASCAR Cup Series", cat:"nascar", special:true},
  {n:"6 Hours of Road America", s:"2026-07-24", e:"2026-07-26", track:"Road America", cars:"GTP & HYP // LMP2 // GT3", cat:"endurance", dur:6, special:true, g61Tracks:[49]},
  {n:"Knoxville Nationals", s:"2026-08-04", e:"2026-08-09", track:"Knoxville Raceway", cars:"410 Winged Sprint Cars", cat:"other"},
  {n:"NEC Round 7", s:"2026-08-08", e:"2026-08-09", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"7 / 10", dur:4, g61Tracks:[94]},
  {n:"Portimao 1000", s:"2026-08-14", e:"2026-08-15", track:"Algarve International Circuit", cars:"HPD // GT1 // GT2", cat:"endurance", dur:6, g61Tracks:[425]},
  {n:"Creventic Round 3 — 12H Barcelona", s:"2026-08-15", e:"2026-08-16", track:"Circuit de Barcelona-Catalunya", cars:"GT3 // Cup // GT4", cat:"endurance", series:"Creventic", round:"3 / 5", dur:12, g61Tracks:[76]},
  {n:"Crandon Championship", s:"2026-08-25", e:"2026-08-30", track:"Crandon International Raceway", cars:"Pro 4 Off-Road Truck", cat:"other"},
  {n:"NEC Round 8", s:"2026-08-29", e:"2026-08-30", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"8 / 10", dur:4, g61Tracks:[94]},
  {n:"Southern 500", s:"2026-09-02", e:"2026-09-07", track:"Darlington Raceway", cars:"NASCAR Cup Series", cat:"nascar", special:true},
  {n:"Suzuka 1000km", s:"2026-09-10", e:"2026-09-15", track:"Suzuka Circuit", cars:"GT3", cat:"endurance", dur:6, special:true, g61Tracks:[57]},
  {n:"Creventic Round 4 — 12H Nürburgring GP", s:"2026-09-12", e:"2026-09-13", track:"Nürburgring GP-Strecke", cars:"GT3 // Cup // GT4", cat:"endurance", series:"Creventic", round:"4 / 5", dur:12, g61Tracks:[66, 100]},
  {n:"Britcar 24HR", s:"2026-09-18", e:"2026-09-20", track:"Silverstone Circuit", cars:"GT3 // GT4", cat:"endurance", dur:24, g61Tracks:[80]},
  {n:"Petit Le Mans", s:"2026-09-25", e:"2026-09-27", track:"Road Atlanta", cars:"GTP // LMP2 // GT3", cat:"endurance", dur:10, special:true, g61Tracks:[40]},
  {n:"Creventic Round 5 — 24H Barcelona", s:"2026-09-26", e:"2026-09-27", track:"Circuit de Barcelona-Catalunya", cars:"GT3 // Cup // GT4", cat:"endurance", series:"Creventic", round:"5 / 5", dur:24, g61Tracks:[76]},
  {n:"Bathurst 1000", s:"2026-10-02", e:"2026-10-04", track:"Mount Panorama Circuit", cars:"Supercars", cat:"endurance", dur:6, special:true, g61Tracks:[79]},
  {n:"NEC Round 9", s:"2026-10-10", e:"2026-10-11", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"9 / 10", dur:4, g61Tracks:[94]},
  {n:"8 Hours of Indianapolis", s:"2026-10-16", e:"2026-10-18", track:"Indianapolis Motor Speedway", cars:"GT3", cat:"endurance", dur:8, special:true, g61Tracks:[380]},
  {n:"iRacing FF1600 Festival", s:"2026-10-30", e:"2026-10-31", track:"Brands Hatch", cars:"Ray FF1600", cat:"other"},
  {n:"Homestead Championship", s:"2026-11-04", e:"2026-11-09", track:"Homestead-Miami Speedway", cars:"NASCAR Cup Series", cat:"nascar", special:true},
  {n:"NEC Round 10", s:"2026-11-07", e:"2026-11-08", track:"Nürburgring Combined VLN", cars:"GT3 // Cup // GT4 // TCR // M2", cat:"endurance", series:"NEC", round:"10 / 10", dur:4, g61Tracks:[94]},
  {n:"SFL Mountain Showdown", s:"2026-11-13", e:"2026-11-15", track:"Mount Panorama Circuit", cars:"Super Formula Lights", cat:"other"},
  {n:"SCCA Runoffs", s:"2026-11-17", e:"2026-11-21", track:"Various / 6 classes", cars:"6 Classes", cat:"other"},
  {n:"992 Endurance Cup", s:"2026-11-27", e:"2026-11-29", track:"Circuit de Spa-Francorchamps", cars:"Porsche Cup 992.2", cat:"endurance", dur:12, g61Tracks:[444, 446]},
  {n:"Winter Derby", s:"2026-12-02", e:"2026-12-07", track:"Five Flags Speedway", cars:"Super Late Model", cat:"other"},
  {n:"Chili Bowl", s:"2026-12-15", e:"2026-12-20", track:"Tulsa Expo Center", cars:"Dirt Midget", cat:"other"},
  {n:"Production Car Challenge @ViR", s:"2026-12-18", e:"2026-12-19", track:"VIR Grand Course", cars:"Production Car Challenge cars", cat:"endurance", dur:2, g61Tracks:[394]}
];
const CAT_COLOR={endurance:'var(--yellow)', nascar:'var(--red)', other:'var(--steel)'};
/* ===== Weekly update ==================================================================
   Seeded from the series-popularity report (2026 S2 to 25 Jul 2026: 30 drivers, 2,064
   official starts, 111 series). Only the series the team actually runs are carried; `on`
   marks the twelve most-raced, which are ticked the first time an admin opens the tab.
   `who` is who actually starts that series, so a driver mention lands on someone who
   races it. Admin edits are stored in state.weekly and override all of this. */
const WEEKLY_SERIES=[
  {n:"IMSA iRacing Series",cat:"SPORTS CAR",st:215,on:true,who:["Sam Millar","Roland Fokkens","Andrew Espenes","Thomaz Hernandes"]},
  {n:"GT Sprint Series by Simucube",cat:"SPORTS CAR",st:172,on:true,who:["Sam Millar","Joseph Tavora","Roland Fokkens","Brock Hellmech"]},
  {n:"Ring Meister by LVRY",cat:"SPORTS CAR",st:121,on:true,who:["David Piljek","John Nyhouse","Roland Fokkens","Zachary Martin"]},
  {n:"iRacing Porsche Cup - Fixed by CONSPIT",cat:"SPORTS CAR",st:119,on:true,who:["Jake Lennox-Bradley","John Nyhouse","Aden Lennox-Bradley"]},
  {n:"Ford Mustang Challenge by Skip Barber",cat:"SPORTS CAR",st:102,on:true,who:["Dominic Bou-Samra","Michael Cullen","Thomaz Hernandes","John Nyhouse"]},
  {n:"iRacing Porsche Cup by CONSPIT",cat:"SPORTS CAR",st:100,on:true,who:["Thomaz Hernandes","Jake Lennox-Bradley","John Nyhouse"]},
  {n:"GT3 Challenge Fixed by Fanatec",cat:"SPORTS CAR",st:85,on:true,who:["Sam Millar","Roland Fokkens","Aaron Werth","Joseph Tavora"]},
  {n:"IMSA iRacing Series - Fixed",cat:"SPORTS CAR",st:76,on:true,who:["Sam Millar","Roland Fokkens","Andrew Espenes","Brock Hellmech"]},
  {n:"iRacing GT3 Regional Tour - Asia Pacific",cat:"SPORTS CAR",st:76,on:true,who:["Brock Hellmech","Aaron Werth","Joseph Tavora","Michael Cullen"]},
  {n:"Global Mazda MX-5 Cup by Fanatec",cat:"SPORTS CAR",st:71,on:true,who:["Aaron Werth","Zachary Martin","matt blee"]},
  {n:"Toyota GR86 Cup by SIMAGIC",cat:"SPORTS CAR",st:64,on:true,who:["Aaron Werth","Chris w","Zachary Martin"]},
  {n:"iRacing GT3 Regional Tour - Americas",cat:"SPORTS CAR",st:62,on:true,who:["Fred Zufelt","Aaron Werth","Dominic Bou-Samra","Bernardo Hickmann"]},
  {n:"Sports Car Challenge by Falken Tyre",cat:"SPORTS CAR",st:40,on:false,who:["Sam Millar","Dominic Bou-Samra","Zachary Martin"]},
  {n:"BMW M2 Cup by Nitro Concepts",cat:"SPORTS CAR",st:38,on:false,who:["Jake Lennox-Bradley","John Nyhouse","Aaron Werth"]},
  {n:"Production Car Challenge by Sim-Lab",cat:"SPORTS CAR",st:33,on:false,who:["Dominic Bou-Samra","Zachary Martin","Michael Cullen"]},
  {n:"Nurburgring Endurance Championship",cat:"SPORTS CAR",st:32,on:false,who:["Aden Lennox-Bradley","Jake Lennox-Bradley","Erik van der Bijl","John Nyhouse"]},
  {n:"Spec Racer Ford Challenge",cat:"SPORTS CAR",st:31,on:false,who:["John Nyhouse","Fred Zufelt","Zachary Martin"]},
  {n:"Formula 1600 Rookie Series by Asetek Racing",cat:"FORMULA CAR",st:27,on:false,who:["Fred Zufelt","Aaron Werth","John Nyhouse"]},
  {n:"FIA Formula 4 Challenge - Fixed",cat:"FORMULA CAR",st:25,on:false,who:["Sam Millar","Aaron Werth","Brock Hellmech","Ben Hagstrom"]},
  {n:"GT Endurance Series by Simucube",cat:"SPORTS CAR",st:23,on:false,who:["Joseph Tavora","Sam Mackenzie","Sam Millar","Brock Hellmech"]},
  {n:"13th Week Mini Stock Cup",cat:"OVAL",st:22,on:false,who:["Sam Millar","Brock Hellmech","John Nyhouse"]},
  {n:"24 Hours of Spa Presented by Falken Tyre",cat:"SPORTS CAR",st:22,on:false,who:["Aaron Werth","Brock Hellmech","Luke Hay","Matthew Halden"]},
  {n:"Global Endurance Tour",cat:"SPORTS CAR",st:21,on:false,who:["Sam Millar","Ben Hagstrom","Erik van der Bijl","John Nyhouse"]},
  {n:"Advanced Mazda MX-5 Cup by Heusinkveld",cat:"SPORTS CAR",st:20,on:false,who:["Dominic Bou-Samra","Michael Cullen","Luke Hay"]},
  {n:"BMW M2 Cup",cat:"SPORTS CAR",st:19,on:false,who:["Luke Hay","Aaron Werth"]},
  {n:"12 Hours of Sebring",cat:"SPORTS CAR",st:18,on:false,who:["Brock Hellmech","Sam Millar","Aden Lennox-Bradley","Andrew Espenes"]},
  {n:"FIA F4 Esports Regional Tour - Asia Pacific",cat:"FORMULA CAR",st:18,on:false,who:["Aaron Werth","Thomas McEwan","Brock Hellmech","Ben Hagstrom"]},
  {n:"6 Hours of the Glen",cat:"SPORTS CAR",st:17,on:false,who:["Sam Mackenzie","Sam Millar","Thomaz Hernandes","Chris w"]},
  {n:"13th Week GT3 Challenge - Fixed",cat:"SPORTS CAR",st:16,on:false,who:["Brock Hellmech","Sam Millar","Bernardo Hickmann","John Nyhouse"]},
  {n:"GT4 Challenge by Falken Tyre",cat:"SPORTS CAR",st:16,on:false,who:["John Nyhouse","Dominic Bou-Samra","Aaron Werth"]}];
function isTarget(ev){ return !!ev.special || (ev.cat==='endurance' && (ev.dur||0)>=3); }
function evKey(ev){ return ev.n+'|'+ev.s; }
function calendar(){ const at={}, out=[]; CAL_EVENTS.concat(state.customEvents||[], state.irEvents||[]).forEach(e=>{ const k=evKey(e); if(at[k]!==undefined){ const m=Object.assign({}, out[at[k]], e); if(e.track && out[at[k]].track && e.track!==out[at[k]].track && !e.g61Tracks) delete m.g61Tracks; out[at[k]]=m; } else { at[k]=out.length; out.push(e); } }); return out; }  // seed + custom + imported, deduped by key (later fields win; fields it leaves out, like g61Tracks, are kept)
function calEvent(key){ return calendar().find(e=>evKey(e)===key)||null; }
function addCustomEvent(o){ o.src='custom'; state.customEvents.push(o); save(); }
function deleteCustomEvent(key){ state.customEvents=(state.customEvents||[]).filter(e=>evKey(e)!==key); state.irEvents=(state.irEvents||[]).filter(e=>evKey(e)!==key); save(); }
const _today=new Date(); _today.setHours(0,0,0,0);
function statusFor(ev){
  const s=new Date(ev.s+'T00:00:00'), e=new Date(ev.e+'T23:59:59');
  if(_today<s) return {label:Math.round((s-_today)/86400000), state:'upcoming'};
  if(_today>=s&&_today<=e) return {label:0,state:'live'};
  return {label:0,state:'past'};
}
function fmtDates(s,e){
  const o={month:'short',day:'numeric'}; const sd=new Date(s+'T00:00:00'), ed=new Date(e+'T00:00:00');
  const l=sd.toLocaleDateString('en-AU',o), r=ed.toLocaleDateString('en-AU', sd.getMonth()===ed.getMonth()?{day:'numeric'}:o);
  return s===e?l:l+'–'+r;
}

/* ===== Roles: driver (default, edits own availability only) vs admin (password / WP login) ===== */
function isAdmin(){ return state.role==='admin'; }
/* Admin password (standalone): change it by replacing ADMIN_HASH with _hash('yournewpassword')
   — run _hash('...') in the browser console. Current password: edr2026 */
/* Driver flare for the weekly write-up. One short, usable hook per driver — the kind of thing
   that makes a series line land. Anything from the source profiles that reads as a dig at
   someone, or is nobody else's business, is not in here: this text gets pasted into a team
   channel. Admins can edit or clear any of it on the Weekly tab (state.weekly.driver). */
/* Personality lines for the earned driver mentions, from the team's own profile brief. Only ever
   shown for a driver the week's data actually ties to a round (see flareFor) — never dropped in
   for no reason. Drivers without a line here fall back to their own record. Keys are the Garage 61
   roster spellings (NAME_ALIASES maps survey/profile variants onto these). */
const DRIVER_NOTES={
  'Matthew Halden':'the ringmaster; names corners by crashing into them, and Blanchimont is his',
  'Chris w':'co-founder and Kiwi race voice; get the car home in one piece',
  'Aden Lennox-Bradley':'the fastest here, and the most allergic to being seen to care',
  'Jake Lennox-Bradley':'the tinkerer who confesses the crash first; keeps score only against Aden',
  'matt blee':'the social engine; ten seconds off the pace and first to say the sincere thing',
  'Dominic Bou-Samra':'meme-engineer; bins it from a good grid slot and posts the clip himself',
  'Laurent Masson':'the emotional core, permanently over-trying and permanently sorry about it',
  'Thomaz Hernandes':'built half the grid rigs and painted their cars, then races them mid-pack',
  'Erik van der Bijl':'the coach; his whole method is two words, do less',
  'Joseph Tavora':'genuinely quick, and his own harshest steward',
  'Michael Cullen':'the chat comedian and its most rigorous mind in the one body',
  'Aaron Werth':'loudest and keenest; rawdogs a race with no practice, then explains the dead tyres',
  'Sam Millar':'wears his heart on his sleeve; would rather do an all-nighter enduro than sleep',
  'Janne Salminen':'the quiet Finn who out-drives everyone and gives the credit away',
  'Brock Hellmech':'no ego about being slow, no shame about improving in public',
  'Luke Hay':'six words and a filthy punchline; pays for the liveries, organises the racing',
  'John Nyhouse':'boundlessly keen, wildly accident-prone, apologises at length for everything',
  'Fred Zufelt':'the 3am Canadian who defends Lance Stroll to his last breath',
  'David Piljek':'Nordschleife obsessive with a real-life Ring war story',
  'Jarrod Williams':'the quiet quartermaster; hands you a setup, posts your position, owns his mistakes',
  'Zachary Martin':'apologises for his lap times before anyone can; lights up about old cars',
  'Roland Fokkens':'IMSA mainstay',
  'Sam Mackenzie':'endurance specialist',
  'Andrew Espenes':'quietly racks up the starts',
  'Jackson Lancaster':'Geelong teenager racing off a wooden end desk; takes any GT3 seat going',
  'River Johnson':'the nocturnal American who reckons GT3 is beneath him'
};
/* Track hooks, keyed by a loose match on the iRacing track name. Seeded from the write-ups
   that already worked; admins add to it over time (state.weekly.track). */
const TRACK_NOTES={
  'hockenheim':'a mix of high and low speed corners — watch turn 15 in particular',
  'sandown':'about as close as iRacing gets to Doreen',
  'misano':'tricky, and forever in EDR hearts. PSA: watch the long pit exit',
  'monza':'looks simple, but there are seconds on the ground in those chicanes',
  'tsukuba':'small, tight and twisty — perfect fit for the Mazda',
  'suzuka':'hard to pass on, so do not bottle qualifying',
  'spa':'Blanchimont is still undefeated',
  'nurburgring':'bring patience and a fresh set of nerves',
  'barcelona':'front tyres will be gone by the end of a stint',
  'road america':'long straights, so the tow matters more than you think',
  'watkins glen':'the esses reward commitment and punish it in equal measure',
  'daytona':'the bus stop decides your race',
  'bathurst':'across the top, lift and you lose it'
};
const ADMIN_HASH='1rdbl5c';
function _hash(s){ let x=5381; for(let i=0;i<s.length;i++) x=(((x*33)>>>0)^s.charCodeAt(i))>>>0; return x.toString(36); }
function verifyAdminPass(p,cb){ cb(_hash(p)===ADMIN_HASH); }  /* WP build overrides: asks the server */
function onAdminUnlocked(){}  /* WP build overrides: loads the Setup tab's track/event lists */
/* inline password field (never window.prompt — that is blocked in sandboxed
   iframes/embeds and the Admin button would silently do nothing) */
let _unlockOpen=false, _unlockMsg='';
function unlockAdmin(){ _unlockOpen=true; _unlockMsg=''; renderRolebar(); const i=document.getElementById('adminpass'); if(i) i.focus(); }
function submitUnlock(){
  const i=document.getElementById('adminpass'); const p=(i&&i.value)||'';
  if(!p) return;
  verifyAdminPass(p, (ok,msg)=>{
    if(ok){ _unlockOpen=false; _unlockMsg=''; state.role='admin'; state.pass=p; save(); renderRolebar(); onAdminUnlocked(); renderContent(); setStatus('Admin unlocked'); }
    else { _unlockMsg=msg||'wrong password'; renderRolebar(); const j=document.getElementById('adminpass'); if(j) j.focus(); }   /* msg: the WP build passes the server's reason, e.g. the rate limit */
  });
}
function lockAdmin(){ state.role='driver'; state.pass=''; _unlockOpen=false; save(); renderRolebar(); renderContent(); }
function renderRolebar(){
  const el=document.getElementById('rolebar'); if(!el) return;
  const tzSel='<select data-tzpick title="show all times in your timezone" style="font-size:10px;padding:3px 6px;margin-left:8px;background:var(--panel2);color:var(--body);border:1px solid var(--line);border-radius:6px">'+TZ_ZONES.map(z=>'<option value="'+z[0]+'"'+(z[0]===TZ?' selected':'')+'>'+z[1]+'</option>').join('')+'</select>';
  if(isAdmin()){
    el.innerHTML='<span class="rolechip admin">ADMIN</span><button class="btn btn-ghost" data-role-action="lock" style="font-size:10px;padding:4px 12px">Lock</button>'+tzSel;
  } else if(_unlockOpen){
    el.innerHTML='<input type="password" id="adminpass" placeholder="admin password" autocomplete="off" style="padding:7px 12px;font-size:12px;width:150px">'
      +'<button class="btn btn-amber" data-role-action="go" style="font-size:10px;padding:5px 13px">Unlock</button>'
      +'<button class="btn btn-ghost" data-role-action="cancel" style="font-size:10px;padding:5px 11px">✕</button>'
      +(_unlockMsg?'<span class="meta" style="color:var(--red)">'+_unlockMsg+'</span>':'');
  } else {
    el.innerHTML='<span class="rolechip">DRIVER</span><button class="btn btn-ghost" data-role-action="unlock" style="font-size:10px;padding:4px 12px">Admin</button>'+tzSel;
  }
}

/* ===== Event selection → timing (window, candidate starts, race length) ===== */
let EV_WIN_MIN=2568;  // availability-window length (min) for the selected event; Spa default
/* Format an absolute timestamp as "Sat 08:00 · 22:00Z" (Brisbane clock + UTC) — used for
   candidate-start labels so they read the same whichever event's window is loaded. */
function fmtStartLabel(ms){
  const bris=new Date(ms).toLocaleString('en-AU',{timeZone:tzZone(),weekday:'short',hour:'2-digit',minute:'2-digit',hour12:false});
  const d=new Date(ms); const utc=String(d.getUTCHours()).padStart(2,'0')+':'+String(d.getUTCMinutes()).padStart(2,'0');
  return bris+' · '+utc+'Z';
}
/* Turn official iRacing session times into a per-event timing override (winStart,
   candidate starts, race length). Reproduces the hand-typed Spa values exactly. */
function applyIrTiming(ev, sea){
  const times=(sea.sessions||[]).map(t=>Date.parse(t)).filter(x=>!isNaN(x)).sort((a,b)=>a-b);
  if(!times.length) return false;
  const winStart=times[0], offsets={}, labels={};
  times.slice(0,6).forEach((t,i)=>{ offsets[i+1]=Math.round((t-winStart)/60000); labels[i+1]=fmtStartLabel(t); });
  const raceMin=sea.race_min||state.stint.race||360;
  const maxOff=Math.max.apply(null,Object.values(offsets));
  // availability window spans the first start to the last candidate race end (we have exact
  // times here, so don't pad to calendar days); respect a larger hand-typed winMin if set
  const winMin=Math.max(maxOff+raceMin, ev.winMin||0);
  state.evTiming[evKey(ev)]={winStart:new Date(winStart).toISOString(), raceMin:raceMin, offsets:offsets, labels:labels, winMin:winMin, src:sea.name||'iRacing'};
  return true;
}
function applyEventTiming(ev0){
  const ovr=state.evTiming&&state.evTiming[evKey(ev0)];
  const ev=ovr?Object.assign({},ev0,ovr):ev0;
  /* block size is per event (admin setting): 2h suits a 24h enduro but is far too coarse for a
     3h sprint, where it can swallow the whole race in two ticks */
  AV_BLOCK = avBlockOk(ev.avBlock) ? ev.avBlock : 120;
  WIN_START_MS = ev.winStart ? Date.parse(ev.winStart) : Date.parse(ev.s+'T00:00:00+10:00');
  const days=Math.round((Date.parse(ev.e+'T00:00:00Z')-Date.parse(ev.s+'T00:00:00Z'))/86400000)+1;
  EV_WIN_MIN = ev.winMin || days*1440;
  const raceMin = ev.raceMin || Math.min((ev.dur||6)*60, EV_WIN_MIN);
  state.stint.race = raceMin;
  if(ev.offsets){ START_OFFSETS=Object.assign({},ev.offsets); START_LABELS=Object.assign({},ev.labels||{}); }
  else{
    START_OFFSETS={}; START_LABELS={};
    const maxOff=Math.max(0, EV_WIN_MIN-raceMin);
    const step=Math.max(240, Math.round(maxOff/180)*60||240);
    let n=1;
    for(let off=0; off<=maxOff && n<=4; off+=step){ START_OFFSETS[n]=off; START_LABELS[n]=fmtClock(off); n++; }
    if(!Object.keys(START_OFFSETS).length){ START_OFFSETS={1:0}; START_LABELS={1:fmtClock(0)}; }
  }
  if(!START_OFFSETS[state.stint.window]) state.stint.window=+Object.keys(START_OFFSETS)[0];
}
function selectEvent(key){
  const ev=calEvent(key); if(!ev||!isTarget(ev)) return;
  const changed = state.evsel!==key;
  state.evsel=key;
  applyEventTiming(ev);
  state.stintAssign={}; state.stintWin={}; state.stintSig='';
  if(changed) state.teams={};   // don't carry the previous event's rosters into a new event; user re-runs Generate
  applyAvailToDrivers();
  save(); state.tab='availability'; setActiveTab(); renderContent();
}

/* ===== Availability: 2h blocks over the event window, converted to the
   {hours, pct, starts, windows} shape the scoring and stints already use ===== */
/* Availability block size in minutes. Per event (see applyEventTiming); 120 is the default and
   what every event used before 2.4.11. Stored ticks are slot INDEXES, so this value is part of
   how they are read — changing it has to rescale them (avSetBlock), never just reinterpret. */
let AV_BLOCK=120;
const AV_BLOCK_CHOICES=[30,60,90,120,180,240];
function avBlockOk(v){ return AV_BLOCK_CHOICES.indexOf(+v)>=0; }
/* slots -> [start,end] minute windows at a given block size; the pure form of slotsToAvail's
   first half, so a rescale can read old ticks with the old size before rewriting them */
function slotsToWindows(slots, block, winMin){
  const set=new Set(slots||[]), out=[]; let run=null;
  const n=Math.max(1, Math.ceil(winMin/block));
  for(let i=0;i<n;i++){
    if(!set.has(i)){ run=null; continue; }
    const s=i*block, e=Math.min((i+1)*block, winMin);
    if(run && run[1]===s){ run[1]=e; } else { run=[s,e]; out.push(run); }
  }
  return out;
}
function evSlots(){ return Math.max(1, Math.ceil(EV_WIN_MIN/AV_BLOCK)); }
function slotsToAvail(slots){
  const set=new Set(slots||[]); const windows=[]; let run=null; const n=evSlots();
  for(let i=0;i<n;i++){
    if(!set.has(i)){ run=null; continue; }
    const s=i*AV_BLOCK, e=Math.min((i+1)*AV_BLOCK, EV_WIN_MIN);
    if(run && run[1]===s){ run[1]=e; } else { run=[s,e]; windows.push(run); }
  }
  const total=windows.reduce((a,w)=>a+(w[1]-w[0]),0);
  const race=Math.max(30,state.stint.race);
  const starts=Object.keys(START_OFFSETS).filter(k=>windows.some(w=>w[0]<=START_OFFSETS[k]&&w[1]>=START_OFFSETS[k]+race)).map(Number);
  return {hours:Math.round(total/6)/10, pct:EV_WIN_MIN?Math.round(total/EV_WIN_MIN*100):0, starts, windows};
}
/* ---- driver identity housekeeping -----------------------------------------------------
   Drivers the team does not want in the builder at all: someone who left, a duplicate the
   APIs keep re-creating, a test entry. Held as name keys so a re-import cannot resurrect
   them, and reversible — nothing is destroyed, they are just filtered out. */
function excludedMap(){ state.excluded=state.excluded||{}; return state.excluded; }
function isExcluded(name){ return !!excludedMap()[nameKey(name)]; }
function excludeDriver(name){
  if(!isAdmin()||!name) return;
  excludedMap()[nameKey(name)]=name;                       // keep a display name for the undo list
  state.drivers=(state.drivers||[]).filter(function(d){ return nameKey(d.name)!==nameKey(name); });
  /* drop them from any car they were assigned to, or Teams/Stints keep rendering a ghost */
  Object.keys(state.teams||{}).forEach(function(cls){
    ['pro','casual'].forEach(function(tier){
      (state.teams[cls][tier]||[]).forEach(function(car,i){
        state.teams[cls][tier][i]=(car||[]).filter(function(n){ return nameKey(n)!==nameKey(name); });
      });
    });
  });
  Object.keys(state.stintAssign||{}).forEach(function(k){
    if(nameKey(state.stintAssign[k]||'')===nameKey(name)) delete state.stintAssign[k];
  });
  applyAvailToDrivers(); save(); renderContent();
}
function restoreDriver(key){
  if(!isAdmin()) return;
  delete excludedMap()[key];
  applyAvailToDrivers(); save(); renderContent();
}
/* Collapse driver rows that are really the same person. Needed because a plan saved before the
   name-suffix fix still holds both spellings, and loadPlan() restores state.drivers verbatim —
   so without this the duplicate survives every reload until someone runs an import. */
function dedupeDrivers(){
  const byKey={}, out=[];
  (state.drivers||[]).forEach(function(d){
    const k=nameKey(d.name), prev=byKey[k];
    if(!prev){ byKey[k]=d; out.push(d); return; }
    // prefer the unsuffixed spelling, and keep whichever row actually has pace data
    if(/\d$/.test(prev.name) && !/\d$/.test(d.name)) prev.name=d.name;
    const pc=Object.keys(prev.cars||{}).length, dc=Object.keys(d.cars||{}).length;
    if(dc>pc) prev.cars=d.cars;
    if(!prev.assignedCar && d.assignedCar) prev.assignedCar=d.assignedCar;
    if(prev.irating==null && d.irating!=null) prev.irating=d.irating;
    if(!prev.carLock && d.carLock) prev.carLock=d.carLock;
  });
  const removed=(state.drivers||[]).length-out.length;
  state.drivers=out;
  return removed;
}
function applyAvailToDrivers(){
  if(!state.evsel) return;
  const a=state.availStore[state.evsel]||{};
  /* availability is strictly per event: wipe first so nobody carries a previous
     event's windows into this one (e.g. Spa availability showing up at NEC) */
  state.drivers.forEach(d=>{ d.avail=null; });
  const byKey={}; state.drivers.forEach(d=>{ byKey[nameKey(d.name)]=d; });
  /* Two spellings of one person now collapse to the same key — iRacing's "Sam Millar2"
     suffix, or an entry in NAME_ALIASES. Gather the UNION of their blocks first: assigning
     inside the loop let whichever spelling the object happened to yield last overwrite the
     other, silently dropping half a driver's availability depending on key order. */
  const merged={};
  Object.keys(a).forEach(n=>{
    if(!(a[n]&&a[n].length)) return;   // no blocks ticked -> not a pool member (avoids hours:0 phantom drivers)
    if(isExcluded(n)) return;          // removed by an admin: never re-add them from stored availability
    const k=nameKey(n);
    if(!merged[k]) merged[k]={name:n, slots:{}};
    else if(/\d$/.test(merged[k].name) && !/\d$/.test(n)) merged[k].name=n;   // prefer the unsuffixed spelling
    a[n].forEach(s=>{ merged[k].slots[s]=1; });
  });
  Object.keys(merged).forEach(k=>{
    let d=byKey[k];
    if(!d){
      /* anyone who submits availability joins the driver pool; pace fills in on the next import */
      const id=state.drivers.reduce((m,x)=>Math.max(m,x.id),0)+1;
      d={id:id, name:merged[k].name, cars:{}, assignedCar:undefined, avail:null};
      state.drivers.push(d); byKey[k]=d;
    }
    d.avail=slotsToAvail(Object.keys(merged[k].slots).map(Number).sort((x,y)=>x-y));
  });
}
function windowsToSlots(windows, winMin, block, strict){
  const W=winMin||EV_WIN_MIN; const B=block||AV_BLOCK;
  const out=[]; const n=Math.max(1, Math.ceil(W/B));
  for(let i=0;i<n;i++){
    const s=i*B, e=Math.min((i+1)*B, W);
    /* strict = the block must sit entirely inside a window. Used when moving to a LARGER
       block size, where the usual "half of it counts" rule rounds outward and hands back
       more availability than the driver actually gave — which could put them in a stint
       they never offered. Losing a sliver is fine; inventing one is not. */
    const hit = strict
      ? (windows||[]).some(w=>w[0]<=s && w[1]>=e)
      : (windows||[]).some(w=>{ const ov=Math.min(w[1],e)-Math.max(w[0],s); return ov>0 && ov >= Math.min(e-s, w[1]-w[0])/2; });
    if(hit) out.push(i);
  }
  return out;
}
/* Re-seed Spa availability from the embedded SAMPLE (survey 2307) on every boot.
   Idempotent and never overwrites blocks a driver has submitted since; repairs saves
   where event-switching wiped the survey availability before it reached the store. */
function seedSpaAvail(){
  const SPA='Spa 24HR|2026-07-10', SPA_WIN=2568;
  const st=state.availStore[SPA]=state.availStore[SPA]||{};
  SAMPLE.forEach(s=>{ if(s.avail&&s.avail.windows&&s.avail.windows.length&&!(st[s.name]&&st[s.name].length)) st[s.name]=windowsToSlots(s.avail.windows, SPA_WIN); });
}
function persistAvail(evk,name){}  /* WP build overrides: syncs this driver's slots to the server */
function releaseLock(name){}       /* WP build overrides: admin clears a driver's submission lock */
/* Device token: a random per-browser id, still sent with availability writes. The hard
   first-device-owns-the-name lock it used to drive was dropped in 2.4.2 (it kept locking
   drivers out of their own availability when they moved phone -> PC), so ownership is now
   advisory only — any device may edit any driver's blocks and the team runs on trust. */
let DEV_TOKEN=(function(){ try{ let t=localStorage.getItem('edrTB_devtok'); if(!t){ t=Array.from((window.crypto&&crypto.getRandomValues)?crypto.getRandomValues(new Uint8Array(16)):[...Array(16)].map(()=>Math.floor(Math.random()*256))).map(b=>b.toString(16).padStart(2,'0')).join(''); localStorage.setItem('edrTB_devtok',t); } return t; }catch(e){ return 'mem-'+Math.random().toString(36).slice(2); } })();
let LOCKED_NAMES=[];               /* names locked server-side (WP build fills this from GET /avail) */
function ownedNames(){ try{ return JSON.parse(localStorage.getItem('edrTB_owned'))||[]; }catch(e){ return []; } }
function markOwned(name){ try{ const k=nameKey(name),o=ownedNames(); if(!o.some(x=>nameKey(x)===k)){ o.push(name); localStorage.setItem('edrTB_owned',JSON.stringify(o)); } }catch(e){} }
function lockedForMe(name){ const k=nameKey(name); return LOCKED_NAMES.some(x=>nameKey(x)===k) && !ownedNames().some(x=>nameKey(x)===k); }
/* EDR membership pulled live from Garage 61 on 2026-07-05 (teams edr-endurotech +
   edr-endurotech-casual).
   Baked-in fallback; the WP build replaces it with the live list from GET /roster. */
let ROSTER_IDS={};   // iRacing customer ID -> display name (filled by the WP /roster payload)
let _iridMsg='';
let TEAM_ROSTER=["Aaron Werth", "Aden Lennox-Bradley", "Ben Hagstrom", "Bernardo Hickmann", "Bradley Whittaker", "Brock Hellmech", "Chris w", "David Piljek", "Dominic Bou-Samra", "Erik van der Bijl", "Fred Zufelt", "Jake Lennox-Bradley", "Janne Salminen", "John Nyhouse", "Joseph Tavora", "Landon Schrecengost", "Laurent Masson", "Luke Hay", "matt blee", "Matthew Halden", "Michael Cullen", "Roland Fokkens", "Sam Mackenzie", "Sam Millar", "Stipe Ljubić", "Thomas McEwan", "Thomaz Hernandes", "Valentin Ozhiganov", "Zachary Martin"];
let _availDirty={};   /* {evKey:{name:1}} — ticked but not yet submitted */
let _avMsg='', _avErr=false;   /* _avErr colours the message: sniffing it for the word "failed" mislabelled server refusals as success */
/* the survey/plan and Garage 61 sometimes spell the same person differently — dedup via
   the documented override map + diacritic-insensitive matching */
const NAME_ALIASES={'joey tavora':'joseph tavora','matt halden':'matthew halden','zach martin':'zachary martin','chris wilson':'chris w','michael s cullen':'michael cullen'};
/* The trailing digits are iRacing's collision suffix ("sam millar2", "luke hay3"), not part of
   anyone's name. Stripping them here means a driver who already has data stored under the
   suffixed spelling folds onto the real one everywhere keys are compared \u2014 pool membership,
   scoring, the availability roster \u2014 without having to rewrite what is stored. Only strips
   when a letter precedes the digits. */
function nameKey(n){
  n=String(n||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  n=n.replace(/([a-z])\d{1,3}$/,'$1');   /* capture group, not lookbehind: Safari before 16.4 throws on lookbehind at PARSE time, which would kill the whole bundle for anyone on an older iPhone */
  return NAME_ALIASES[n]||n;
}
function availRoster(){
  const out=[], seen={};
  const add=n=>{ const k=nameKey(n); if(k&&!seen[k]&&!isExcluded(n)){ seen[k]=1; out.push(n); } };
  state.drivers.forEach(d=>add(d.name));
  TEAM_ROSTER.forEach(add);
  Object.keys(state.availStore[state.evsel]||{}).forEach(add);
  return out.sort((x,y)=>x.localeCompare(y));
}
function fmtDay(absMin){
  return new Date(WIN_START_MS+absMin*60000).toLocaleDateString('en-AU',{timeZone:tzZone(),weekday:'short',day:'numeric',month:'short'});
}

/* ===== Instructions tab (driver landing page) ===== */
function renderInstructions(){
  const wn=(state.swapNote||'').trim();
  const hasIds=Object.keys(ROSTER_IDS||{}).length>0;
  let h='';
  h+='<div class="importbox"><div class="head" style="font-size:17px;color:#fff;text-transform:uppercase">How this works</div>'
    +'<div class="meta" style="margin-top:7px;max-width:780px;line-height:1.7">This is the team\'s endurance planner. You tell it <b style="color:#fff">when you can drive</b>; the admins build the cars and the stint plan around everyone\'s availability. Everything here is live and shared with the whole team, and every clock shows <b style="color:#fff">your local time</b> — set with the timezone picker in the top-right corner.</div></div>';
  h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;color:var(--yellow)">Step 1 · Tell us when you can race</div>'
    +'<div class="meta" style="line-height:1.7;max-width:780px">Open the <b style="color:#fff">Availability</b> tab. '
    +(hasIds?'Type your <b style="color:#fff">iRacing customer ID</b> (helmet menu in iRacing, or your Garage 61 profile) and hit <b style="color:#fff">Find me</b> — your name comes up automatically, and this device remembers you from then on.':'Pick your name from the list.')
    +' Tap every 2-hour block you could be in the car, choose your race preference (start or finish the race · wet or dry) — and on multi-class events, pick <b style="color:#fff">which class you\'re racing</b> — then hit <b style="color:#fff">Submit availability</b>. You can update it any time — more green blocks makes the planner\'s job easier.</div>'
    +'<div style="margin-top:12px"><button class="btn btn-amber avfree" data-action="gotoavail">Enter my availability</button></div></div>';
  h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;color:var(--yellow)">Step 2 · Read your stints</div>'
    +'<div class="meta" style="line-height:1.8;max-width:780px">On the <b style="color:#fff">Stints</b> tab, each card is one car. How to read it:'
    +'<br>· The top row is the clock (your local time) with the conditions that hour: <b style="color:var(--amber)">\u2600 day</b> · <b style="color:#9aa3c0">\uD83C\uDF19 night</b> · <b style="color:#6ea8ff">\uD83C\uDF27 rain</b> — the percentage is the rain chance.'
    +'<br>· The <b style="color:#fff">Driving</b> row is who\'s in the car for each stint.'
    +'<br>· Your own lane below it: <span style="color:var(--green)">green = you said you\'re available</span> · striped = you\'re not · solid colour = <b style="color:#fff">you are driving that stint</b>.'
    +'<br>· The fuel line shows laps and litres per stint, and \u26FD marks where a pit stop lands.'
    +'<br>· Scroll each card sideways to see the whole race.</div></div>';
  h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;color:var(--yellow)">Step 3 · Know your car</div>'
    +'<div class="meta" style="line-height:1.7;max-width:780px">The <b style="color:#fff">Teams</b> tab shows your car and teammates, with each driver\'s pace, laps, clean percentage and iRating. The <b style="color:#fff">Drivers</b> tab is the ranking the split is built from. Both are read-only for drivers — the admins arrange the cars.</div></div>';
  h+='<div class="importbox" style="border-left:4px solid var(--yellow)"><div class="meta" style="text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px">Need a stint swapped, or can\'t make your slot?</div>'
    +'<div style="font-family:Prompt,sans-serif;font-weight:600;color:#fff;font-size:15px">'+(wn?esc(wn):'Message Thomaz on Discord — @tomhernandes')+'</div>'
    +'<div class="meta" style="margin-top:6px;line-height:1.6;max-width:780px">Don\'t just not show up — the plan can be rearranged in minutes if we know early.</div>'
    +(isAdmin()?'<div style="margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap"><span class="meta" style="font-size:10px;text-transform:uppercase">Admin · edit this contact line</span><input type="text" data-action="swapnote" value="'+esc(wn)+'" placeholder="e.g. Message Thomaz on Discord (@thomaz) for swaps" style="padding:7px 10px;font-size:12px;min-width:320px"></div>':'')
    +'</div>';
  return h;
}
/* ===== Event tab (season calendar) ===== */
let _calFilter='all', _calTargets=true, _calPast=false, _evFormOpen=false, _evSyncMsg='';
let _calAll=false;          /* false = just what is actionable; true = the whole calendar */
const CAL_BRIEF=6;          /* rows kept in the short view, on top of anything live or selected */
function weekStartOf(s){ const dt=new Date(s+'T00:00:00'); const day=dt.getDay(); dt.setDate(dt.getDate()+((day===0?-6:1)-day)); return dt; }
function renderEventTab(){
  let html='';
  const upcoming=calendar().filter(ev=>statusFor(ev).state!=='past').sort((a,b)=>a.s.localeCompare(b.s))[0];
  if(upcoming){
    const st=statusFor(upcoming);
    html+='<div class="pitboard"><div><div class="meta" style="text-transform:uppercase;letter-spacing:.1em;color:var(--yellow)">'+(st.state==='live'?'live now':'next up')+'</div>'
      +'<div class="head" style="font-size:22px;color:#fff;text-transform:uppercase;letter-spacing:.03em">'+esc(upcoming.n)+'</div>'
      +'<div class="meta">'+esc(upcoming.track)+' · '+fmtDates(upcoming.s,upcoming.e)+(isTarget(upcoming)?' · <span style="color:var(--yellow)">EDR target</span>':'')+'</div></div>'
      +'<div class="pitcount"><div class="num">'+(st.state==='live'?'GO':st.label)+'</div><div class="meta">'+(st.state==='live'?'racing':(st.label===1?'day':'days'))+'</div></div></div>';
  }
  html+='<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:14px">';
  [['all','All'],['endurance','Endurance / team'],['other','Other specials'],['nascar','NASCAR']].forEach(([k,l])=>{
    html+='<button class="chip'+(k===_calFilter?' calactive':'')+'" data-action="calfilter" data-val="'+k+'" style="cursor:pointer">'+l+'</button>';
  });
  html+='<label class="meta" style="margin-left:8px;cursor:pointer"><input type="checkbox" data-action="caltargets"'+(_calTargets?' checked':'')+'> EDR targets only</label>';
  html+='<label class="meta" style="cursor:pointer"><input type="checkbox" data-action="calpast"'+(_calPast?' checked':'')+'> show past</label>';
  html+='</div>';
  if(isAdmin()){
    html+='<div class="importbox" style="margin-bottom:14px"><button class="btn btn-ghost" data-action="addcustomev" style="font-size:11px">+ Add custom event</button> <button class="btn btn-ghost" data-action="syncir" style="font-size:11px">⟳ Sync iRacing events</button>'+(_evSyncMsg?'<span class="meta" style="margin-left:8px">'+esc(_evSyncMsg)+'</span>':'');
    if(_evFormOpen){
      html+='<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;align-items:flex-end">'
        +'<div class="ctl"><label>NAME</label><input id="cev_n" placeholder="Le Mans 24" style="padding:6px;width:150px"></div>'
        +'<div class="ctl"><label>TRACK</label><input id="cev_track" placeholder="Circuit de la Sarthe" style="padding:6px;width:160px"></div>'
        +'<div class="ctl"><label>START</label><input id="cev_s" type="date" style="padding:6px"></div>'
        +'<div class="ctl"><label>END</label><input id="cev_e" type="date" style="padding:6px"></div>'
        +'<div class="ctl"><label>RACE (h)</label><input id="cev_dur" type="number" min="1" step="1" value="24" style="padding:6px;width:70px"></div>'
        +'<div class="ctl"><label>CATEGORY</label><select id="cev_cat"><option value="endurance">Endurance</option><option value="other">Other</option><option value="nascar">NASCAR</option></select></div>'
        +'<div class="ctl"><label>CLASSES</label><input id="cev_cls" placeholder="GT3 // Cup // GT4" value="GT3" style="padding:6px;width:150px"></div>'
        +'<label class="meta" style="align-self:center"><input type="checkbox" id="cev_tgt" checked> EDR target</label>'
        +'<button class="btn btn-amber" data-action="savecustomev" style="font-size:11px">Save event</button>'
        +'<button class="btn btn-ghost" data-action="cancelcustomev" style="font-size:11px">Cancel</button></div>';
    }
    html+='</div>';
  }
  let list=calendar().filter(ev=>(_calFilter==='all'||ev.cat===_calFilter)&&(!_calTargets||isTarget(ev))&&(_calPast||statusFor(ev).state!=='past'))
    .slice().sort((a,b)=>a.s.localeCompare(b.s));
  /* Default to what is actually actionable — live now, the next few up, and whatever is
     selected. The full year was 18 rows and three and a half phone screens for a driver who
     almost always only cares about the race in front of them. */
  const fullCount=list.length;
  if(!_calAll && fullCount>CAL_BRIEF){
    const keep=list.filter(ev=>statusFor(ev).state==='live'||state.evsel===evKey(ev));
    list.filter(ev=>statusFor(ev).state!=='live'&&state.evsel!==evKey(ev)).forEach(ev=>{ if(keep.length<CAL_BRIEF) keep.push(ev); });
    list=keep.sort((a,b)=>a.s.localeCompare(b.s));
  }
  if(!list.length){ return html+'<div class="meta">Nothing matches this filter.</div>'; }
  const byWeek=new Map();
  list.forEach(ev=>{ const k=weekStartOf(ev.s).getTime(); if(!byWeek.has(k)) byWeek.set(k,[]); byWeek.get(k).push(ev); });
  let nextShown=false;
  [...byWeek.keys()].sort((a,b)=>a-b).forEach(wk=>{
    const ws=new Date(wk); const we=new Date(wk); we.setDate(we.getDate()+6);
    html+='<div class="calweek"><div class="meta" style="text-transform:uppercase;letter-spacing:.06em;margin-bottom:8px">'
      +ws.toLocaleDateString('en-AU',{month:'short',day:'numeric'})+' – '+we.toLocaleDateString('en-AU',{month:'short',day:'numeric'})+'</div>';
    byWeek.get(wk).forEach(ev=>{
      const st=statusFor(ev), tgt=isTarget(ev), sel=state.evsel===evKey(ev);
      const isNext=!nextShown&&st.state==='upcoming'; if(isNext) nextShown=true;
      html+='<div class="calrow'+(st.state==='past'?' past':'')+(sel?' sel':'')+(tgt?' target':'')+'"'+(tgt?' data-action="selev" data-ev="'+esc(evKey(ev))+'"':'')+'>'
        +'<span class="swatch" style="background:'+CAT_COLOR[ev.cat]+';flex:0 0 auto"></span>'
        +'<div style="min-width:0;flex:1">'
        +'<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><span style="color:#fff;font-family:Prompt,sans-serif;font-weight:600">'+esc(ev.n)+'</span>'
        +(sel?'<span class="calbadge selb">selected</span>':'')
        +(isNext?'<span class="calbadge next">up next</span>':'')
        +(tgt?'<span class="calbadge tgt">target</span>':'<span class="calbadge ctx">context</span>')
        +(ev.src==='custom'?'<span class="calbadge" style="background:var(--panel2)">custom</span>'+(isAdmin()?' <span data-action="delcustomev" data-ev="'+esc(evKey(ev))+'" title="remove this event" style="cursor:pointer;color:var(--red);font-size:13px">✕</span>':''):(ev.src==='iracing'?'<span class="calbadge" style="background:var(--panel2)">iRacing</span>':''))+'</div>'
        +(ev.series?'<div class="meta">'+esc(ev.series)+' · round '+esc(ev.round)+'</div>':'')
        +'<div class="meta">'+esc(ev.track)+(ev.dur?' · '+ev.dur+'h':'')+'</div></div>'
        +'<div style="text-align:right;flex:0 0 auto"><div class="meta" style="color:#fff">'+(ev.tbd?'TBD':fmtDates(ev.s,ev.e))+'</div>'
        +'<div class="meta">'+(st.state==='live'?'<span style="color:var(--green)">live now</span>':st.state==='past'?'completed':(ev.tbd?'':'in '+st.label+'d'))+'</div></div>'
        +'</div>';
    });
    html+='</div>';
  });
  if(fullCount>list.length || _calAll){
    html+='<div style="margin:10px 0 0"><button class="quickbtn avfree" data-action="calall">'
      +(_calAll?'Show less':'Show the full calendar ('+fullCount+' events)')+'</button></div>';
  }
  html+='<div class="meta" style="margin:6px 0 0">Click a <b style="color:var(--yellow)">target</b> event to select it — the whole plan (availability, drivers, teams, stints) follows the selected event. Context events are shown for awareness only.</div>';
  return html;
}

/* ===== Weekly update (admin only) =====================================================
   Two deliberately separate steps:
     weeklyFacts()  -> a structured object: what is on this week, where, and who races it
     weeklyDraft()  -> turns that into pasteable text
   The split is the point. The facts are the part a WordPress plugin can actually get right;
   the voice is not something PHP can invent, so the draft is a skeleton an admin finishes.
   When the Claude API step is wired in it consumes weeklyFacts() and replaces weeklyDraft()
   only — nothing else has to move. */
let _wkMsg='', _wkDraft='', _wkErr=false, _wkAI=false;
/* The generated draft is a starting point, not the thing that goes out: the write-up is copied
   out, edited and added to somewhere else, then pasted back. _wkFinal is that pasted-back
   version, and it is deliberately NOT the same box as the draft — Generate rewrites _wkDraft
   from scratch, and an accidental click on it must never be able to destroy the edited copy.
   Empty means "nothing pasted yet", in which case the draft posts as-is. */
let _wkFinal='', _wkFinalAt=0;
/* The server's copy of the last stored post, offered as a restore rather than pre-loaded, and
   whether the database gave it back intact (see cacheDraft — a 3-byte-utf8 column eats emoji). */
let _wkStored=null, _wkStripped=false;
let _wkCat='all', _wkQ='';   /* pick-list discipline filter and search, display only */
/* Exactly what a Post to Discord would send, from either box. Also what gets cached
   server-side, so the scheduled job posts the edited version and not the raw draft. */
function wkPostText(){ return (_wkFinal&&_wkFinal.trim()) ? _wkFinal : _wkDraft; }
/* Discord hard-limits one message to 2000 characters and the server splits on blank lines at a
   1900-BYTE budget (edr_tb_discord_chunks — strlen counts bytes, and an emoji is four of them).
   This is a line-for-line port of that function so the count on screen is the number of messages
   the team will actually receive, not an estimate of it. */
const WK_LIMIT=1900;
function wkBytes(s){
  if(typeof TextEncoder==='undefined') return String(s).length;
  if(!wkBytes._e) wkBytes._e=new TextEncoder();
  return wkBytes._e.encode(String(s)).length;
}
/* mirrors edr_tb_split_utf8: cut on character boundaries, measure in bytes */
function wkSplitUtf8(s, limit){
  const out=[]; let cur='', len=0;
  Array.from(String(s)).forEach(function(ch){      // by code point, like preg_split('//u')
    const n=wkBytes(ch);
    if(len+n>limit){ out.push(cur); cur=''; len=0; }
    cur+=ch; len+=n;
  });
  if(cur!=='') out.push(cur);
  return out;
}
function wkChunks(text){
  const t=String(text||'').replace(/\r\n|\r/g,'\n');
  /* split KEEPING the separators: the wider gap above a section heading is part of the layout,
     and rejoining everything with a flat '\n\n' flattens it back out */
  const parts=t.split(/(\n{2,})/);
  const out=[]; let cur='', sep='\n\n';
  parts.forEach(function(part,i){
    if(i%2===1){ sep=(part.length>3)?'\n\n\n':part; return; }   // at most one extra blank line
    const p=part.replace(/\s+$/,''); if(p==='') return;
    if(wkBytes(p)>WK_LIMIT){
      p.split('\n').forEach(function(line){
        const pieces=(wkBytes(line)>WK_LIMIT)?wkSplitUtf8(line,WK_LIMIT):[line];
        pieces.forEach(function(piece){
          if(cur!=='' && wkBytes(cur)+wkBytes(piece)+1>WK_LIMIT){ out.push(cur); cur=''; }
          cur+=(cur===''?'':'\n')+piece;
        });
      });
      return;
    }
    let join=(cur==='')?'':sep;
    if(cur!=='' && wkBytes(cur)+join.length+wkBytes(p)>WK_LIMIT){ out.push(cur); cur=''; join=''; }
    cur+=join+p;
  });
  if(cur.trim()!=='') out.push(cur);
  return out;
}
function wkChunkCount(text){ return wkChunks(text).length; }

/* ---- Preview -------------------------------------------------------------------------------
   Posting is one click that reaches everybody at once and cannot be taken back, so it goes
   through here first. The value is not decoration: it renders the same markdown subset Discord
   does, which is the only way to see before sending that a ** never closed, that a heading lost
   its space and is showing as a literal #, or that the post is about to arrive as three
   messages split in a place nobody would choose. */
function wkInline(s){
  return String(s)
    .replace(/`([^`\n]+)`/g,'<code>$1</code>')
    .replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>')
    .replace(/__([^_\n]+)__/g,'<u>$1</u>')
    .replace(/~~([^~\n]+)~~/g,'<s>$1</s>')
    .replace(/\*([^*\n]+)\*/g,'<em>$1</em>');
}
function wkMdToHtml(text){
  const lines=String(text||'').replace(/\r\n|\r/g,'\n').split('\n');
  const out=[]; let quote=[], list=[];
  const flushQuote=function(){ if(quote.length){ out.push('<blockquote>'+quote.join('<br>')+'</blockquote>'); quote=[]; } };
  const flushList =function(){ if(list.length){ out.push('<ul>'+list.map(function(li){return '<li>'+li+'</li>';}).join('')+'</ul>'); list=[]; } };
  lines.forEach(function(raw){
    const body=esc(raw);                                  // escape first: this is pasted-in text
    if(/^>\s?/.test(raw)){ flushList(); quote.push(wkInline(body.replace(/^&gt;\s?/,''))); return; }
    flushQuote();
    if(/^- /.test(raw)){ list.push(wkInline(body.replace(/^- /,''))); return; }   // -# is not a bullet
    flushList();
    if(raw===''){ out.push('<div class="gap"></div>'); return; }
    if(/^-# /.test(raw)){ out.push('<p class="sub">'+wkInline(body.replace(/^-# /,''))+'</p>'); return; }
    const h=raw.match(/^(#{1,3}) /);
    if(h){ const n=h[1].length; out.push('<h'+n+'>'+wkInline(body.replace(/^#{1,3} /,''))+'</h'+n+'>'); return; }
    out.push('<p>'+wkInline(body)+'</p>');
  });
  flushQuote(); flushList();
  return out.join('');
}
let _wkPrevEl=null;
function wkClosePreview(){
  if(_wkPrevEl&&_wkPrevEl.parentNode) _wkPrevEl.parentNode.removeChild(_wkPrevEl);
  _wkPrevEl=null;
  document.removeEventListener('keydown', _wkPrevKey);
}
function _wkPrevKey(e){ if(e.key==='Escape') wkClosePreview(); }
function wkOpenPreview(){
  if(!isAdmin()) return;
  /* read the boxes, not the globals: text pasted a keystroke ago has not cleared the debounce,
     and previewing something other than what Post would send defeats the point */
  const fin=document.getElementById('wkfinal'), dr=document.getElementById('wkdraft');
  if(fin) _wkFinal=fin.value||'';
  if(dr && (dr.value||'').trim()) _wkDraft=dr.value;
  const text=wkPostText();
  if(!text.trim()){ _wkMsg='Nothing to preview — generate the draft, or paste your version into the final box.'; _wkErr=true; renderContent(); return; }
  wkClosePreview();
  const chunks=wkChunks(text);
  const src=_wkFinal.trim()?'the final box':'the generated draft';
  let h='<div class="wkprev" role="dialog" aria-modal="true" aria-label="Preview the Discord post">';
  h+='<div class="wkprev-head"><div class="head" style="font-size:15px;color:#fff;text-transform:uppercase">Preview</div>'
    +'<span class="meta" style="font-size:10.5px">This is '+src+', rendered the way Discord will render it'
    +(chunks.length>1?(' — it is over the 2000-character limit, so it arrives as <b style="color:var(--yellow)">'+chunks.length+' separate messages</b>'):'')+'.</span></div>';
  /* The write-up is edited outside the builder, so the two markers that misfire in Discord can
     come back in at any time. Say so here rather than after the whole team has seen it. */
  const risky=[];
  const lines=text.replace(/\r\n|\r/g,'\n').split('\n');
  if(lines.some(function(l){ return /^-#\s/.test(l); }))
    risky.push('<b>-# subtext</b> — on a Discord client without subtext support this renders as a <b>large heading</b>, which flips the line from the quietest thing in the entry to the loudest. Use <b>*italics*</b> instead.');
  if(lines.some(function(l){ return /^#\s/.test(l); }))
    risky.push('<b># heading</b> — Discord\'s H1 is enormous next to body text. Use <b>##</b> for the title and <b>###</b> for sections.');
  if(risky.length){
    h+='<div style="padding:10px 18px;border-bottom:1px solid var(--lineSoft)">';
    risky.forEach(function(r){ h+='<div class="meta" style="font-size:10.5px;color:var(--red)">'+r+'</div>'; });
    h+='</div>';
  }
  h+='<div class="wkprev-body">';
  chunks.forEach(function(c,i){
    if(chunks.length>1) h+='<div class="wkprev-n">Message '+(i+1)+' of '+chunks.length+' · '+wkBytes(c)+' bytes</div>';
    h+='<div class="wkmsg">'+wkMdToHtml(c)+'</div>';
  });
  h+='</div>';
  h+='<div class="wkprev-foot">'
    +'<button class="btn btn-amber avfree" data-action="wkpost">Post to Discord</button>'
    +'<button class="quickbtn avfree" data-action="wkprevclose">Back to editing</button>'
    +'<span class="meta" style="font-size:10.5px;margin-left:auto">'+text.length+' characters · '+wkBytes(text)+' bytes</span>'
    +'</div></div>';
  const el=document.createElement('div');
  el.className='wkprev-scrim';
  el.innerHTML=h;
  el.addEventListener('click',function(e){
    if(e.target===el){ wkClosePreview(); return; }            // click the scrim to dismiss
    const a=e.target.dataset&&e.target.dataset.action;
    if(a==='wkprevclose') wkClosePreview();
    else if(a==='wkpost'){ wkClosePreview(); postDraftToDiscord(); }
  });
  (document.getElementById('edr-tb-app')||document.body).appendChild(el);
  _wkPrevEl=el;
  document.addEventListener('keydown', _wkPrevKey);
}
function catLabel(c){
  const m={'sports_car':'Sports car','formula_car':'Formula','oval':'Oval','dirt_oval':'Dirt oval','dirt_road':'Dirt road','road':'Road'};
  return m[c]||cap(String(c||'').replace(/_/g,' '));
}
function weeklyState(){
  if(!state.weekly) state.weekly={pick:{}, track:{}, driver:{}, flare:true, scope:'next'};
  const w=state.weekly;
  /* `pick` holds ONLY explicit admin choices. It used to bulk-seed every known series on first
     open, which meant a stored `false` for everything outside the top twelve — indistinguishable
     from a deliberate untick, so the defaults could never change afterwards. Endurance rounds
     defaulting on (the point being to advertise the endurance calendar) had no effect on any
     install that had already been opened once. Defaults are computed fresh in weeklyPickList();
     only what an admin actually clicked is stored. */
  if(!w.pick) w.pick={};
  /* Which race week the draft covers. 'next' is the default and the tab's real job — the week
     ahead — but an admin drafting mid-week sometimes wants the week already under way, and on a
     Tuesday afternoon the "next" week is six days out. Anything unset or unrecognised normalises
     to 'next' so an older stored plan opens on the documented default. */
  if(w.scope!=='this') w.scope='next';
  return w;
}
/* iRacing season names carry the season and the sponsor ("iRacing Porsche Cup by CONSPIT -
   2026 Season 3"), the popularity report does not. Strip both ends before comparing. */
function seriesKey(n){
  return String(n||'').toLowerCase()
    .replace(/\s*[-–]\s*20\d\d\s*season\s*\d.*$/,'')
    .replace(/\s+(by|presented by|powered by)\s+[a-z0-9 .\-]+$/,'')
    .replace(/[^a-z0-9]+/g,' ').trim();
}
function trackNoteFor(track){
  const t=String(track||'').toLowerCase(), w=weeklyState();
  const all=Object.assign({}, TRACK_NOTES, w.track||{});
  const hit=Object.keys(all).find(function(k){ return t.indexOf(k)>=0; });
  return hit?all[hit]:'';
}
/* `used` lets the caller stop the same person being the colour on four different series in one
   write-up — the second mention adds nothing and reads like a copy-paste error. */
function driverNoteFor(names, used){
  const w=weeklyState(); if(!w.flare) return null;
  const all=Object.assign({}, DRIVER_NOTES, w.driver||{});
  const list=(names||[]);
  const hit=list.find(function(n){ return all[n] && !(used&&used[n]); }) || null;
  if(!hit) return null;
  if(used) used[hit]=1;
  return {name:hit, note:all[hit]};
}
/* Live team history (WordPress only — HISTORY is filled from GET /history; undefined in the
   standalone build, so every helper below quietly returns nothing there and the draft keeps its
   seeded/hand-written content). All of it degrades honestly: a win or podium count only prints
   when the proxy actually carried finish positions (HISTORY.fields.pos). */
function haveHistory(){ return typeof HISTORY!=='undefined' && HISTORY && HISTORY.tracks; }
/* Config-insensitive, accent-folded — must match edr_tb_hist_track_key() in history.php. */
function histTrackKey(name){
  return String(name||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'');
}
/* "EDR here: 23 starts, 3 wins, 5 podiums (best 2nd, Sam Millar)" for a round's track, or ''. */
function histTrackLine(track){
  if(!haveHistory() || !track) return '';
  const t=HISTORY.tracks[histTrackKey(track)];
  if(!t || !t.races) return '';
  const pos=!!(HISTORY.fields && HISTORY.fields.pos);
  const bits=['EDR here: '+t.races+' start'+(t.races===1?'':'s')];
  if(pos && t.wins) bits.push(t.wins+' win'+(t.wins===1?'':'s'));
  if(pos && t.podiums) bits.push(t.podiums+' podium'+(t.podiums===1?'':'s'));
  let s=bits.join(', ');
  if(pos && t.bestLabel && t.bestBy) s+=' (best '+t.bestLabel+', '+t.bestBy+')';
  return s;
}
/* The drivers on the team who actually race this series, from the history sweep (TEAM_SERIES is
   re-keyed by the client's own seriesKey, so this joins the schedule name cleanly). null when the
   sweep found none — which is the signal to say nothing rather than reach for a seeded name. */
function histSeriesDrivers(label){
  if(typeof TEAM_SERIES==='undefined' || !TEAM_SERIES || !label) return null;
  const a=TEAM_SERIES[seriesKey(label)];
  return (a && a.length) ? a : null;
}
/* A driver's own record is only worth a line if there is something to it — a win, a podium, or a
   real body of starts. "1 start, best 8th" is noise, so it is not counted as flare-worthy. */
function flareStatWorthy(d){ return d.wins>0 || d.podiums>0 || d.races>=5; }
function flareStatNote(d){
  const pos=!!(HISTORY.fields && HISTORY.fields.pos);
  let note=d.races+' start'+(d.races===1?'':'s');
  if(pos){ if(d.wins) note+=', '+d.wins+' win'+(d.wins===1?'':'s'); else if(d.podiums) note+=', '+d.podiums+' podium'+(d.podiums===1?'':'s'); else if(d.bestLabel && d.best!==null) note+=', best '+d.bestLabel; }
  return note;
}
/* Pick the best unused driver from a list: one we have a personality line for first, then one whose
   own record says something. null if neither. */
function flarePick(list, used, notes){
  const free=(list||[]).filter(function(x){ return !(used&&used[x.name]); });
  return free.find(function(x){ return !!notes[x.name]; }) || free.find(flareStatWorthy) || null;
}
/* A driver mention for a round, kept honest with the "EDR here" line above it. If the team has
   history at this track, the mention comes from THAT track — never a series regular who has raced
   the series elsewhere but never here (which is how "EDR here: Zach" ended up next to "one for
   Fred"). As a last resort it names the track's own standout (the driver in the EDR-here line),
   even if already used, so the two lines always agree rather than the flare going off-track. Only a
   round with no track history at all falls back to who races the series. Standalone build (no
   history pulled) keeps the hand-written notes. */
function flareFor(who, used, track, seriesLabel){
  const w=weeklyState(); if(!w.flare) return null;
  if(!haveHistory()) return driverNoteFor(who, used);
  const notes=Object.assign({}, DRIVER_NOTES, w.driver||{});
  const t = track ? HISTORY.tracks[histTrackKey(track)] : null;
  if(t && t.drivers && t.drivers.length){
    let d=flarePick(t.drivers, used, notes);
    if(!d && t.bestBy){ d=t.drivers.find(function(x){ return x.name===t.bestBy; }) || null; }  // the EDR-here driver, even if used
    if(!d) return null;
    if(used) used[d.name]=1;
    return {name:d.name, note:notes[d.name] || flareStatNote(d)};
  }
  /* no EDR history at this track — a series regular is the relevant mention, and there is no
     "EDR here" line to disagree with */
  const d=flarePick(histSeriesDrivers(seriesLabel), used, notes);
  if(!d) return null;
  if(used) used[d.name]=1;
  return {name:d.name, note:notes[d.name] || flareStatNote(d)};
}
/* Everything the write-up is built from. Endurance and specials lead, because that is the bit
   the team most needs telling about; sprints follow, one per selected series. */
/* The week the write-up covers is an iRacing race week, which ticks over at Tuesday 00:00
   UTC — 10:00 Brisbane year-round, 10:00 or 11:00 Melbourne depending on daylight saving.
   Returned as ISO date strings and compared as strings — iRacing start_date is a plain
   YYYY-MM-DD, and mixing that with local-midnight timestamps skews the window by hours in
   Brisbane and can drop or double-count a round at the boundary. */
function isoDayUTC(ms){ return new Date(ms).toISOString().slice(0,10); }
/* Race length is the honest split between an endurance round and a sprint: the endurance
   series run 90 minutes and up, the sprints 12 to 45. Series names are not reliable — plenty
   of sprint series have "Challenge" or a track famous for enduros in the name. */
const ENDURO_MIN=90;
/* An event further out than this gets the "start practising" nudge in the write-up. */
const PRACTICE_NUDGE_DAYS=21;
/* iRacing season names carry the season on the end ("IMSA Endurance Series - 2026 Season 3").
   Fine as a key, ugly in a write-up. */
function prettySeriesName(n){
  return String(n||'').replace(/\s*[-–]\s*20\d\d\s*season\s*\d?.*$/i,'').replace(/\s*[-–]\s*20\d\d\s*$/,'').trim();
}
/* Does this name look like a recurring series rather than a one-off major? Used only to keep
   synced iRacing series out of the specials list; the live `rounds` count is preferred where
   we have it. */
function isRecurringSeries(n){
  return /series|challenge|championship|tour|cup|league/i.test(String(n||''));
}
function isTeamSeries(n){
  return /\bnec\b|nurburgring endurance|nürburgring endurance|endurance championship/i.test(String(n||''));
}
/* Is this calendar event and this live round the same race? Track and date, loosely — enough
   to stop "Creventic Round 3 — 12H Barcelona" and "Creventic Endurance Series" both printing. */
function sameRace(ev, r){
  /* fold accents first: the calendar says "Nürburgring" and iRacing says "Nurburgring", and
     stripping non-alphanumerics alone leaves "nrburgring" vs "nurburgring" — never equal */
  const nk=function(s){ return String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^a-z0-9]/g,''); };
  const a=nk(ev.track), b=nk(r.track);
  if(!a||!b) return false;
  const trackHit = a.indexOf(b.slice(0,10))>=0 || b.indexOf(a.slice(0,10))>=0;
  if(!trackHit) return false;
  const d1=Date.parse(ev.s+'T00:00:00Z'), d2=Date.parse((r.start_date||'')+'T00:00:00Z');
  if(isNaN(d1)||isNaN(d2)) return false;
  return Math.abs(d1-d2) <= 4*86400000;
}
/* Anchored on iRacing's own Tuesday tick rather than on a local Monday. The old version took
   this week's Monday and added seven days, which lands on the Tuesday EIGHT days out whenever
   the draft is generated on a Monday — the write-up then described the week after the one
   everybody was about to race. It only read correctly Wed–Sun, which is why the Sunday cron
   never showed it. Done in UTC so the window does not shift with whose browser generated it. */
function draftWeekWindow(){
  const now=new Date();
  let ahead=(2 - now.getUTCDay() + 7) % 7;                 // 2 = Tuesday
  /* on a Tuesday the 00:00 UTC tick has already gone, so the next week is a full seven days
     out — without this the draft re-announces a week that is already under way */
  if(ahead===0) ahead=7;
  let start=Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()+ahead);
  /* "this week" steps back to the tick that has already passed: the week being raced right now */
  if(weeklyState().scope==='this') start-=7*86400000;
  return {from:isoDayUTC(start), to:isoDayUTC(start+6*86400000)};
}
function inDraftWeek(startDate){
  const w=draftWeekWindow(), d=String(startDate||'');
  return d>=w.from && d<=w.to;
}
/* "next week" / "this week", for headings and draft lines that have to agree with the toggle. */
function draftWeekWord(){ return weeklyState().scope==='this' ? 'this week' : 'next week'; }
function weeklyFacts(){
  /* The live schedule is the source of truth for what is on. IR_WEEKS comes straight from the
     iRacing API (every official round in the next fortnight); the baked WEEKLY_SERIES list is
     only a fallback for who-races-what and ordering until the live team data has been pulled. */
  const weeks=(typeof IR_WEEKS!=='undefined' && Array.isArray(IR_WEEKS)) ? IR_WEEKS : [];
  const w=weeklyState();
  const now=Date.now();
  const win=draftWeekWindow();
  const known={}; WEEKLY_SERIES.forEach(function(s){ known[seriesKey(s.n)]=s; });

  /* only rounds that actually start in the drafted week */
  const rounds=weeks.filter(function(r){ return inDraftWeek(r.start_date); });

  /* one source for "is this series in": the same list the tick boxes render from, so the draft
     can never disagree with what the admin sees ticked */
  const picked={}; weeklyPickList().forEach(function(p){ if(p.on) picked[p.key]=p; });

  const sprints=[], usedDrivers={};
  rounds.forEach(function(r){
    const k=seriesKey(r.series);
    if(!picked[k]) return;
    if((r.race_min||0) >= ENDURO_MIN || r.team) return;   // handled in the endurance section
    const seed=known[k]||null;                       // team history for this series, if we have it
    const label=picked[k].label;
    const who=teamRunners(k, seed);
    sprints.push({
      series:label, cat:seed?seed.cat:'', starts:seed?seed.st:0, who:who,
      cars:(r.cars&&r.cars.length)?r.cars:[],   // live car classes for the round, from iRacing
      carsWeek:(r.carsWeek!==false), raceLaps:r.race_laps||0,
      track:r.track||'', raceMin:r.race_min||0, sessions:r.sessions||[],
      when:raceTimePattern(r), times:sessionTimeList(r,4), firstRaw:r.firstRaw||'', repeatRaw:r.repeat||0,
      matched:!!r.track, note:trackNoteFor(r.track), flare:flareFor(who, usedDrivers, r.track, label), hist:histTrackLine(r.track),
      startDate:r.start_date
    });
  });
  sprints.sort(function(a,b){ return (b.starts||0)-(a.starts||0) || a.series.localeCompare(b.series); });

  /* Specials: the one-off majors and anything the team has flagged as a target, four weeks
     out from the start of the drafted week. These come from the season calendar rather than iRacing
     because that is where EDR's own entries and round numbering live. */
  const horizon=isoDayUTC(Date.parse(win.from+'T00:00:00Z')+28*86400000);
  const specials=calendar().filter(function(ev){
    if(ev.cat!=='endurance' && !ev.special && !isTarget(ev)) return false;
    if((ev.e||ev.s) < win.from) return false;          // finished before the drafted week begins
    if(ev.s > horizon) return false;
    /* A recurring series synced in from iRacing is not a "special" — it belongs in the
       endurance list below, once, rather than filling this section with one row per future
       week. That is what turned the first draft into twenty-two lines of GT3. */
    return !(ev.src==='iracing' && isRecurringSeries(ev.n));
  }).sort(function(a,b){ return a.s.localeCompare(b.s); });

  /* Regular scheduled endurance — the weekly and fortnightly series, from the live schedule,
     the drafted week's round only. Split from sprints on race length, which is the honest signal:
     these run 90 minutes and up, the sprints are 12 to 45. */
  const enduros=[];
  rounds.forEach(function(r){
    if((r.race_min||0) < ENDURO_MIN && !r.team) return;   // team events count regardless of length
    if(!picked[seriesKey(r.series)]) return;              // an unticked series must actually drop out
    const label=prettySeriesName(r.series);
    if(specials.some(function(ev){ return sameRace(ev, r); })) return;   // already led with it above
    enduros.push({
      series:label, track:r.track||'', raceMin:r.race_min||0, cars:r.cars||[],
      carsWeek:(r.carsWeek!==false), raceLaps:r.race_laps||0,
      when:raceTimePattern(r), times:sessionTimeList(r,6),
      recurring:(r.rounds||0)>3, note:trackNoteFor(r.track), startDate:r.start_date,
      hist:histTrackLine(r.track), team:isTeamSeries(label)
    });
  });
  enduros.sort(function(a,b){ return (a.startDate||'').localeCompare(b.startDate||'') || a.series.localeCompare(b.series); });

  return {
    generated:new Date().toISOString(),
    tz:tzLabel(),
    specials:specials.map(function(ev){
      const st=statusFor(ev);
      return {name:prettySeriesName(ev.n), track:ev.track, cars:ev.cars, dur:ev.dur||0, dates:fmtDates(ev.s,ev.e),
              live:st.state==='live', inDays:st.state==='live'?0:+st.label||0,
              target:isTarget(ev), note:trackNoteFor(ev.track)};
    }),
    enduros:enduros,
    week:{from:win.from, to:win.to},
    sprints:sprints,
    rounds:rounds.length,
    unmatched:sprints.filter(function(s){ return !s.matched; }).length,
    haveIracing:weeks.length>0,
    liveRunners:teamSeriesLive()
  };
}
/* Who from the team actually runs a series.
   Live first: TEAM_SERIES is built server-side from iRacing results matched to the Garage 61
   roster, so it reflects reality rather than a snapshot. The figures baked into WEEKLY_SERIES
   came from a one-off report and are only a stand-in until that pull has happened. */
function teamSeriesLive(){
  return (typeof TEAM_SERIES!=='undefined' && TEAM_SERIES && Object.keys(TEAM_SERIES).length) ? TEAM_SERIES : null;
}
function teamRunners(key, seed){
  const live=teamSeriesLive();
  if(live && live[key] && live[key].length) return live[key].map(function(x){ return x.name||x; });
  return seed?seed.who:[];
}
/* Last week's results, pulled from the iRacing proxy by a background sweep and cached
   server-side (WORDPRESS ONLY — the standalone has no proxy, so this stays empty and the
   recap section is simply omitted). */
let RECAP=null, RECAP_RUNNING=false, RECAP_ERR='', RECAP_PROG=null;
/* Season team history (per track / series / driver), pulled server-side (WORDPRESS ONLY). Declared
   here so both builds have the state and the standalone stub can write to it; the WP layer fills it
   via applyHistory() and populates TEAM_SERIES from it. */
let HISTORY=null, HIST_RUNNING=false, HIST_ERR='', HIST_PROG=null;
/* Weekly iRating/Safety Rating movement, diffed from two Garage 61 snapshots. Two HTTP calls
   rather than the multi-minute iRacing sweep, so the ratings awards never wait on it. */
let RATINGS=null;
function sgn(n){ return (n>0?'+':'')+n; }
/* Two shapes reach here: the sweep gives pre-formatted licence strings ("B 3.10"), the
   snapshot diff gives numbers plus a licence class. Render whichever we got. */
function fmtSr(d){
  if(typeof d.srStart==='string' && d.srStart) return d.srStart+' → '+d.srEnd;
  const lab=d.srLabel?d.srLabel+' ':'';
  return lab+Number(d.srStart).toFixed(2)+' → '+lab+Number(d.srEnd).toFixed(2)
       +' ('+(d.srDelta>0?'+':'')+Number(d.srDelta).toFixed(2)+')';
}
/* The awards. Deliberately computed from the same driver rows rather than pre-baked server
   side, so adding an award never needs a re-sweep of the API. */
function recapAwards(r){
  if(!r || !r.drivers || !r.drivers.length) return null;
  const raced=r.drivers.slice().filter(function(d){ return d.races>0; });
  if(!raced.length) return null;
  const byIr=raced.slice().sort(function(a,b){ return b.irDelta-a.irDelta; });
  const bySr=raced.slice().sort(function(a,b){ return b.srDelta-a.srDelta; });
  const byRaces=raced.slice().sort(function(a,b){ return b.races-a.races; });
  const byClean=raced.filter(function(d){ return d.races>=2; })
                     .sort(function(a,b){ return (a.inc/a.races)-(b.inc/b.races); });
  const winners=raced.filter(function(d){ return d.wins>0; })
                     .sort(function(a,b){ return b.wins-a.wins || b.podiums-a.podiums; });
  /* iRating and SR awards come from the recap — the actual iRacing race results, which are
     authoritative and current. The Garage 61 ratings snapshot is deliberately NOT used here: it
     lags iRacing badly (a real pull showed 28 of 30 drivers unchanged in a week the results say
     ~20 moved, and its per-driver values contradicted the races), so folding it in hid the real
     movers and named the wrong ones. The snapshot survives only as the Weekly-tab FYI line. */
  const rIr = byIr, rSr = bySr;
  return {
    ratingsLive: true,
    top3:      rIr.filter(function(d){ return d.irDelta>0; }).slice(0,3),
    improved:  (rIr[0] && rIr[0].irDelta>0) ? rIr[0] : null,
    lost:      (rIr[rIr.length-1] && rIr[rIr.length-1].irDelta<0) ? rIr[rIr.length-1] : null,
    srUp:      (rSr[0] && rSr[0].srDelta>0) ? rSr[0] : null,
    srDown:    (rSr[rSr.length-1] && rSr[rSr.length-1].srDelta<0) ? rSr[rSr.length-1] : null,
    busiest:   byRaces[0]||null,
    cleanest:  byClean[0]||null,
    winners:   winners.slice(0,3),
    starts:    raced.reduce(function(t,d){ return t+d.races; },0),
    drivers:   raced.length
  };
}
function recapAgeLabel(){
  if(RECAP_ERR) return RECAP_ERR;
  if(RECAP_RUNNING){
    const p=RECAP_PROG;
    if(p && p.total) return (p.stage==='drivers'?'searching drivers':'fetching races')+' — '+p.done+' of '+p.total;
    return 'starting the results pull…';
  }
  if(!RECAP||!RECAP.at) return 'no results pulled yet — the recap section is left out until you do';
  const d=RECAP.drivers?RECAP.drivers.length:0;
  return 'last pulled '+relTime(new Date(RECAP.at*1000).toISOString().replace('T',' ').slice(0,19))
       +' · '+d+' driver'+(d===1?'':'s')+', '+(RECAP.races||0)+' race'+((RECAP.races||0)===1?'':'s')
       +((RECAP.dropped)?' · '+RECAP.dropped+' not fetched (run capped)':'');
}
/* Freshness line for the team-history sweep, mirroring recapAgeLabel(). */
function histAgeLabel(){
  if(typeof HIST_ERR!=='undefined' && HIST_ERR) return HIST_ERR;
  if(typeof HIST_RUNNING!=='undefined' && HIST_RUNNING){
    const p=(typeof HIST_PROG!=='undefined')?HIST_PROG:null;
    if(p && p.total) return 'searching drivers — '+p.done+' of '+p.total;
    return 'starting the history pull…';
  }
  if(!haveHistory() || !HISTORY.at) return 'no team history yet — "EDR here" lines and earned mentions stay off until you pull it';
  const nd=(HISTORY.drivers?HISTORY.drivers.length:0);
  return 'last pulled '+relTime(new Date(HISTORY.at*1000).toISOString().replace('T',' ').slice(0,19))
       +' · last '+(HISTORY.days||90)+' days · '+nd+' driver'+(nd===1?'':'s')+', '+(HISTORY.races||0)+' race'+((HISTORY.races||0)===1?'':'s')
       +((HISTORY.fields && !HISTORY.fields.pos)?' · positions not in feed — starts only':'');
}
/* When a repeating series actually goes green, as minutes past the hour — the thing people
   need in order to plan an evening ("on the :00 and :30"). Computed in the viewer's own
   timezone, because zones on a half-hour offset (Adelaide, India) shift the minute. */
function localMinute(ms){
  try{ return +new Date(ms).toLocaleString('en-AU',{timeZone:tzZone(),minute:'2-digit'}); }
  catch(e){ return new Date(ms).getMinutes(); }
}
function pad2(n){ return (n<10?'0':'')+n; }
/* "a, b and c" — chaining "and" four times reads like a child's list */
function andList(a){
  if(!a||!a.length) return '';
  if(a.length===1) return a[0];
  return a.slice(0,-1).join(', ')+' and '+a[a.length-1];
}
function raceTimePattern(r){
  const first=Date.parse(r.first||(r.sessions&&r.sessions[0])||'');
  const rep=+(r.repeat||0);
  if(isNaN(first)||!rep) return '';
  const m0=localMinute(first);
  if(rep<60 && 60%rep===0){                      // several a hour: list every offset
    const outs=[];
    for(let m=m0%rep, n=0; n<60/rep; n++, m+=rep) outs.push(':'+pad2(m%60));
    return 'on the '+andList(outs);
  }
  if(rep===60) return 'on the :'+pad2(m0)+', every hour';
  /* A two-hourly series always starts on the same hour parity, and "every 2 hours" leaves you
     working out which two. Say it: "on the :00, even hours". Parity is taken from the local
     hour, so a viewer on a half-hour offset zone still gets their own clock. */
  if(rep===120) return 'on the :'+pad2(m0)+', '+((localHour(first)%2===0)?'even':'odd')+' hours';
  if(rep%60===0){
    const h=localHour(first), every=rep/60;
    return 'every '+every+' hours from '+pad2(h)+':'+pad2(m0);
  }
  return 'every '+rep+' min from :'+pad2(m0);
}
/* Explicit session starts, for the fixed-schedule rounds where there is no repeat — the
   endurance and special events, where the actual green flag is the whole point. */
function sessionTimeList(r, max){
  const ss=(r.sessions||[]).slice();
  if(!ss.length) return '';
  const seen={}, out=[];
  ss.forEach(function(t){
    const ms=Date.parse(t); if(isNaN(ms)) return;
    const lbl=new Date(ms).toLocaleString('en-AU',{timeZone:tzZone(),weekday:'short',hour:'2-digit',minute:'2-digit',hour12:false});
    if(seen[lbl]) return; seen[lbl]=1; out.push(lbl);
  });
  if(!out.length) return '';
  const cap=max||6;
  return out.length>cap ? out.slice(0,cap).join(', ')+' (+'+(out.length-cap)+' more)' : out.join(', ');
}
function cap(s){ s=String(s||''); return s.charAt(0).toUpperCase()+s.slice(1); }
/* "3h" reads better than "180 min" for an enduro, "20 min" better than "0.33h" for a sprint */
function fmtRaceLen(m){
  if(!m) return '';
  if(m>=90 && m%60===0) return (m/60)+'h';
  if(m>=90) return Math.floor(m/60)+'h '+(m%60)+'m';
  return m+' min';
}
/* Race length, from whichever limit the round actually has. Lap-limited rounds — Ring Meister,
   both cup cars, most ovals — carry no race_time_limit at all, so reading only the minutes left
   them looking like rounds of unknown length when the schedule had said "2 laps" all along. */
function fmtRaceDist(min, laps){
  if(min) return fmtRaceLen(min);
  laps=laps||0;
  return laps ? (laps+' lap'+(laps===1?'':'s')) : '';
}
function weeklyDraft(f){
  /* Markdown, because the draft is posted straight into Discord — which renders #/##
     headings, bold and block quotes — and still reads fine as plain text if it is pasted
     anywhere else. Keep lines short: Discord wraps narrow on mobile.

     House layout, applied to every section so the whole post scans the same way:
       ## title     once, at the top
       ### heading  one per section — the only headings in the body, and the only emoji
       **Name**     the subject of an entry, alone on its line
       plain line   the facts that decide whether you care (track, car, length, when)
       *italic*     the quiet supporting stuff (history, session times, warnings, flare)
       > quote      the human note
       blank line   between entries; two above a section heading. That spacing IS the
                    formatting in Discord, and it is where the chunker prefers to split.

     Two rules learned the hard way, both from what the team actually saw:

     **No `-#`.** It is Discord's subtext marker on a current client, but a client without
     subtext support parses `-#` as a list item whose content is `# heading` — so the quietest
     line in an entry (the car list) rendered as the biggest thing on screen while the event
     name above it looked like a caption. Every other marker here fails safe: an unsupported
     `**` shows literal asterisks. `-#` fails by inverting the hierarchy, which is worse than
     no styling at all, so the quiet lines are italic instead.

     **Headings start at `##`, not `#`.** Discord's H1 is enormous next to body text; with one
     per section the post read as a stack of banners.

     Emoji are rationed to the headings and the top-three medals. Sprinkled through the body
     they stop reading as signal and the write-up looks like a newsletter. */
  const L=[];
  L.push('## 🏁 This week in iRacing');
  L.push('*Week of '+f.week.from+' to '+f.week.to+' · times in '+f.tz+'*');
  L.push('');

  /* Recap first: people read the week they just had before the week they are about to have. */
  const aw=recapAwards(RECAP);
  if(aw){
    L.push('### 📊 Last week');
    if(aw.starts) L.push('**'+aw.drivers+'** driver'+(aw.drivers===1?'':'s')+' started **'+aw.starts+'** official race'+(aw.starts===1?'':'s')+'.');
    L.push('');
    if(aw.top3.length){
      L.push('**Top three on iRating**');
      /* medals rather than "1." / "2." / "3.": Discord turns a numbered list into its own
         indented block, which reads as a nested aside instead of the headline result */
      const MEDAL=['🥇','🥈','🥉'];
      aw.top3.forEach(function(d,i){
        let ln=(MEDAL[i]||'•')+' **'+d.name+'** `'+sgn(d.irDelta)+'`'+(d.irEnd?' → '+d.irEnd:'');
        if(d.races){                       // race counts only exist if the results sweep ran
          ln+=' — '+d.races+' race'+(d.races===1?'':'s')
             +(d.wins?', '+d.wins+' win'+(d.wins===1?'':'s'):'')
             +(!d.wins&&d.podiums?', '+d.podiums+' podium'+(d.podiums===1?'':'s'):'');
        }
        L.push(ln);
      });
      L.push('');
    }
    const bits=[];
    if(aw.improved) bits.push('**Most improved** — '+aw.improved.name+' `'+sgn(aw.improved.irDelta)+'`');
    if(aw.lost)     bits.push('**Took one for the team** — '+aw.lost.name+' `'+sgn(aw.lost.irDelta)+'`, it happens');
    if(aw.srUp)     bits.push('**Safety rating climb** — '+aw.srUp.name+' '+fmtSr(aw.srUp));
    if(aw.srDown)   bits.push('**Safety rating slide** — '+aw.srDown.name+' '+fmtSr(aw.srDown));
    if(aw.winners.length) bits.push('**Wins** — '+aw.winners.map(function(d){ return d.name+' ('+d.wins+')'; }).join(', '));
    if(aw.busiest && aw.busiest.races>1) bits.push('**Busiest** — '+aw.busiest.name+', '+aw.busiest.races+' starts');
    if(aw.cleanest) bits.push('**Cleanest** — '+aw.cleanest.name+', '+(Math.round((aw.cleanest.inc/aw.cleanest.races)*10)/10)+'x per race');
    bits.forEach(function(b){ L.push('- '+b); });
    L.push('');
  }

  L.push('### ⭐ Special events — next four weeks');
  if(!f.specials.length) L.push('*Nothing on the EDR calendar in the next four weeks.*');
  f.specials.forEach(function(e){
    const when=e.live?'**live now**':('in '+e.inDays+' day'+(e.inDays===1?'':'s'));
    L.push('**'+e.name+'**'+(e.target?' · *EDR target*':''));
    L.push(e.track+(e.dur?' · '+e.dur+'h':'')+' · '+e.dates+' · '+when);
    if(e.cars) L.push(e.cars);
    if(e.note) L.push('> '+cap(e.note)+'.');
    /* far enough out that there is still runway to build up to it — that is the moment the
       nudge is useful, not the week before when it is already too late to start */
    if(!e.live && e.inDays>PRACTICE_NUDGE_DAYS) L.push('**It\'s time to start practising.**');
    L.push('');
  });

  L.push('### ⏱️ Endurance — on '+draftWeekWord());
  if(!f.enduros.length) L.push('*No endurance rounds '+draftWeekWord()+'.*');
  f.enduros.forEach(function(e){
    L.push('**'+e.series+'**'+(e.team?' · *team event*':''));
    let line=(e.track||'track TBC');
    if(e.cars&&e.cars.length) line+=' · '+e.cars.join(' / ');
    const elen=fmtRaceDist(e.raceMin, e.raceLaps);
    if(elen) line+=' · '+elen;
    L.push(line);
    if(!e.carsWeek) L.push('*Please confirm car for '+draftWeekWord()+' — the schedule did not name one for this round.*');
    if(e.hist)      L.push('*'+e.hist+'*');
    if(e.times)     L.push('Sessions: '+e.times);
    else if(e.when) L.push('Races '+e.when);
    if(e.note) L.push('> '+cap(e.note)+'.');
    L.push('');   // blank line between entries: keeps the quotes off the next heading, and
                  // gives the Discord chunker a clean place to split
  });

  L.push('### ⚡ Sprints');
  if(!f.haveIracing){
    L.push('*No live iRacing schedule — connect the proxy in plugin Settings.*');
  } else if(!f.sprints.length){
    L.push('*No rounds '+draftWeekWord()+' for the series you have ticked.*');
  }
  f.sprints.forEach(function(s){
    if(!s.matched){ L.push('**'+s.series+'**'); L.push('track TBC'); L.push(''); return; }
    L.push('**'+s.series+'**');
    let line=s.track;
    /* "in the Toyota GR86" reads well for a one-make series; "in the GTP / LMP2 / GT3" does
       not, so a multi-class round gets the classes in the bracket with the race length */
    const multi=(s.cars||[]).length>1;
    if(s.cars&&s.cars.length===1) line+=' in the '+s.cars[0];
    const bits=[];
    if(multi) bits.push(s.cars.join(' / '));
    const slen=fmtRaceDist(s.raceMin, s.raceLaps);
    if(slen) bits.push(slen);
    if(bits.length) line+=' ('+bits.join(', ')+')';
    if(s.when) line+=' — '+s.when;
    else if(s.times) line+=' — '+s.times;
    L.push(line);
    if(!s.carsWeek) L.push('*Please confirm car for '+draftWeekWord()+' — the schedule did not name one for this round.*');
    if(s.hist) L.push('*'+s.hist+'*');
    if(s.note) L.push('> '+cap(s.note)+'.');
    if(s.flare) L.push('*One for '+s.flare.name+' — '+s.flare.note+'.*');
    L.push('');
  });

  /* Sign-off, not a warning. This text is now posted verbatim to a team channel, so the old
     "edit it before it goes anywhere public" line read as an instruction to the whole team;
     the reminder to edit belongs on the tab, where the person who can act on it is looking. */
  L.push('');
  L.push('*Posted from the EDR Team Builder*');
  return wkTidy(L).join('\n');
}
/* One spacing pass over the finished draft, so the gaps do not depend on which sections
   happened to have entries. Each section emits its own trailing blank line from inside its
   loop, which means a section with nothing in it emits none at all and its "nothing on this
   week" line ends up welded to the next heading. Rather than sprinkle more L.push('') around,
   normalise once at the end: never two blank lines in a row, always exactly one above a
   heading, none trailing. It is also what gives the chunker a clean split point before every
   heading — the blank line is what edr_tb_discord_chunks() breaks on. */
function wkTidy(L){
  const out=[];
  const blanks=function(){ let n=0; for(let i=out.length-1;i>=0&&out[i]==='';i--) n++; return n; };
  L.forEach(function(ln){
    const s=String(ln==null?'':ln);
    if(s===''){ if(out.length && blanks()<1) out.push(''); return; }
    /* A section heading gets a DOUBLE gap above it and an entry gets a single one. Discord
       renders headings tight against whatever precedes them, so with one blank line everywhere
       the whole post reads as an unbroken wall — the section breaks are what make it scannable
       on a phone. `-#` is subtext, not a heading. */
    if(/^#{1,3}\s/.test(s) && out.length){
      while(blanks()<2) out.push('');
    }
    out.push(s);
  });
  while(out.length && out[out.length-1]==='') out.pop();
  return out;
}

/* ===== Printable PDF brief =====================================================================
   The same weekly facts, laid out as an EDR-branded briefing and sent to the browser's Save-as-PDF.
   Pure client side (works in both builds): it opens a print window, lays the content into explicit
   A4 pages so the dark background is edge to edge with a clean per-page footer, and prints. */
const EDR_BRIEF_CSS = `
:root{ --bg:#0c0e13; --card:#151a22; --card2:#11151b; --line:#242b36; --yellow:#f0f000; --white:#fff; --dim:#98a1b2; --dim2:#727c8d; }
*{box-sizing:border-box;margin:0;padding:0}
@page{ size:A4; margin:0; }
html,body{ background:var(--bg); color:var(--white); font-family:'Karla',system-ui,sans-serif; font-size:10.2px; line-height:1.5; -webkit-print-color-adjust:exact; print-color-adjust:exact; }
#src{ position:absolute; left:-9999px; top:0; width:180mm; }
.page{ position:relative; width:210mm; height:297mm; background:var(--bg); overflow:hidden; padding:13mm 15mm 15mm; break-after:page; }
.page:last-child{ break-after:auto; }
.page.cont{ padding-top:26mm; }
.minilogo{ position:absolute; top:11mm; right:15mm; width:78px; }
.foot{ position:absolute; left:0; right:0; bottom:0; height:11mm; padding:0 15mm; display:flex; justify-content:space-between; align-items:center; background:var(--bg); border-top:1px solid var(--line); font-size:8px; color:var(--dim2); }
.foot .c{ color:var(--yellow); }
.disp,h1,h2,h3{ font-family:'Prompt','Karla',sans-serif; }
.mono-cap{ font-family:'Prompt',sans-serif; text-transform:uppercase; letter-spacing:.24em; }
.mast{ display:flex; align-items:flex-start; gap:16px; }
.mast img{ width:118px; height:auto; }
.mast .kicker{ color:var(--yellow); font-size:9px; font-weight:600; }
.mast .title{ color:#fff; font-weight:700; font-style:italic; font-size:34px; line-height:.98; letter-spacing:.5px; text-transform:uppercase; margin-top:1px; }
.mast .sub{ color:var(--dim); font-weight:700; font-size:11px; margin-top:5px; font-family:'Prompt',sans-serif; }
.rule{ height:3px; background:var(--yellow); margin:9px 0 12px; }
.intro{ color:var(--dim); font-size:11px; line-height:1.6; }
.intro b{ color:var(--yellow); }
.sec{ display:flex; align-items:center; gap:14px; margin:18px 0 11px; }
.sec .h{ color:var(--yellow); font-weight:700; font-style:italic; font-size:21px; text-transform:uppercase; letter-spacing:.5px; white-space:nowrap; }
.sec .ln{ flex:1; height:1px; background:var(--line); }
.sec .tag{ color:var(--dim2); font-size:8.5px; }
.recap{ background:var(--card); border:1px solid var(--line); border-radius:5px; padding:19px 21px; }
.recap .lead{ color:#fff; font-family:'Prompt',sans-serif; font-weight:700; font-size:17px; margin-bottom:13px; }
.recap .lead b{ color:var(--yellow); }
.podium{ display:flex; gap:12px; margin-bottom:16px; }
.pod{ flex:1; background:var(--card2); border-top:2px solid var(--yellow); border-radius:3px; padding:11px 13px; }
.pod .rk{ color:var(--dim2); font-size:8.5px; font-family:'Prompt',sans-serif; letter-spacing:.14em; }
.pod .nm{ color:#fff; font-weight:700; font-size:14.5px; font-family:'Prompt',sans-serif; margin-top:2px; }
.pod .dl{ color:var(--yellow); font-weight:700; font-size:20px; margin-top:1px; }
.pod .ex{ color:var(--dim); font-size:9.5px; margin-top:2px; }
.awards{ display:grid; grid-template-columns:1fr 1fr; gap:9px 26px; }
.aw{ color:var(--dim); font-size:11.5px; }
.aw .lbl{ color:#cfd6e2; font-weight:700; }
.aw .y{ color:var(--yellow); font-weight:700; }
.card{ background:var(--card); border-left:4px solid var(--yellow); border-radius:3px; padding:12px 15px; margin-bottom:9px; }
.card .crow{ display:flex; justify-content:space-between; align-items:flex-start; gap:12px; }
.card .name{ color:#fff; font-weight:700; font-size:15px; font-family:'Prompt',sans-serif; }
.card .track{ color:var(--yellow); font-weight:700; font-size:11px; margin-top:1px; }
.badges{ display:flex; gap:7px; align-items:center; white-space:nowrap; }
.pill{ background:var(--yellow); color:#111; font-weight:700; font-size:9px; padding:3px 8px; border-radius:2px; font-family:'Prompt',sans-serif; }
.pill.ghost{ background:transparent; color:#fff; border:1px solid #3a4250; font-weight:600; letter-spacing:.04em; }
.meta{ color:var(--dim); font-size:10px; margin-top:8px; }
.meta b{ color:#cfd6e2; font-weight:700; }
.desc{ color:var(--dim); font-size:10.3px; line-height:1.55; margin-top:7px; }
.edrhere{ color:#cfd6e2; font-size:10px; margin-top:6px; }
.edrhere b{ color:var(--yellow); }
.tgt{ display:inline-block; border:1px solid #3a4250; color:var(--dim); font-size:7.6px; letter-spacing:.12em; padding:2px 6px; border-radius:2px; margin-left:8px; text-transform:uppercase; font-family:'Prompt',sans-serif; }
.pairs{ width:100%; border-collapse:collapse; }
.pairs td{ padding:9px 12px; font-size:10px; vertical-align:top; }
.pairs tr:nth-child(odd) td{ background:var(--card2); }
.pairs .ptrk{ color:var(--yellow); font-weight:700; width:26%; }
.pairs .pser{ color:#fff; font-weight:700; width:32%; font-family:'Prompt',sans-serif; }
.pairs .pmatch{ color:var(--dim); }
.sprint{ padding:9px 0 8px; border-bottom:1px solid var(--line); }
.sprint .stop{ display:flex; justify-content:space-between; align-items:baseline; gap:12px; }
.sprint .s{ color:#fff; font-weight:700; font-size:12.5px; font-family:'Prompt',sans-serif; }
.sprint .s .dur{ color:var(--yellow); font-size:11px; margin-left:5px; }
.sprint .trk{ color:var(--dim); font-size:10px; text-align:right; }
.sprint .cls{ color:var(--dim2); font-size:9.6px; margin-top:2px; }
.sprint .cls .t{ color:var(--yellow); }
.shout{ background:var(--card2); border-left:3px solid var(--yellow); border-radius:2px; padding:6px 10px; margin-top:6px; font-size:10px; color:var(--dim); }
.shout .lbl{ color:var(--dim2); font-size:7.6px; letter-spacing:.18em; margin-right:8px; font-family:'Prompt',sans-serif; }
.shout b{ color:var(--yellow); }
`;
function _briefDate(iso){ try{ return new Date(iso+'T00:00:00Z').toLocaleDateString('en-AU',{day:'numeric',month:'long',timeZone:'UTC'}); }catch(e){ return iso; } }
function _briefYear(iso){ return String(iso||'').slice(0,4); }
function _bsec(h,tag){ return '<div class="sec" data-keep="1"><div class="h">'+esc(h)+'</div><div class="ln"></div><div class="tag mono-cap">'+esc(tag)+'</div></div>'; }
function _bpill(dur,date,live){ let b=[]; if(live) b.push('<span class="pill">LIVE NOW</span>'); if(dur) b.push('<span class="pill">'+esc(dur)+'</span>'); if(date) b.push('<span class="pill ghost">'+esc(date)+'</span>'); return b.length?'<div class="badges">'+b.join('')+'</div>':''; }
function _bcard(o){
  let p=['<div class="card"><div class="crow"><div><div class="name">'+esc(o.name)+'</div><div class="track">'+esc(o.track||'track TBC')+'</div></div>'+_bpill(o.dur,o.date,o.live)+'</div>'];
  const tgt=o.target?'<span class="tgt">EDR target</span>':'';
  if(o.cars) p.push('<div class="meta"><b>Class:</b> '+esc(o.cars)+tgt+'</div>'); else if(tgt) p.push('<div class="meta">'+tgt+'</div>');
  if(o.sessions) p.push('<div class="meta"><b>Sessions:</b> '+esc(o.sessions)+'</div>');
  if(o.edrhere) p.push('<div class="edrhere"><b>EDR here:</b> '+esc(o.edrhere)+'</div>');
  if(o.desc) p.push('<div class="desc">'+esc(o.desc)+'</div>');
  return p.join('')+'</div>';
}
function _bsprint(s){
  const dur=fmtRaceDist(s.raceMin,s.raceLaps), cls=(s.cars&&s.cars.length)?s.cars.join(' / '):'', timing=s.when||s.times||'';
  let h='<div class="sprint"><div class="stop"><div class="s">'+esc(s.series)+(dur?'<span class="dur">'+esc(dur)+'</span>':'')+'</div><div class="trk">'+esc(s.track||'track TBC')+'</div></div>';
  if(cls||timing) h+='<div class="cls">'+esc(cls)+(cls&&timing?' · ':'')+(timing?'<span class="t">'+esc(timing)+'</span>':'')+'</div>';
  if(s.hist) h+='<div class="edrhere"><b>EDR here:</b> '+esc(s.hist)+'</div>';
  if(s.flare) h+='<div class="shout"><span class="lbl">SHOUTOUT</span><b>'+esc(s.flare.name)+'</b>: '+esc(s.flare.note)+'.</div>';
  return h+'</div>';
}
/* Sprints that share a track with an enduro — the mockup's "free homework" table. */
function _briefPairings(f){
  const rows=[];
  (f.enduros||[]).forEach(function(e){
    if(!e.track) return;
    const k=histTrackKey(e.track);
    const m=(f.sprints||[]).filter(function(s){ return s.track && histTrackKey(s.track)===k; })
      .map(function(s){ return s.series+' '+fmtRaceDist(s.raceMin,s.raceLaps); });
    if(m.length) rows.push({trk:e.track, ser:e.series+' · '+fmtRaceDist(e.raceMin,e.raceLaps), match:m.slice(0,3).join(' · ')});
  });
  return rows;
}
/* The whole brief as one HTML string of blocks (in #src), for the paginator to lay out. */
function weeklyBriefBlocks(f){
  const B=[];
  B.push('<div class="mast"><img src="'+(EDR_BRIEF_LOGO||'')+'">'
    +'<div><div class="kicker mono-cap">Endurotech Racing Weekly Briefing</div>'
    +'<div class="title disp">This Week in iRacing</div>'
    +'<div class="sub">Week of '+esc(_briefDate(f.week.from))+' to '+esc(_briefDate(f.week.to))+' '+esc(_briefYear(f.week.to))+'</div></div></div>'
    +'<div class="rule"></div>'
    +'<div class="intro">Team first, as always: last week in the mirrors, then the endurance calendar, the majors on the horizon, and this week\'s sprint lineup. <b>If you don\'t know a race is on, you don\'t know.</b></div>');

  const aw=(typeof recapAwards==='function')?recapAwards(RECAP):null;
  if(aw){
    B.push(_bsec('Last Week','In the mirrors'));
    let r='<div class="recap"><div class="lead"><b>'+(aw.drivers||0)+'</b> drivers started <b>'+(aw.starts||0)+'</b> official races.</div>';
    if(aw.top3&&aw.top3.length){
      r+='<div class="podium">';
      aw.top3.forEach(function(d,i){
        const ex=(d.races?(d.races+' race'+(d.races===1?'':'s')+(d.wins?', '+d.wins+' win'+(d.wins===1?'':'s'):(d.podiums?', '+d.podiums+' podium'+(d.podiums===1?'':'s'):''))):'');
        r+='<div class="pod"><div class="rk">'+(i===0?'01 · Most improved':(i===1?'02':'03'))+'</div><div class="nm">'+esc(d.name)+'</div><div class="dl">'+sgn(d.irDelta)+'</div><div class="ex">'+(d.irEnd?'→ '+d.irEnd+' iR':'')+(ex?' · '+esc(ex):'')+'</div></div>';
      });
      r+='</div>';
    }
    const aws=[];
    if(aw.lost) aws.push('<span class="lbl">Took one for the team</span> — '+esc(aw.lost.name)+' <span class="y">'+sgn(aw.lost.irDelta)+'</span>');
    if(aw.winners&&aw.winners.length) aws.push('<span class="lbl">Wins</span> — '+aw.winners.map(function(d){return esc(d.name)+' ('+d.wins+')';}).join(', '));
    if(aw.srUp) aws.push('<span class="lbl">Safety rating climb</span> — '+esc(aw.srUp.name)+' '+esc(fmtSr(aw.srUp)));
    if(aw.srDown) aws.push('<span class="lbl">Safety rating slide</span> — '+esc(aw.srDown.name)+' '+esc(fmtSr(aw.srDown)));
    if(aw.busiest&&aw.busiest.races>1) aws.push('<span class="lbl">Busiest</span> — '+esc(aw.busiest.name)+', '+aw.busiest.races+' starts');
    if(aw.cleanest) aws.push('<span class="lbl">Cleanest</span> — '+esc(aw.cleanest.name)+', '+(Math.round((aw.cleanest.inc/aw.cleanest.races)*10)/10)+'x per race');
    if(aws.length) r+='<div class="awards">'+aws.map(function(a){return '<div class="aw">'+a+'</div>';}).join('')+'</div>';
    B.push(r+'</div>');
  }

  if(f.enduros&&f.enduros.length){
    B.push(_bsec('Endurance','Team focus'));
    f.enduros.forEach(function(e){ B.push(_bcard({name:e.series, track:e.track, cars:(e.cars&&e.cars.length)?e.cars.join(' / '):'', sessions:(e.times?'Sessions: '+e.times:(e.when?'Races '+e.when:'')).replace(/^Sessions: /,''), dur:fmtRaceDist(e.raceMin,e.raceLaps), edrhere:e.hist, desc:e.note?cap(e.note)+'.':''})); });
  }
  if(f.specials&&f.specials.length){
    B.push(_bsec('On the Horizon','Next four weeks · EDR targets'));
    f.specials.forEach(function(ev){
      const when=ev.live?'':(esc(ev.dates)+' · in '+ev.inDays+' day'+(ev.inDays===1?'':'s'));
      B.push(_bcard({name:ev.name, track:ev.track, cars:ev.cars||'', dur:ev.dur?ev.dur+'H':'', date:when, live:ev.live, target:ev.target, desc:ev.note?cap(ev.note)+'.':''}));
    });
  }
  const pr=_briefPairings(f);
  if(pr.length){
    B.push(_bsec('Practice Pairings','Free homework'));
    B.push('<div class="intro" style="margin-bottom:8px">Some of this week\'s sprints run on the same track as an enduro — same corners, a fraction of the commitment.</div>');
    B.push('<table class="pairs"><tbody>'+pr.map(function(p){ return '<tr><td class="ptrk">'+esc(p.trk)+'</td><td class="pser">'+esc(p.ser)+'</td><td class="pmatch">'+esc(p.match)+'</td></tr>'; }).join('')+'</tbody></table>');
  }
  if(f.sprints&&f.sprints.length){
    B.push(_bsec('Sprints','On the repeating slots'));
    f.sprints.forEach(function(s){ if(s.matched) B.push(_bsprint(s)); });
  }
  return B.join('\n');
}
let EDR_BRIEF_LOGO='';
function openWeeklyBrief(){
  if(!isAdmin()) return;
  const f=weeklyFacts();
  try{ const im=document.querySelector('img[src^="data:image/png;base64,iVBOR"]'); EDR_BRIEF_LOGO=im?im.src:''; }catch(e){ EDR_BRIEF_LOGO=''; }
  const blocks=weeklyBriefBlocks(f);
  const footHTML='<div class="mono-cap">Endurotech Racing</div><div class="c mono-cap">This Week in iRacing · '+esc(_briefDate(f.week.from))+' to '+esc(_briefDate(f.week.to))+'</div><div class="mono-cap">Endurotech</div>';
  const pager='(function(){var LOGO='+JSON.stringify(EDR_BRIEF_LOGO)+',FOOT='+JSON.stringify(footHTML)+';'
    +'function px(mm){return mm*96/25.4;}var CAP=px(297-16);'
    +'function foot(){var f=document.createElement("div");f.className="foot";f.innerHTML=FOOT;return f;}'
    +'function logo(){var i=document.createElement("img");i.className="minilogo";i.src=LOGO;return i;}'
    +'function run(){var src=document.getElementById("src"),pages=document.getElementById("pages");var bl=[].slice.call(src.children);src.parentNode.removeChild(src);'
    +'var page,first=true;function np(){page=document.createElement("div");page.className="page"+(first?"":" cont");if(!first)page.appendChild(logo());page.appendChild(foot());pages.appendChild(page);}'
    +'function anchor(){return page.querySelector(".foot");}function cnt(){return page.querySelectorAll(":scope > :not(.foot):not(.minilogo)").length;}np();'
    +'bl.forEach(function(b){page.insertBefore(b,anchor());if(b.offsetTop+b.offsetHeight>CAP&&cnt()>1){page.removeChild(b);var carry=[],last=anchor().previousElementSibling;if(last&&last.getAttribute("data-keep")==="1"){page.removeChild(last);carry.push(last);}first=false;np();carry.forEach(function(c){page.insertBefore(c,anchor());});page.insertBefore(b,anchor());}});'
    +'setTimeout(function(){try{window.focus();window.print();}catch(e){}},80);}'
    +'window.addEventListener("load",function(){if(document.fonts&&document.fonts.ready){document.fonts.ready.then(function(){setTimeout(run,150);});}else setTimeout(run,400);});})();';
  const doc='<!doctype html><html><head><meta charset="utf-8"><title>EDR — This Week in iRacing</title>'
    +'<link href="https://fonts.googleapis.com/css2?family=Prompt:ital,wght@0,500;0,600;0,700;1,600;1,700&family=Karla:wght@400;500;700&display=swap" rel="stylesheet">'
    +'<style>'+EDR_BRIEF_CSS+'</style></head><body><div id="src">'+blocks+'</div><div id="pages"></div><script>'+pager+'<\/script></body></html>';
  const w=window.open('','_blank');
  if(!w){ _wkMsg='Allow pop-ups for this site, then hit Download brief again.'; _wkErr=true; renderContent(); return; }
  w.document.open(); w.document.write(doc); w.document.close();
}
/* The pick list is the drafted week's actual rounds, not a fixed menu. Series the team has history in
   come first and are ticked; anything else is offered unticked so a new series can be added
   without editing code. */
function weeklyPickList(){
  const weeks=(typeof IR_WEEKS!=='undefined' && Array.isArray(IR_WEEKS)) ? IR_WEEKS : [];
  const w=weeklyState();
  const known={}; WEEKLY_SERIES.forEach(function(s){ known[seriesKey(s.n)]=s; });
  const seen={}, rows=[];
  weeks.forEach(function(r){
    if(!inDraftWeek(r.start_date)) return;
    const k=seriesKey(r.series); if(seen[k]) return; seen[k]=1;
    const seed=known[k]||null;
    const label=seed?seed.n:prettySeriesName(r.series);
    /* Endurance rounds default ON whether or not the team has ever started one — the point of
       listing them is to remind people the endurance calendar exists, which a history-based
       default would defeat exactly for the series nobody has got around to yet. */
    const isEnduro=((r.race_min||0)>=ENDURO_MIN) || !!r.team;
    const on=(w.pick[label]!==undefined) ? !!w.pick[label] : (isEnduro || !!(seed&&seed.on));
    rows.push({key:k, label:label, track:r.track, cars:(r.cars||[]).join(' / '),
               starts:seed?seed.st:0, enduro:isEnduro, cat:r.cat||'', on:on});
  });
  rows.sort(function(a,b){ return (b.starts||0)-(a.starts||0) || a.label.localeCompare(b.label); });
  return rows;
}
function renderWeekly(){
  if(!isAdmin()) return '<div class="importbox"><div class="meta">The weekly update is an admin tool.</div></div>';
  const w=weeklyState();
  const f=weeklyFacts();
  let h='<div class="importbox">';
  h+='<div class="head" style="font-size:17px;color:#fff;text-transform:uppercase">This week in iRacing</div>';
  h+='<div class="meta" style="margin-top:4px">Pick the series to cover and hit Generate. Copy the draft out, edit it and add your own flare wherever you like working, then paste it back into the final box at the bottom and hit Post to Discord. '
    +(f.haveIracing?('Tracks come from live iRacing data — '+f.sprints.filter(function(s){return s.matched;}).length+' of '+f.sprints.length+' series matched a round this week.')
                   :'No live iRacing data right now, so tracks will be blank — set the proxy in plugin Settings.')+'</div>';
  h+='<div class="quickrow" style="margin-top:10px">'
    +'<button class="btn btn-amber avfree" data-action="wkgen">Generate the update</button>'
    +'<button class="quickbtn avfree" data-action="wkai"'+(_wkAI?' disabled':'')+' title="rewrite the generated draft in EDR\'s voice with Gemini — needs an API key in plugin Settings">'+(_wkAI?'Composing…':'Compose with AI')+'</button>'
    +'<button class="quickbtn avfree" data-action="wkcopy" title="copy the draft so you can edit it somewhere else">Copy the draft</button>'
    +'<button class="quickbtn avfree" data-action="wkpdf" title="open a styled, printable brief and save it as a PDF (uses this week\'s data)">Download brief (PDF)</button>'
    /* everything routes through the preview: posting reaches the whole team in one click and
       cannot be undone, so there is no path that sends without showing it first */
    +'<button class="quickbtn avfree" data-action="wkpreview" title="see exactly what the team will get, then post from there">Preview &amp; post</button>'
    +'<span class="meta" style="display:flex;gap:10px;align-items:center;margin-left:8px" title="which race week the draft covers — iRacing weeks tick over Tuesday 10:00 Melbourne">'
      +'<label style="display:flex;gap:5px;align-items:center"><input type="radio" name="wkscope" data-action="wkscope" data-v="next"'+(w.scope==='next'?' checked':'')+'> next week</label>'
      +'<label style="display:flex;gap:5px;align-items:center"><input type="radio" name="wkscope" data-action="wkscope" data-v="this"'+(w.scope==='this'?' checked':'')+'> this week</label>'
    +'</span>'
    +'<label class="meta" style="display:flex;gap:6px;align-items:center;margin-left:8px"><input type="checkbox" data-action="wkflare"'+(w.flare?' checked':'')+'> driver mentions</label>'
    +(_wkMsg?'<span class="meta" style="color:'+(_wkErr?'var(--red)':'var(--green)')+'">'+esc(_wkMsg)+'</span>':'')
    +'</div>';
  /* Last week's results are a separate, slow pull, so they get their own control and their
     own freshness line rather than being hidden behind Generate. */
  h+='<div class="quickrow">'
    +'<button class="quickbtn avfree" data-action="wkrecap"'+(RECAP_RUNNING?' disabled':'')+'>'
      +(RECAP_RUNNING?'Pulling last week…':'Pull last week\'s results')+'</button>'
    +'<button class="quickbtn avfree" data-action="wksnap" title="reads iRating and safety rating from Garage 61 — seconds, not minutes">Snapshot ratings</button>'
    +'<span class="meta" style="font-size:10.5px;color:'+(RECAP_ERR?'var(--red)':'var(--dim)')+'">'+esc(recapAgeLabel())+'</span>'
    +'</div>';
  /* Season-long team history — the "EDR here: N starts, W wins" lines and the earned driver
     mentions. Its own slow pull, like the recap. */
  h+='<div class="quickrow">'
    +'<button class="quickbtn avfree" data-action="wkhist"'+((typeof HIST_RUNNING!=='undefined'&&HIST_RUNNING)?' disabled':'')+' title="one search per driver over the last season — used for per-track records and earned driver mentions">'
      +((typeof HIST_RUNNING!=='undefined'&&HIST_RUNNING)?'Pulling team history…':'Pull team history')+'</button>'
    +'<span class="meta" style="font-size:10.5px;color:'+((typeof HIST_ERR!=='undefined'&&HIST_ERR)?'var(--red)':'var(--dim)')+'">'+esc(histAgeLabel())+'</span>'
    +'</div>';
  if(RATINGS&&RATINGS.ready){
    h+='<div class="meta" style="font-size:10.5px">Ratings movement '+esc(RATINGS.from)+' → '+esc(RATINGS.to)+', '+((RATINGS.movers||[]).length)+' driver(s) moved — from Garage 61\'s synced ratings, which lag iRacing by about a week. FYI only: the draft\'s iRating/SR awards now come from the results sweep below, not this.</div>';
    /* Diagnostic: says whether a low mover count is coverage (few matched / few with a sports-car
       rating) or genuinely quiet (many matched, nearly all unchanged). Only sports-car iRating is
       snapshotted, so a driver who did not race that category shows no movement. */
    if(RATINGS.diag){ const d=RATINGS.diag;
      h+='<div class="meta" style="font-size:10px;color:var(--dim)">Snapshots: '+d.prevDrivers+' → '+d.currDrivers+' drivers, '+d.matched+' in both; '+d.currRated+' with a sports-car rating; '+d.zeroDelta+' unchanged. Only sports-car iRating/SR is tracked — anyone who did not race that category this week shows no movement.</div>';
    }
  }
  else if(RATINGS) h+='<div class="meta" style="font-size:10.5px">Ratings: '+((RATINGS.have||0))+' snapshot(s) stored — a second week is needed before movement can be shown.</div>';
  h+='</div>';

  h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">Series racing '+draftWeekWord()+'</div>';
  h+='<div class="meta" style="font-size:10.5px">Straight from the iRacing schedule for '+esc(f.week.from)+' to '+esc(f.week.to)+'. '
    +(f.liveRunners?'Team participation is live from iRacing results.'
                   :'Team participation is still the seeded snapshot — it becomes live once the results pull has run.')+'</div>';
  const allRows=weeklyPickList();
  /* Discipline filter + search. Both narrow what is DISPLAYED only — a series ticked while a
     filter was on stays in the draft when the filter changes, otherwise the filter would
     quietly edit the write-up. */
  const cats=[]; allRows.forEach(function(r){ if(r.cat && cats.indexOf(r.cat)<0) cats.push(r.cat); });
  if(cats.length>1 || _wkQ){
    h+='<div class="quickrow" style="margin-top:8px">';
    h+='<button class="quickbtn avfree'+(_wkCat==='all'?' on':'')+'" data-action="wkcat" data-c="all"'
      +(_wkCat==='all'?' style="border-color:var(--yellow);color:#fff"':'')+'>All</button>';
    cats.sort().forEach(function(c){
      h+='<button class="quickbtn avfree'+(_wkCat===c?' on':'')+'" data-action="wkcat" data-c="'+esc(c)+'"'
        +(_wkCat===c?' style="border-color:var(--yellow);color:#fff"':'')+'>'+esc(catLabel(c))+'</button>';
    });
    h+='<input id="wkq" class="avfree" type="search" placeholder="search series or track" value="'+esc(_wkQ)+'" data-action="wkq" style="margin-left:auto;padding:5px 10px;font-size:11px;width:190px">';
    h+='</div>';
  }
  const rows=allRows.filter(function(r){
    if(_wkCat!=='all' && r.cat!==_wkCat) return false;
    if(!_wkQ) return true;
    const q=_wkQ.toLowerCase();
    return (r.label+' '+(r.track||'')+' '+(r.cars||'')).toLowerCase().indexOf(q)>=0;
  });
  if(!allRows.length){
    h+='<div class="meta" style="margin-top:8px">'+(f.haveIracing?'No official rounds land in that window yet — iRacing usually publishes a week or so ahead.':'No schedule available. Set the iRacing proxy in plugin Settings.')+'</div>';
  } else if(!rows.length){
    h+='<div class="meta" style="margin-top:8px">Nothing matches that filter.</div>';
  } else {
    /* split the list the same way the write-up is split, so what you tick maps onto the
       section it will appear in */
    [['Endurance', true], ['Sprints', false]].forEach(function(grp){
      const set=rows.filter(function(r){ return !!r.enduro===grp[1]; });
      if(!set.length) return;
      h+='<div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin:10px 0 2px">'+grp[0]+' · '+set.length+'</div>';
      h+='<div class="wkser">';
      set.forEach(function(r){
        h+='<label><input type="checkbox" class="avfree" data-action="wkser" data-n="'+esc(r.label)+'"'+(r.on?' checked':'')+'>'
          +'<span>'+esc(r.label)+'<span class="st"> · '+esc(r.track||'track TBC')+(r.cars?' · '+esc(r.cars):'')
          +(r.starts?' · '+r.starts+' team starts':(r.enduro?'':' · new to the team'))+'</span></span></label>';
      });
      h+='</div>';
    });
  }
  h+='</div>';

  /* If a series comes back with no start-time pattern the write-up just omits it silently,
     which is impossible to diagnose from the outside — the schedule field names vary. Say
     which ones are missing and what the API actually sent for them. */
  const noTime=(f.sprints||[]).filter(function(x){ return x.matched && !x.when && !x.times; });
  if(noTime.length){
    h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">No start time for '+noTime.length+' series</div>';
    h+='<div class="meta" style="font-size:10.5px">The schedule gave no usable start or repeat for these. What arrived:</div>';
    h+='<div class="wkser">';
    noTime.slice(0,12).forEach(function(x){
      h+='<label style="cursor:default"><span>'+esc(x.series)
        +'<span class="st"> · first='+esc(x.firstRaw||'(none)')+' · repeat='+esc(String(x.repeatRaw||0))
        +' · sessions='+((x.sessions&&x.sessions.length)||0)+'</span></span></label>';
    });
    h+='</div></div>';
  }

  /* Rounds whose car came from the season-wide class list rather than the week's own
     race_week_cars. For a rotating-car series that list never moves, so the draft would name
     the same car every week of the season — say so here rather than let it read as fact. */
  const noCar=(f.sprints||[]).concat(f.enduros||[]).filter(function(x){ return x.carsWeek===false; });
  if(noCar.length){
    h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">Car unconfirmed for '+noCar.length+' series</div>';
    h+='<div class="meta" style="font-size:10.5px">The schedule named no car for these rounds, so the season-wide list is showing. Check the car before the draft goes out.</div>';
    h+='<div class="wkser">';
    noCar.slice(0,12).forEach(function(x){
      h+='<label style="cursor:default"><span>'+esc(x.series)
        +'<span class="st"> · showing '+esc((x.cars&&x.cars.length)?x.cars.join(' / '):'(nothing)')+'</span></span></label>';
    });
    h+='</div></div>';
  }
  h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">Step 1 · the draft</div>';
  h+='<div class="meta" style="font-size:10.5px;margin-bottom:6px">Generated from the data above. Copy it out, edit it and add whatever you want, then paste the finished version into step 2.</div>';
  /* placeholder, not a value: the hint used to sit in the box as real text, and Post to Discord
     reads the box — so an un-generated draft would have posted the hint to the team channel */
  h+='<textarea class="wkbox avfree" id="wkdraft" spellcheck="false" placeholder="Hit Generate to build this week\'s update.">'+esc(_wkDraft)+'</textarea>';
  h+='</div>';

  /* Step 2 is a separate box on purpose. The edited write-up is the valuable artefact — it has
     been through someone's hands and picked up things the generator cannot know — and Generate
     rebuilds the draft from scratch on every click, so sharing one box means one stray click
     destroys it. Empty means nothing has been pasted, and the draft posts as-is. */
  h+='<div class="importbox"><div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">Step 2 · the final post</div>';
  h+='<div class="meta" style="font-size:10.5px;margin-bottom:6px">Paste your edited version here — this is exactly what goes to Discord, character for character. Generate never touches this box. Leave it empty and the draft above is posted as it stands.</div>';
  h+='<textarea class="wkbox avfree" id="wkfinal" spellcheck="false" placeholder="Paste the edited write-up here, then hit Post to Discord.">'+esc(_wkFinal)+'</textarea>';
  h+='<div class="quickrow" style="margin-top:8px">'
    /* repeated from the top of the tab on purpose: this is where you are standing when you
       finish pasting, and the row up there is a long scroll away by then */
    +'<button class="btn btn-amber avfree" data-action="wkpreview" title="see exactly what the team will get, then post from there">Preview &amp; post</button>'
    +'<button class="quickbtn avfree" data-action="wkseed" title="drop the generated draft in here as a starting point">Start from the draft</button>'
    +'<button class="quickbtn avfree" data-action="wkfinalcopy">Copy this</button>'
    +'<button class="quickbtn avfree" data-action="wkfinalclear" title="empty this box — Post to Discord then falls back to the draft above">Clear</button>'
    /* offered, never auto-loaded: the stored copy is whatever was last posted, so it can easily
       be last week's, and silently seeding the box that wins would post it */
    +((_wkStored&&_wkStored.text&&!_wkFinal.trim())
        ? '<button class="quickbtn avfree" data-action="wkrestore" title="load the copy the server is holding — this is what a scheduled post would send">Restore saved ('+esc(wkAgo(_wkStored.at))+')</button>'
        : '')
    +'<span class="meta" id="wkcount" style="font-size:10.5px;margin-left:auto">'+wkCountHtml()+'</span>'
    +'</div>';
  if(_wkStripped){
    h+='<div class="meta" style="font-size:10.5px;color:var(--red);margin-top:8px">'
      +'This site\'s database is dropping characters from the saved copy — almost always a table still on 3-byte <b>utf8</b> instead of <b>utf8mb4</b>, which silently eats emoji. '
      +'Posting from this tab is unaffected (the text goes straight to Discord), but a <b>scheduled</b> post sends the saved copy and would arrive without them. '
      +'Converting the database to utf8mb4 fixes it.</div>';
  }
  h+='</div>';
  return h;
}
function wkAgo(at){
  const mins=Math.max(0, Math.round((Date.now()/1000-(at||0))/60));
  if(mins<60) return mins+' min ago';
  const hrs=Math.round(mins/60);
  if(hrs<24) return hrs+'h ago';
  return Math.round(hrs/24)+'d ago';
}
/* Which box wins, how long it is, and how many messages Discord will receive. Kept out of
   renderWeekly so typing can refresh just this line — re-rendering the tab on a keystroke
   would throw the textarea's caret to the end, which is unusable in a 3000-character post. */
function wkCountHtml(){
  const posting=wkPostText();
  if(!posting.trim()) return 'Nothing to post yet.';
  const chunks=wkChunkCount(posting);
  return (_wkFinal.trim()?'Will post <b style="color:var(--yellow)">this box</b>':'Will post <b style="color:var(--yellow)">the draft above</b>')
    +' · '+posting.length+' characters · '+chunks+' Discord message'+(chunks===1?'':'s')
    +(_wkFinalAt?' · saved '+wkSavedLabel():'');
}
function wkSyncCount(){ const el=document.getElementById('wkcount'); if(el) el.innerHTML=wkCountHtml(); }
/* How long ago the server's copy of the post was stored. It matters because the scheduled job
   posts that copy with no browser involved, and /weekly/post refuses one more than 8 days old. */
function wkSavedLabel(){
  const mins=Math.max(0, Math.round((Date.now()/1000-_wkFinalAt)/60));
  if(mins<1) return 'just now';
  if(mins<60) return mins+' min ago';
  const hrs=Math.round(mins/60);
  if(hrs<24) return hrs+'h ago';
  return Math.round(hrs/24)+'d ago';
}
/* ===== Availability tab ===== */
function canEditAvail(name){ return isAdmin()||(!!state.me&&name===state.me&&!lockedForMe(name)); }
function toggleAvail(name,slot,want){
  if(!canEditAvail(name)) return false;
  const store=state.availStore[state.evsel]=state.availStore[state.evsel]||{};
  const arr=store[name]=store[name]||[];
  const i=arr.indexOf(slot);
  const on=(want===undefined)?(i<0):want;
  if(on&&i<0) arr.push(slot);
  if(!on&&i>=0) arr.splice(i,1);
  (_availDirty[state.evsel]=_availDirty[state.evsel]||{})[name]=1; _avMsg=''; _avErr=false;
  applyAvailToDrivers(); save(); return true;
}
function setAllAvail(name,on){
  if(!canEditAvail(name)) return false;
  const store=state.availStore[state.evsel]=state.availStore[state.evsel]||{};
  store[name]= on ? Array.from({length:evSlots()},(_,i)=>i) : [];
  (_availDirty[state.evsel]=_availDirty[state.evsel]||{})[name]=1; _avMsg=''; _avErr=false;
  applyAvailToDrivers(); save(); return true;
}
function prefsFor(name){ const p=((state.prefStore||{})[state.evsel]||{})[name]; return {time:(p&&p.time)||'any', cond:(p&&p.cond)||'any', cls:(p&&p.cls)||''}; }
/* Change the block size for the selected event and RESCALE every stored tick through real
   minute windows, because a slot index means nothing without the size it was recorded at —
   reinterpreting 2h ticks as 30min ticks would silently shrink everyone's availability. */
function avSetBlock(next){
  if(!state.evsel || !avBlockOk(next) || +next===AV_BLOCK) return;
  const ev=calEvent(state.evsel); if(!ev) return;
  const oldB=AV_BLOCK, store=state.availStore[state.evsel]||{};
  const coarser=(+next>oldB);
  let before=0, after=0;
  Object.keys(store).forEach(function(nm){
    const win=slotsToWindows(store[nm], oldB, EV_WIN_MIN);
    before+=win.reduce(function(a,w){return a+(w[1]-w[0]);},0);
    store[nm]=windowsToSlots(win, EV_WIN_MIN, +next, coarser);
    after+=slotsToWindows(store[nm], +next, EV_WIN_MIN).reduce(function(a,w){return a+(w[1]-w[0]);},0);
    (_availDirty[state.evsel]=_availDirty[state.evsel]||{})[nm]=1;   // rescaled ticks must be pushed
  });
  state.evTiming=state.evTiming||{};
  state.evTiming[state.evsel]=Object.assign({}, state.evTiming[state.evsel]||{}, {avBlock:+next});
  applyEventTiming(ev);
  const n=Object.keys(store).length;
  const lost=Math.round((before-after)/6)/10;
  _avMsg=n?('Block size now '+fmtBlockLen(+next)+' — '+n+' driver'+(n>1?'s':'')+' rescaled'
            +(lost>0?', '+lost+'h trimmed where blocks no longer line up':'')+'. Hit Submit to save.')
          :('Block size now '+fmtBlockLen(+next)+'.');
  _avErr=false; save(); renderContent();
}
function fmtBlockLen(m){ return m%60===0 ? (m/60)+'h' : (m<60? m+'min' : Math.floor(m/60)+'h '+(m%60)+'min'); }
/* last-submission stamps from the server ({ev:{name:{at,n}}}), so a returning driver is told
   they are already in instead of having to decode their own grid */
let AV_SEEN={};
function avSeenFor(nm){
  const s=((AV_SEEN||{})[state.evsel]||{})[nm];
  if(!s||!s.at) return null;
  return {n:s.n||0, ago:relTime(s.at)};
}
function relTime(sqlish){
  /* WP current_time('mysql') is "YYYY-MM-DD HH:MM:SS" in the SITE's zone, with no offset to
     anchor it. Close enough for "3 days ago"; never used for anything that has to be exact. */
  const t=Date.parse(String(sqlish).replace(' ','T'));
  if(isNaN(t)) return 'earlier';
  const mins=Math.round((Date.now()-t)/60000);
  if(mins<2) return 'just now';
  if(mins<60) return mins+' minutes ago';
  const hrs=Math.round(mins/60); if(hrs<24) return hrs+' hour'+(hrs===1?'':'s')+' ago';
  const days=Math.round(hrs/24); return days+' day'+(days===1?'':'s')+' ago';
}
/* ---- bulk pickers: 72 individual taps was the single biggest cost of submitting ---- */
function avApplyBulk(nm, want, test){
  if(!canEditAvail(nm)) return;
  const a=state.availStore[state.evsel]=state.availStore[state.evsel]||{};
  const cur=new Set(a[nm]||[]); const n=evSlots();
  for(let i=0;i<n;i++){ if(!test(i)) continue; if(want) cur.add(i); else cur.delete(i); }
  a[nm]=Array.from(cur).sort(function(x,y){return x-y;});
  (_availDirty[state.evsel]=_availDirty[state.evsel]||{})[nm]=1; _avMsg=''; _avErr=false;
  save(); renderContent();
}
/* local hour-of-day, so "evenings" means evenings where the driver lives, not UTC evenings */
function localHour(ms){
  try{ return +new Date(ms).toLocaleString('en-AU',{timeZone:tzZone(),hour:'2-digit',hourCycle:'h23'}); }
  catch(e){ return new Date(ms).getHours(); }
}
function localDayHourKey(ms){
  try{ return new Date(ms).toLocaleString('en-AU',{timeZone:tzZone(),weekday:'short',hour:'2-digit',hourCycle:'h23'}); }
  catch(e){ const d=new Date(ms); return d.getDay()+'|'+d.getHours(); }
}
function slotHour(i){ return localHour(WIN_START_MS + i*AV_BLOCK*60000); }
const AV_PERIODS={ morning:[6,12], afternoon:[12,17], evening:[17,23], night:[23,6] };
function inPeriod(i,p){ const h=slotHour(i), r=AV_PERIODS[p]; return r[0]<r[1] ? (h>=r[0]&&h<r[1]) : (h>=r[0]||h<r[1]); }
/* Copy the driver's ticks from the most recent OTHER event they filled in, matched on local
   weekday + hour rather than slot index — different events have different windows, so index
   copying would land the blocks in the wrong place entirely. */
function avCopyPrevious(nm){
  const prev=avPreviousEvent(nm); if(!prev) return;
  const pat={}, pb=prev.block, pstart=prev.winStart;
  (prev.slots||[]).forEach(function(i){
    for(let m=0;m<pb;m+=30) pat[localDayHourKey(pstart + i*pb*60000 + m*60000)]=1;
  });
  const n=evSlots(), out=[];
  for(let i=0;i<n;i++){
    let hit=0, tot=0;
    for(let m=0;m<AV_BLOCK;m+=30){ tot++; if(pat[localDayHourKey(WIN_START_MS + i*AV_BLOCK*60000 + m*60000)]) hit++; }
    if(tot && hit/tot>=0.5) out.push(i);
  }
  const a=state.availStore[state.evsel]=state.availStore[state.evsel]||{};
  a[nm]=out;
  (_availDirty[state.evsel]=_availDirty[state.evsel]||{})[nm]=1;
  _avMsg=out.length?('Copied your pattern from '+prev.name+' — '+out.length+' block'+(out.length>1?'s':'')+'. Check it, then Submit.')
                   :('Nothing carried over from '+prev.name+' — those hours do not fall inside this event.');
  _avErr=!out.length; save(); renderContent();
}
/* the newest event other than this one where the driver has ticks, with the sizing needed to read them */
function avPreviousEvent(nm){
  const cands=[];
  Object.keys(state.availStore||{}).forEach(function(k){
    if(k===state.evsel) return;
    const slots=(state.availStore[k]||{})[nm]; if(!slots||!slots.length) return;
    const ev=calEvent(k); if(!ev) return;
    const ovr=(state.evTiming||{})[k]||{};
    const winStart=ovr.winStart?Date.parse(ovr.winStart):(ev.winStart?Date.parse(ev.winStart):Date.parse(ev.s+'T00:00:00+10:00'));
    const days=Math.round((Date.parse(ev.e+'T00:00:00Z')-Date.parse(ev.s+'T00:00:00Z'))/86400000)+1;
    cands.push({key:k, name:ev.n, slots:slots, block:avBlockOk(ovr.avBlock)?ovr.avBlock:120,
                winMin:ovr.winMin||ev.winMin||days*1440, winStart:winStart, sort:ev.s});
  });
  cands.sort(function(a,b){ return a.sort<b.sort?1:-1; });
  return cands[0]||null;
}
function renderMyBlocks(a){
  const nm=state.me; const arr=a[nm]||[]; const n=evSlots(); const canEdit=canEditAvail(nm);
  const pr=prefsFor(nm);
  const seg=(axis,opts)=>Object.keys(opts).map(k=>'<button class="btn '+(pr[axis]===k?'btn-amber':'btn-ghost')+' avfree"'+(canEdit?' data-prefset="'+axis+'" data-name="'+esc(nm)+'" data-val="'+k+'"':' disabled')+' style="font-size:10px;padding:5px 11px">'+opts[k]+'</button>').join('');
  const groups=[]; let cur=null;
  for(let i=0;i<n;i++){ const d=fmtDay(i*AV_BLOCK); if(!cur||cur.day!==d){ cur={day:d,slots:[]}; groups.push(cur);} cur.slots.push(i); }
  let h='<div class="importbox">';
  h+='<div class="myblocks-head"><span class="head" style="color:#fff;font-size:15px">'+(isAdmin()?'Editing · ':'Your blocks · ')+esc(nm.split(' ')[0])+(lockedForMe(nm)?' 🔒':'')+'</span>'
    +(canEdit?'<span class="myblocks-btns"><button class="btn btn-amber avfree" data-action="avtickall">Tick all</button><button class="btn btn-ghost avfree" data-action="avclear">Clear</button></span>':'')+'</div>';
  h+='<div class="meta" style="margin:2px 0 4px">Tap every '+fmtBlockLen(AV_BLOCK)+' block you can race ('+tzLabel()+' time), or drag across a row. Then Submit.</div>';
  const seen=avSeenFor(nm);
  if(seen) h+='<div class="meta" style="margin:2px 0 6px;color:var(--green)">Already in — you submitted '+seen.n+' block'+(seen.n===1?'':'s')+' '+esc(seen.ago)+'.</div>';
  if(canEdit){
    const prev=avPreviousEvent(nm);
    h+='<div class="quickrow"><span class="meta" style="width:56px">Quick add</span>'
      +Object.keys(AV_PERIODS).map(function(p){ return '<button class="quickbtn avfree" data-bulk="period" data-p="'+p+'" data-name="'+esc(nm)+'">'+p.charAt(0).toUpperCase()+p.slice(1)+'s</button>'; }).join('')
      +(prev?'<button class="quickbtn avfree" data-bulk="prev" data-name="'+esc(nm)+'" title="match the hours you gave for '+esc(prev.name)+'">Same as '+esc(prev.name.length>22?prev.name.slice(0,21)+'…':prev.name)+'</button>':'')
      +'</div>';
  }
  const hasWx=!!(state.evWeather&&state.evWeather[state.evsel]);
  h+='<div class="meta" style="margin:8px 0 3px;text-transform:uppercase;letter-spacing:.04em">Race preference</div>';
  const evcls=evClasses(calEvent(state.evsel));
  if(evcls.length>1){ const co={}; evcls.forEach(c=>co[c]=c);
    h+='<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:4px"><span class="meta" style="width:56px">Class</span>'+seg('cls',co)+'</div>';
  }
  h+='<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:4px"><span class="meta" style="width:56px">Time</span>'+seg('time',{start:'Start',finish:'Finish',any:'No pref'})+'</div>';
  h+='<div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:8px"><span class="meta" style="width:56px">Weather</span>'+seg('cond',{wet:'Wet',dry:'Dry',any:'Both'})+(hasWx?'':'<span class="meta" style="font-size:10px">· applies once weather is set for this event</span>')+'</div>';
  groups.forEach(function(g){
    h+='<div class="blockday">'+g.day
      +(canEdit?' <button class="quickbtn avfree" data-bulk="day" data-day="'+esc(g.day)+'" data-name="'+esc(nm)+'" style="margin-left:8px;text-transform:none">all day</button>'
                +' <button class="quickbtn avfree" data-bulk="dayoff" data-day="'+esc(g.day)+'" data-name="'+esc(nm)+'" style="text-transform:none">none</button>':'')
      +'</div><div class="blockrow">';
    g.slots.forEach(function(i){
      const on=arr.indexOf(i)>=0;
      const lbl=fmtClock(i*AV_BLOCK).split(' ').slice(1).join(' ')+'–'+fmtClock(Math.min((i+1)*AV_BLOCK,EV_WIN_MIN)).split(' ').slice(1).join(' ');
      h+='<button class="blockcell avfree'+(on?' on':'')+'"'+(canEdit?' data-avtoggle data-name="'+esc(nm)+'" data-slot="'+i+'"':' disabled')+'>'+lbl+'</button>';
    });
    h+='</div>';
  });
  h+='</div>'; return h;
}
function renderAvail(){
  if(!state.evsel) return '<div class="importbox"><div class="meta" style="margin-bottom:10px">No event selected yet.</div><button class="btn btn-amber avfree" data-action="gotoevent">Pick an event first</button></div>';
  const ev=calEvent(state.evsel);
  if(!ev) return '<div class="meta">Selected event not found in the calendar — pick another on the Event tab.</div>';
  const a=state.availStore[state.evsel]=state.availStore[state.evsel]||{};
  const roster=availRoster();
  const n=evSlots();
  let html='<div class="importbox">';
  html+='<div style="display:flex;gap:14px;flex-wrap:wrap;align-items:baseline"><span class="head" style="font-size:17px;color:#fff;text-transform:uppercase">'+esc(ev.n)+'</span>'
    +'<span class="meta">'+esc(ev.track)+' · '+fmtDates(ev.s,ev.e)+(ev.dur?' · '+ev.dur+'h race':'')+'</span></div>';
  const hasIds=Object.keys(ROSTER_IDS||{}).length>0;
  if(!isAdmin() && hasIds && !state.me){ try{ const sid=localStorage.getItem('edrTB_irid'); if(sid&&ROSTER_IDS[sid]) state.me=ROSTER_IDS[sid]; }catch(e){} }   // this device already identified once
  if(isAdmin()){
    html+='<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px"><label class="meta">Editing availability for</label>'
      +'<select class="avfree" data-action="meselect"><option value="">— pick a driver —</option>'
      +roster.map(nm=>'<option value="'+esc(nm)+'"'+(nm===state.me?' selected':'')+'>'+esc(nm)+'</option>').join('')+'</select>'
      +(state.me?'':'<span class="meta">Pick a driver to set their blocks, or just review coverage below.</span>')+'</div>';
  } else if(hasIds){
    if(state.me){
      html+='<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px"><span class="meta">You are</span><span style="font-family:Prompt,sans-serif;font-weight:600;color:#fff">'+esc(state.me)+'</span>'
        +'<span class="meta avfree" data-action="iridchange" style="cursor:pointer;text-decoration:underline">not you?</span></div>';
    } else {
      html+='<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px"><label class="meta">Your iRacing ID</label>'
        +'<input id="iridbox" type="text" inputmode="numeric" placeholder="e.g. 267342" style="padding:7px 10px;font-size:13px;width:130px">'
        +'<button class="btn btn-amber avfree" data-action="iridgo" style="font-size:11px;padding:6px 14px">Find me</button>'
        +'<span class="meta" style="font-size:11px">your customer ID — in iRacing under Helmet → Account</span></div>'
        +(_iridMsg?'<div class="meta" style="margin-top:6px;color:var(--red)">'+esc(_iridMsg)+'</div>':'');
    }
  } else {
    html+='<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:10px"><label class="meta">I am</label>'
      +'<select class="avfree" data-action="meselect"><option value="">— pick your name —</option>'
      +roster.map(nm=>'<option value="'+esc(nm)+'"'+(nm===state.me?' selected':'')+'>'+esc(nm)+'</option>').join('')+'</select>'
      +(state.me?'':'<span class="meta">Pick your name to enter availability.</span>')+'</div>';
  }
  if(isAdmin()){
    html+='<div class="quickrow" style="margin-top:12px"><span class="meta" style="width:56px">Block size</span>'
      +AV_BLOCK_CHOICES.map(function(b){ return '<button class="quickbtn avfree'+(b===AV_BLOCK?' on':'')+'" data-action="avblock" data-b="'+b+'"'
        +(b===AV_BLOCK?' style="border-color:var(--yellow);color:#fff"':'')+'>'+fmtBlockLen(b)+'</button>'; }).join('')
      +'<span class="meta" style="font-size:10px">· existing ticks are rescaled, then need a Submit</span>'
      +'<button class="quickbtn avfree" data-action="avprune" style="margin-left:auto" title="drop stored availability for events that finished over 90 days ago">Clear old events</button></div>';
  }
  html+='</div>';
  // tile picker for the selected person (driver = themself; admin = the driver they chose)
  if(state.me) html+=renderMyBlocks(a);
  else if(isAdmin()) html+='<div class="importbox"><div class="meta">Pick a driver above to set their 2-hour blocks — the coverage below updates as you go.</div></div>';
  // ---- compact team-coverage strip (same availStore data as before; replaces the checkbox grid) ----
  { const cov=[]; let cvd=0;
    for(let i=0;i<n;i++){ let c=0; roster.forEach(nm=>{ if((a[nm]||[]).indexOf(i)>=0)c++; }); cov.push(c); if(c>0)cvd++; }
    const maxc=Math.max(1,Math.max.apply(null,cov));
    html+='<div class="importbox"><div class="meta" style="margin-bottom:8px;text-transform:uppercase;letter-spacing:.04em">Team coverage · '+cvd+'/'+n+' blocks covered</div>';
    let lastDay='', open=false;
    for(let i=0;i<n;i++){ const day=fmtDay(i*AV_BLOCK);
      if(day!==lastDay){ if(open)html+='</div>'; lastDay=day; html+='<div class="blockday">'+day+'</div><div style="display:flex;gap:5px;align-items:flex-end;margin-bottom:8px">'; open=true; }
      const c=cov[i], col=c===0?'var(--red)':c===1?'var(--amber)':'var(--green)', ht=8+Math.round((c/maxc)*40);
      const lbl=fmtClock(i*AV_BLOCK).split(' ').slice(1).join(' ');
      html+='<div style="flex:1;min-width:0;text-align:center" title="'+lbl+' · '+c+' driver'+(c===1?'':'s')+' free">'
        +'<div style="height:'+ht+'px;background:'+col+';border-radius:3px"></div>'
        +'<div class="meta" style="font-size:10px;margin-top:3px;color:#fff">'+c+'</div>'
        +'<div class="meta" style="font-size:8px">'+lbl.replace(':00','')+'</div></div>';
    }
    if(open)html+='</div>';
    html+='<div class="meta" style="font-size:11px;margin-top:2px">Bar = drivers free that 2-hour block · <span style="color:var(--green)">green</span> good, <span style="color:var(--amber)">amber</span> thin, <span style="color:var(--red)">red</span> gap.</div>';
    if(isAdmin()){
      html+='<div style="display:flex;gap:8px;margin-top:12px;align-items:center;flex-wrap:wrap"><input type="text" id="avnewdrv" placeholder="Add a driver by name" style="padding:7px 10px;font-size:12px">'
        +'<button class="btn btn-ghost" data-action="avadddrv" style="font-size:10px;padding:5px 12px">+ Add driver</button></div>';
      if(LOCKED_NAMES.length){
        html+='<div class="meta" style="margin-top:10px">Locked (submitted from their own device): '
          +LOCKED_NAMES.map(nm=>'<span data-action="avrelease" data-name="'+esc(nm)+'" title="release this lock" style="cursor:pointer;text-decoration:underline;margin-right:8px">'+esc(nm)+' 🔓</span>').join('')
          +'— click a name to release its lock (e.g. new device).</div>';
      }
    }
    html+='</div>';
  }
  // coverage summary
  let covered=0, totalHrs=0, avail=0;
  for(let i=0;i<n;i++){ if(roster.some(nm=>(a[nm]||[]).indexOf(i)>=0)) covered++; }
  roster.forEach(nm=>{ const h4=slotsToAvail(a[nm]||[]).hours; totalHrs+=h4; if(h4>0) avail++; });
  html+='<div class="sumgrid">'
    +'<div class="sumcard"><div class="v">'+avail+'</div><div class="k">drivers available</div></div>'
    +'<div class="sumcard"><div class="v">'+totalHrs+'h</div><div class="k">total driver-hours</div></div>'
    +'<div class="sumcard"><div class="v">'+(n?Math.round(covered/n*100):0)+'%</div><div class="k">window coverage</div></div>'
    +'<div class="sumcard"><div class="v">'+covered+'/'+n+'</div><div class="k">blocks covered</div></div>'
    +'</div>';
  html+='<div class="meta" style="margin-top:10px">Availability here feeds the '+(isAdmin()?'Drivers ranking, Teams and Stints tabs directly.':'team plan — the admin builds teams and stints from it.')+'</div>';
  /* Submit rides at the very end, as a direct child of the tab content. position:sticky only
     holds an element inside its own containing block, so while this lived up in the header
     panel it vanished the moment you scrolled down into the grid — which is the entire time
     you are actually ticking blocks. Last child of the tallest box = pinned the whole way. */
  const dirtyN=Object.keys(_availDirty[state.evsel]||{}).length;
  html+='<div class="subbar">'
    +'<button class="btn btn-amber avfree" data-action="avsubmit">Submit availability</button>'
    /* the outcome message must not sit behind the dirty banner: a failed submit always leaves
       the entry dirty, so making these exclusive meant a driver whose save was rejected only
       ever saw "hit Submit" and never learned it had failed. Show both when both apply. */
    +(_avMsg?'<span class="meta" style="color:'+(_avErr?'var(--red)':'var(--green)')+'">'+esc(_avMsg)+'</span>':'')
    +(dirtyN?'<span class="meta" style="color:var(--amber)">Unsaved changes ('+dirtyN+' driver'+(dirtyN>1?'s':'')+') — hit Submit to save for the team.</span>'
      :(_avMsg?'':'<span class="meta">Tick your blocks, then Submit — everyone sees it from then on.</span>'))
    +'</div>';
  return html;
}

function renderSummary(model){
  const classes=Object.keys(model);
  const ev=state.evsel?calEvent(state.evsel):null;
  const eh=document.getElementById('evheading');
  if(eh) eh.innerHTML = ev
    ? '<span style="font-family:\'Prompt\',sans-serif;font-weight:700;font-size:19px;color:var(--yellow);text-transform:uppercase;letter-spacing:.04em">'+esc(ev.n)+'</span>'
      +' <span class="meta" style="font-size:12px">'+esc(ev.track)+' · '+fmtDates(ev.s,ev.e)+(ev.dur?' · '+ev.dur+'h race':'')+'</span>'
    : '<span class="meta" style="color:var(--red);font-size:12px">No event selected — open the Event tab and pick one.</span>';
  document.getElementById('summary').innerHTML =
    '<span>'+state.drivers.length+' drivers · '+classes.length+' classes</span>'+
    classes.map(c=>'<span style="color:var(--dim)">'+esc(c)+'</span>').join('');
}

function carLabel(cls,tier,ti){ const k=cls+'|'+tier+'|'+ti, n=(state.teamNames||{})[k]; return (n&&(''+n).trim())?(''+n).trim():null; }  // custom car name or null
let _renaming=null;  // cls|tier|idx currently being renamed inline
function renderTeams(byId){
  const classes=Object.keys(state.teams);
  if(!classes.length) return '<div class="meta">Hit Generate or load teams.</div>';
  // dropdown lists EVERY car (both tiers, all classes) so any driver can go anywhere
  function moveOpts(curC,curT,curJ){
    let o='';
    classes.forEach(c=>['pro','casual'].forEach(t=>{ (state.teams[c][t]||[]).forEach((_,j)=>{ const v=c+'|'+t+'|'+j; const sel=(c===curC&&t===curT&&j===curJ)?' selected':''; o+='<option value="'+v+'"'+sel+'>'+esc(c)+' '+t[0].toUpperCase()+(j+1)+'</option>'; }); }));
    return o;
  }
  let html='';
  if(isAdmin()){
    html+='<div class="importbox" style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:16px;border-left:4px solid '+(state.teamsLocked?'var(--green)':'var(--line)')+'">'
      +'<button class="btn '+(state.teamsLocked?'btn-amber':'btn-ghost')+'" data-action="teamlock">'+(state.teamsLocked?'🔒 Line-up locked':'🔓 Lock line-up')+'</button>'
      +'<span class="meta" style="max-width:520px">'+(state.teamsLocked
        ?'<b style="color:var(--green)">Locked.</b> Generate and Import will not touch these teams. You can still move drivers by hand, and it stays saved.'
        :'Arrange the cars how you want, then <b style="color:#fff">Lock</b> — after that, Generate and Import leave your line-up alone.')+'</span></div>';
  }
  classes.forEach(cls=>{
    html+='<div style="margin-bottom:26px"><h2 class="classhdr" style="font-size:17px">'+esc(cls)+'</h2>';
    [['pro','PRO','var(--gold)'],['casual','CASUAL','var(--steel)']].forEach(([tier,label,col])=>{
      const list=(state.teams[cls]&&state.teams[cls][tier])||[];
      html+='<div style="margin-bottom:16px"><div style="display:flex;align-items:center;gap:10px;margin-bottom:10px"><span class="swatch" style="background:'+col+'"></span><span class="head" style="letter-spacing:2px;font-size:13px;color:'+col+'">'+label+'</span><button class="btn btn-ghost" data-action="addcar" data-class="'+esc(cls)+'" data-tier="'+tier+'" style="font-size:10px;padding:3px 9px">+ car</button></div><div class="grid">';
      list.forEach((team,ti)=>{
        const members=team.map(id=>byId[id]).filter(Boolean);
        const meds=members.map(m=>m._median).filter(x=>x!=null);
        const avg=meds.length?meds.reduce((a,b)=>a+b,0)/meds.length:null;
        const irs=members.map(m=>m.irating).filter(x=>x!=null&&isFinite(x));
        const avgIR=irs.length?Math.round(irs.reduce((a,b)=>a+b,0)/irs.length):null;
        const cname=carLabel(cls,tier,ti), tag=label[0]+(ti+1), rkey=cls+'|'+tier+'|'+ti;
        const hd=(_renaming===rkey)
          ? '<input class="avfree" data-action="renamesave" data-key="'+rkey+'" value="'+esc(cname||'')+'" placeholder="'+tag+'" style="font-size:14px;padding:3px 7px;width:150px" autofocus>'
          : ((cname?esc(cname)+' <span class="meta" style="font-weight:400;font-size:11px">'+tag+'</span>':tag)+(isAdmin()?' <span data-action="renamecar" data-key="'+rkey+'" title="rename this car" style="cursor:pointer;font-size:12px;opacity:.6">✎</span>':''));
        const irTxt=avgIR!=null?' · iR '+avgIR+(irs.length<members.length?' ('+irs.length+'/'+members.length+')':''):(members.length?' · iR —':'');
        html+='<div class="card"><div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px"><span class="head" style="color:'+col+';letter-spacing:1px">'+hd+'</span><span class="meta">avg '+fmtLap(avg)+irTxt+(members.length?'':' <span data-action="delcar" data-class="'+esc(cls)+'" data-tier="'+tier+'" data-idx="'+ti+'" title="remove empty car" style="color:var(--red);cursor:pointer;font-size:13px">✕</span>')+'</span></div>';
        members.forEach(d=>{
          html+='<div class="mem"><div style="min-width:0"><div style="font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(d.name)+'</div><div style="font-size:10px;color:var(--dim)">'+fmtLap(d._median)+' · '+d._laps+' laps · '+Math.round(d._clean*100)+'% clean'+(d.irating?' · iR '+d.irating:'')+(d.avail?' · <span style="color:'+(d.avail.pct>=80?'var(--green)':d.avail.pct>=40?'var(--amber)':'var(--red)')+'">'+d.avail.pct+'% avail</span>':'')+'</div></div><select data-action="move" data-id="'+d.id+'">'+moveOpts(cls,tier,ti)+'</select></div>';
        });
        if(!members.length) html+='<div class="meta">empty</div>';
        html+='</div>';
      });
      html+='</div></div>';
    });
    html+='</div>';
  });
  return html;
}

function renderDrivers(model){
  let html='';
  const allCars=[...new Set(state.drivers.reduce((a,x)=>a.concat(Object.keys(x.cars||{})),[]))].sort();   // any car driven at this track this season, by anyone on the team
  if(state.evsel){
    const pool=eventPool().length, hidden=state.drivers.length-pool;
    const ev=calEvent(state.evsel);
    html+='<div class="meta" style="margin-bottom:14px">Showing the <b style="color:#fff">'+pool+'</b> driver'+(pool===1?'':'s')+' with availability for <b style="color:var(--yellow)">'+esc(ev?ev.n:state.evsel)+'</b>'+(hidden>0?' · '+hidden+' without availability hidden':'')+'.</div>';
    if(!pool) return html+'<div class="importbox"><div class="meta">No one has submitted availability for this event yet — drivers appear here as soon as they hit Submit on the Availability tab.</div></div>';
  }
  Object.keys(model).forEach(cls=>{
    const grp=model[cls];
    html+='<div style="margin-bottom:18px"><div class="classhdr">'+esc(cls)+' <small>· '+grp.length+' drivers · ranked within class</small></div><div style="display:flex;flex-direction:column;gap:8px">';
    grp.forEach((d,i)=>{
      const cars=Object.keys(d.cars||{}).sort((a,b)=>((d.cars[a].medianLap==null?1e9:d.cars[a].medianLap)-(d.cars[b].medianLap==null?1e9:d.cars[b].medianLap)));
      let opts=cars.map(c=>'<option value="'+esc(c)+'"'+(c===d.assignedCar?' selected':'')+'>'+esc(c)+'</option>').join('');
      const others=allCars.filter(c=>!(d.cars&&d.cars[c]));
      if(others.length) opts+='<optgroup label="— any car at this track —">'+others.map(c=>'<option value="'+esc(c)+'"'+(c===d.assignedCar?' selected':'')+'>'+esc(c)+' (no laps)</option>').join('')+'</optgroup>';
      html+='<div class="row '+d._tier+'"><span class="meta" style="width:20px">#'+(i+1)+'</span><span style="font-size:13px;min-width:110px">'+esc(d.name)+'</span><select data-action="assign" data-id="'+d.id+'">'+opts+'</select>'+(isAdmin()?'<span data-action="carlock" data-id="'+d.id+'" title="'+(d.carLock?'car locked — imports keep this choice; click to unlock':'lock this car choice so imports keep it')+'" style="cursor:pointer;font-size:12px;opacity:'+(d.carLock?'1':'.4')+'">'+(d.carLock?'🔒':'🔓')+'</span>':(d.carLock?'<span title="car locked by admin" style="font-size:12px">🔒</span>':''))+'<span class="meta">'+fmtLap(d._median)+' · '+d._laps+' laps · '+Math.round(d._clean*100)+'% clean'+(d.avail?' · '+d.avail.pct+'% avail':'')+'</span><span class="tier '+d._tier+'">'+d._tier.toUpperCase()+' · '+(d._score*100).toFixed(0)+'</span><button class="x" data-action="remove" data-id="'+d.id+'">✕</button></div>';
    });
    html+='</div></div>';
  });
  html+=renderDriverAdmin();
  return html;
}
/* Admin-only roster management. The builder pulls its driver list from Garage 61 and from
   whoever submits availability, so it will happily surface people who have left, test
   accounts, or a duplicate the APIs keep re-creating. Removing writes a name key to
   state.excluded, which survives re-imports — deleting the row alone would not, because the
   next import or availability submission puts them straight back. */
function renderDriverAdmin(){
  if(!isAdmin()) return '';
  const ex=excludedMap(), keys=Object.keys(ex);
  let h='<div class="importbox" style="margin-top:16px">';
  h+='<div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">Manage drivers</div>';
  h+='<div class="meta" style="font-size:10.5px;margin-bottom:8px">Remove anyone who should not be in the team builder. They stay out through imports and availability submissions, and nothing is deleted — you can put them back below.</div>';
  const list=(state.drivers||[]).slice().sort(function(a,b){ return a.name.localeCompare(b.name); });
  if(!list.length) h+='<div class="meta">No drivers in the pool yet.</div>';
  else {
    h+='<div class="wkser">';
    list.forEach(function(d){
      const laps=Object.keys(d.cars||{}).reduce(function(t,c){ return t+((d.cars[c]&&d.cars[c].laps)||0); },0);
      const hrs=(d.avail&&d.avail.hours)||0;
      h+='<label style="justify-content:space-between"><span>'+esc(d.name)
        +'<span class="st"> · '+laps+' laps'+(hrs?' · '+hrs+'h avail':'')+'</span></span>'
        +'<button class="quickbtn avfree" data-action="drvremove" data-n="'+esc(d.name)+'" title="remove from the team builder" style="color:var(--red);border-color:rgba(255,90,90,.4)">remove</button></label>';
    });
    h+='</div>';
  }
  if(keys.length){
    h+='<div class="meta" style="text-transform:uppercase;letter-spacing:.04em;margin:12px 0 4px">Removed</div><div class="quickrow">';
    keys.forEach(function(k){
      h+='<button class="quickbtn avfree" data-action="drvrestore" data-k="'+esc(k)+'" title="put this driver back">'+esc(ex[k]||k)+' ✕</button>';
    });
    h+='</div>';
  }
  h+='</div>';
  return h;
}

// ---- stint planning ----
function fmtClock(absMin){
  const d=new Date(WIN_START_MS + absMin*60000);
  return d.toLocaleString('en-AU',{timeZone:tzZone(),weekday:'short',hour:'2-digit',minute:'2-digit',hour12:false});
}
function availBadge(d){ return d.avail ? d.avail.pct+'%' : 'no avail'; }
function driverFree(d,s,e){ return !!(d.avail && d.avail.windows && d.avail.windows.some(w=>w[0]<=s && w[1]>=e)); }
function isWetStint(s,e){ if(!(state.evWeather&&state.evWeather[state.evsel])) return false; if(typeof weatherAt!=='function') return false; const wx=weatherAt(s); return !!(wx&&wx.wet); }
function applyIrWeather(ev, se){  // map an iRacing schedule weather{} onto state.evWeather (F7 auto-pull)
  const w=se&&se.weather; if(!w) return;
  let startTod=null; if(w.simulated_start_time){ const m=(''+w.simulated_start_time).match(/T(\d\d):(\d\d)/); if(m) startTod=(+m[1])*60+(+m[2]); }
  let temp=(w.temp_value!=null)?+w.temp_value:null; if(temp!=null && (+w.temp_units)===0) temp=Math.round((temp-32)*5/9);  // iRacing 0 = Fahrenheit
  let pct=null; const ws=w.weather_summary||{};
  if(ws.precip_chance!=null){ pct=+ws.precip_chance; if(pct>0&&pct<1) pct=pct*100;   // 0.35 -> 35, but integer 1 stays 1%
    pct=Math.max(0,Math.min(100,Math.round(pct))); }
  // "wet" means rain is LIKELY — a 1% chance must not paint the whole race wet
  const wetBase = (pct!=null) ? pct>=50 : (((+w.precip_option)>0)||(w.forecast_options&&(+w.forecast_options.precipitation)>0));
  state.evWeather[evKey(ev)]={ src:'iracing', startTod:(startTod!=null?startTod:720), mult:(+w.simulated_time_multiplier)||1, tempC:temp, wet:!!wetBase, rainPct:pct, todOffsets:(Array.isArray(w.simulated_time_offsets)?w.simulated_time_offsets.map(Number):null) };
}
function blockTimes(off,len,race){ const n=Math.ceil(race/len),t=[]; for(let i=0;i<n;i++)t.push({s:off+i*len,e:off+Math.min((i+1)*len,race)}); return t; }
/* ---- weather (F7): maps a stint's clock offset to sim conditions for the event ---- */
function weatherAt(absMin, raceStartOff, winNo){
  const w=state.evWeather&&state.evWeather[state.evsel]; if(!w) return null;
  const off=(raceStartOff!=null)?raceStartOff:(START_OFFSETS[state.stint.window]||0);
  const elapsed=Math.max(0, absMin-off);                     // real minutes since this car's green flag
  const mult=(+w.mult)||1;                                   // sim minutes per real minute (day/night rollover)
  const winAdd=(w.todOffsets&&winNo!=null&&isFinite(w.todOffsets[winNo-1]))?+w.todOffsets[winNo-1]:0;   // each start window is its own session with its own sim clock
  const todMin=((((+w.startTod||0) + winAdd + elapsed*mult)%1440)+1440)%1440;
  const night = todMin<6*60 || todMin>=19*60;
  const wet = !!w.wet || (w.wetFrom!=null && w.wetFrom!=='' && elapsed>=(+w.wetFrom));
  const hh=Math.floor(todMin/60), mm=Math.round(todMin%60);
  const clk=(hh<10?'0':'')+hh+':'+(mm<10?'0':'')+mm;
  const pct=(w.rainPct!=null&&w.rainPct!=='')?Math.round(+w.rainPct):null;
  const icon = wet?'🌧':(night?'🌙':'☀');
  let label = wet?(clk+' wet'):(night?(clk+' night'):(clk+(w.tempC!=null&&w.tempC!==''?' '+w.tempC+'°':'')));
  if(pct!=null&&pct>0) label+=' · '+pct+'%';   // rain probability, so "wet" vs "1% chance" is unambiguous
  return { todMin, night, wet, rainPct:pct, tempC:w.tempC, clk, icon, label };
}
function carBestWindow(memberIds, byId, len, race){   // window with fewest uncovered blocks for this car
  let best=null;
  Object.keys(START_OFFSETS).forEach(w=>{
    const times=blockTimes(START_OFFSETS[w],len,race);
    const gaps=times.filter(t=>!memberIds.some(id=>{const m=byId[id];return m&&driverFree(m,t.s,t.e);})).length;
    if(!best || gaps<best.gaps) best={w:+w,gaps};
  });
  return best;
}
function autoPlan(memberIds, byId, times){
  const members=memberIds.map(id=>byId[id]).filter(Boolean);
  const count={}; members.forEach(m=>count[m.id]=0);
  const B=0.08, n=times.length;                       // soft preference bias (F9): breaks ties, never outranks a clearly better driver
  const pref={}; members.forEach(m=>pref[m.id]=prefsFor(m.name));
  const arr=[]; let prev=null;
  times.forEach(({s,e},i)=>{
    const wet=isWetStint(s,e);
    const bias=m=>{ const p=pref[m.id]||{time:'any',cond:'any'}; let b=0;
      if(n>1){ if(p.time==='start') b+=B*(1-i/(n-1)); else if(p.time==='finish') b+=B*(i/(n-1)); }
      if(wet){ if(p.cond==='wet') b+=B; else if(p.cond==='dry') b-=B; }
      return b; };
    const elig=members.filter(m=>driverFree(m,s,e));
    let pool=elig.filter(m=>m.id!==prev); if(!pool.length) pool=elig;  // avoid back-to-back unless forced
    let pick=null;
    if(pool.length){ pool.sort((a,b)=>(count[a.id]-count[b.id])||((b._score+bias(b))-(a._score+bias(a)))); pick=pool[0]; count[pick.id]++; }  // count-balance stays primary
    prev=pick?pick.id:null; arr.push(pick?pick.id:null);
  });
  return arr;
}
function allTeams(){
  const list=[];
  Object.keys(state.teams).forEach(cls=>['pro','casual'].forEach(tier=>{
    (state.teams[cls]&&state.teams[cls][tier]||[]).forEach(t=>{ if(t.length) list.push(t); });
  }));
  return list;
}
function windowSummary(byId, len, race){
  const teamsList=allTeams();
  const allIds=[...new Set(teamsList.reduce((a,t)=>a.concat(t),[]))];
  return Object.keys(START_OFFSETS).map(w=>{
    const off=START_OFFSETS[w], times=blockTimes(off,len,race);
    const free=allIds.filter(id=>{const m=byId[id]; return m&&driverFree(m,off,off+race);}).length;
    let covered=0;
    teamsList.forEach(team=>{ const mem=team.map(id=>byId[id]).filter(Boolean); if(times.every(t=>mem.some(m=>driverFree(m,t.s,t.e)))) covered++; });
    return {w:+w, off, free, covered, cars:teamsList.length, total:allIds.length};
  });
}
/* ---- fuel / laps / pit model (F4/5/6): laps from pace, fuel + pit from config ---- */
function resolveFuel(car){ const f=state.fuelCfg||{}; const bc=(f.byCar||{})[car]||{}, cl=(f.byClass||{})[classOf(car||'')]||{}; return { tankL:+bc.tankL||+cl.tankL||+f.tankL||0, fuelPerLap:+bc.fuelPerLap||+cl.fuelPerLap||+f.fuelPerLap||0 }; }
function stintLaps(blockSec, median){ return (median>0)?Math.floor(blockSec/median):0; }
function carFuelPlan(times, arr, byId){
  const perBlock=[]; let cum=0, pits=0, totLaps=0, totFuel=0, anyCfg=false;
  times.forEach((t,i)=>{
    const id=arr[i], m=(id!=null)?byId[id]:null;
    const med=(m&&isFinite(m._median))?m._median:null;
    const fu=m?resolveFuel(m._car):{tankL:0,fuelPerLap:0};
    if(fu.tankL>0&&fu.fuelPerLap>0) anyCfg=true;
    const laps=med?stintLaps((t.e-t.s)*60, med):0;
    const fuel=laps*(fu.fuelPerLap||0);
    totLaps+=laps; totFuel+=fuel;
    let pit=false;
    if(fu.tankL>0 && fu.fuelPerLap>0){ cum+=fuel; if(cum>fu.tankL){ pit=true; pits++; cum=cum-fu.tankL; } }
    perBlock.push({laps, fuel:Math.round(fuel*10)/10, pit});
  });
  const pitLoss=(state.fuelCfg&&+state.fuelCfg.pitLossSec)||0;
  return { perBlock, totLaps, totFuel:Math.round(totFuel), pits, lostSec:pits*pitLoss, anyCfg };
}
function fmtLost(sec){ if(!sec) return '0s'; const m=Math.floor(sec/60), s=sec%60; return m ? (m+'m'+(s?(' '+s+'s'):'')) : (s+'s'); }
function renderStints(byId){
  const len=Math.max(10,state.stint.len), race=Math.max(30,state.stint.race);
  const sig=[len,race].join('|');
  if(!state.stintsLocked && state.stintSig!==sig){ state.stintAssign={}; state.stintSig=sig; }  // block/race length changed -> fresh auto-plan; team moves do NOT wipe manual stints (moved-out drivers render as gaps)
  let html='<div class="importbox" style="display:flex;gap:18px;flex-wrap:wrap;align-items:flex-end">';
  html+='<div class="ctl"><label>DEFAULT START (LOCAL · UTC)</label><select data-action="stintwin">'+
    Object.keys(START_OFFSETS).map(Number).map(w=>'<option value="'+w+'"'+(w===state.stint.window?' selected':'')+'>#'+w+' · '+START_LABELS[w]+'</option>').join('')+'</select></div>';
  html+='<div class="ctl"><label>BLOCK LENGTH (min)</label><input type="number" min="10" max="240" step="5" value="'+state.stint.len+'" data-action="stintlen" style="width:90px;padding:6px"></div>';
  html+='<div class="ctl"><label>RACE LENGTH (min)</label><input type="number" min="30" max="1440" step="10" value="'+state.stint.race+'" data-action="stintrace" style="width:90px;padding:6px"></div>';
  if(isAdmin()){
    const fc=state.fuelCfg||{};
    html+='<div class="ctl"><label>TANK (L)</label><input type="number" min="0" step="1" value="'+(fc.tankL||'')+'" placeholder="—" data-action="fueltank" style="width:74px;padding:6px"></div>';
    html+='<div class="ctl"><label>FUEL / LAP (L)</label><input type="number" min="0" step="0.1" value="'+(fc.fuelPerLap||'')+'" placeholder="—" data-action="fuelperlap" style="width:74px;padding:6px"></div>';
    html+='<div class="ctl"><label>PIT LOSS (s)</label><input type="number" min="0" step="1" value="'+(fc.pitLossSec||'')+'" data-action="fuelpit" style="width:74px;padding:6px"></div>';
  }
  html+='<button class="btn btn-ghost" data-action="stintreset" style="align-self:center">Auto-fill all</button>';
  if(isAdmin()) html+='<button class="btn '+(state.stintsLocked?'btn-amber':'btn-ghost')+'" data-action="stintlock" style="align-self:center">'+(state.stintsLocked?'🔒 Stints locked':'🔓 Lock stints')+'</button>';
  html+='<div class="meta" style="align-self:center;max-width:360px"><b style="color:#fff">Each car can run a different session.</b> Pick its start below (or set a default for all). Clock = '+tzLabel()+'. Drag blocks or bank names, or click a driver\'s lane to hand them that stint.</div>';
  html+='</div>';
  if(isAdmin()){
    const w=(state.evWeather&&state.evWeather[state.evsel])||{};
    const tod=(w.startTod!=null&&w.startTod!=='')?((('0'+Math.floor(w.startTod/60)).slice(-2))+':'+(('0'+(w.startTod%60)).slice(-2))):'';
    html+='<div class="importbox" style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end;margin-bottom:14px"><div class="meta" style="width:100%;text-transform:uppercase;letter-spacing:.04em;margin-bottom:2px">Event weather — '+(w.src==='iracing'?'<span style="color:var(--green)">pulled from iRacing automatically</span>':(w.src==='manual'?'manual override':'auto-pulls from iRacing on the site'))+' · drivers see day/night and wet per stint</div>'
      +'<div class="ctl"><label>START (local, HH:MM)</label><input type="time" value="'+tod+'" data-action="wxstart" style="padding:6px"></div>'
      +'<div class="ctl"><label>TEMP (°C)</label><input type="number" step="1" value="'+(w.tempC!=null?w.tempC:'')+'" placeholder="—" data-action="wxtemp" style="width:74px;padding:6px"></div>'
      +'<div class="ctl"><label>SIM MULT</label><input type="number" step="0.5" min="1" value="'+(w.mult||'')+'" placeholder="1" data-action="wxmult" style="width:74px;padding:6px"></div>'
      +'<div class="ctl"><label>TURNS WET AT (min)</label><input type="number" step="10" value="'+(w.wetFrom!=null?w.wetFrom:'')+'" placeholder="dry" data-action="wxwetfrom" style="width:90px;padding:6px"></div>'
      +'<div class="ctl"><label>RAIN CHANCE (%)</label><input type="number" min="0" max="100" step="5" value="'+(w.rainPct!=null?w.rainPct:'')+'" placeholder="—" data-action="wxrain" style="width:74px;padding:6px"></div>'
      +'<label class="meta" style="align-self:center"><input type="checkbox" data-action="wxwet"'+(w.wet?' checked':'')+'> wet from start</label>'
      +(Object.keys(w).length?'<span class="meta" style="cursor:pointer;text-decoration:underline;align-self:center" data-action="wxclear">clear</span>':'')
      +'</div>';
  }
  const classes=Object.keys(state.teams);
  if(!classes.length) return html+'<div class="meta">Hit Generate to build teams first.</div>';
  // driver bank — drag any name onto any stint block
  const bankByCls={}; Object.values(byId).forEach(d=>{(bankByCls[d._class]=bankByCls[d._class]||[]).push(d);});
  Object.keys(bankByCls).forEach(c=>bankByCls[c].sort((a,b)=>a.name.localeCompare(b.name)));
  html+='<div class="importbox" style="margin-bottom:16px"><div class="meta" style="margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em">Driver bank — drag a name onto any block. (P)=Pro (C)=Casual</div><div style="display:flex;flex-wrap:wrap;align-items:center;gap:2px">';
  Object.keys(bankByCls).sort().forEach(c=>{
    html+='<span class="meta" style="margin:0 4px">'+esc(c)+'</span>';
    html+=bankByCls[c].map(d=>'<span class="chip" data-bankchip data-driver="'+d.id+'" style="cursor:grab;user-select:none;touch-action:none">'+esc(d.name.split(' ')[0])+(d._tier==='pro'?' (P)':' (C)')+'</span>').join('');
  });
  html+='<span class="chip" data-bankchip data-driver="" style="cursor:grab;user-select:none;touch-action:none;color:var(--red);margin-left:8px">✕ empty</span></div></div>';
  const PALETTE=['#6ea8ff','#5fd38a','#ffb454','#d78cff','#4fd1c5','#ff8fa3','#c8e05a','#9aa3c0'];
  classes.forEach(cls=>{
    [['pro','PRO','var(--gold)'],['casual','CASUAL','var(--steel)']].forEach(([tier,label,col])=>{
      const list=(state.teams[cls]&&state.teams[cls][tier])||[];
      list.forEach((team,ti)=>{
        const members=team.map(id=>byId[id]).filter(Boolean);
        if(!members.length) return;
        const mem=new Set(members.map(m=>m.id));
        const key=cls+'|'+tier+'|'+ti;
        const win=state.stintWin[key]||state.stint.window;
        const off=START_OFFSETS[win]||0;
        const times=blockTimes(off,len,race);
        if(!state.stintsLocked && (!state.stintAssign[key] || state.stintAssign[key].length!==times.length)) state.stintAssign[key]=autoPlan(team,byId,times);
        else if(!state.stintAssign[key]) state.stintAssign[key]=Array(times.length).fill(null);  // locked + new car -> empty, fill by hand
        const arr=state.stintAssign[key];
        const carCounts={}; members.forEach(m=>{ if(m._car) carCounts[m._car]=(carCounts[m._car]||0)+1; });
        const carName=Object.keys(carCounts).sort((a,b)=>carCounts[b]-carCounts[a])[0]||'';
        const fp=carFuelPlan(times,arr,byId);
        const colr={}; members.forEach((m,i)=>colr[m.id]=PALETTE[i%PALETTE.length]);
        const count={}; members.forEach(m=>count[m.id]=0); arr.forEach(id=>{ if(id!=null && count[id]!=null) count[id]++; });
        let gaps=0, conflicts=0;
        arr.forEach((id,i)=>{ const t=times[i]; if(id==null||!byId[id]||!mem.has(id)){ gaps++; return; } if(!driverFree(byId[id],t.s,t.e)) conflicts++; });
        const badge = gaps? '<span class="meta" style="color:var(--red)">'+gaps+' empty</span>' : conflicts? '<span class="meta" style="color:var(--red)">'+conflicts+' conflict'+(conflicts>1?'s':'')+'</span>' : '<span class="meta" style="color:var(--green)">all covered</span>';
        const best=carBestWindow(team,byId,len,race);
        const winTabs='<span style="display:inline-flex;gap:5px;flex-wrap:wrap;align-items:center"><span class="meta" style="font-size:9px;text-transform:uppercase;letter-spacing:.06em">start</span>'+Object.keys(START_OFFSETS).map(Number).map(w=>{
          const on=w===win, isBest=best&&best.w===w;
          return '<button class="btn '+(on?'btn-amber':'btn-ghost')+'" data-action="carwin" data-key="'+key+'" data-win="'+w+'" title="start '+START_LABELS[w]+(isBest?' · best coverage for this car':'')+'" style="font-size:10px;padding:5px 10px">'+START_LABELS[w]+(isBest?' <span style="color:'+(on?'#0a0a0a':'var(--green)')+'">●</span>':'')+'</button>';
        }).join('')+'</span>';
        html+='<div class="stintcar"><div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;flex-wrap:wrap"><span class="swatch" style="background:'+col+'"></span><span class="head" style="letter-spacing:.04em;color:#fff;font-size:15px">'+(_renaming===key
          ? esc(cls)+' · <input class="avfree" data-action="renamesave" data-key="'+key+'" value="'+esc(carLabel(cls,tier,ti)||'')+'" placeholder="'+label[0]+(ti+1)+'" style="font-size:13px;padding:3px 7px;width:150px">'
          : esc(cls)+' · '+(carLabel(cls,tier,ti)?esc(carLabel(cls,tier,ti))+' <span class="meta" style="font-size:11px">'+label[0]+(ti+1)+'</span>':label[0]+(ti+1))+(isAdmin()?' <span data-action="renamecar" data-key="'+key+'" title="rename this car" style="cursor:pointer;font-size:12px;opacity:.6">✎</span>':''))+'</span>'+winTabs+badge+(fp.anyCfg?'<span class="meta" style="color:var(--dim)">⛽ '+fp.totLaps+' laps · '+fp.totFuel+'L · '+fp.pits+' stop'+(fp.pits===1?'':'s')+(fp.lostSec?' ('+fmtLost(fp.lostSec)+' lost)':'')+'</span>':'')+'</div>';
        if(isAdmin()&&carName){ const bc=(state.fuelCfg.byCar||{})[carName]||{}; const def=resolveFuel(carName);
          html+='<div class="carfuel"><span class="meta" style="font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:var(--yellow)">'+esc(carName)+'</span>'
            +'<label>tank <input type="number" min="0" step="1" value="'+(bc.tankL||'')+'" placeholder="'+(def.tankL||'—')+'" data-action="cartank" data-car="'+esc(carName)+'">L</label>'
            +'<label>per lap <input type="number" min="0" step="0.1" value="'+(bc.fuelPerLap||'')+'" placeholder="'+(def.fuelPerLap||'—')+'" data-action="carfuel" data-car="'+esc(carName)+'">L</label>'
            +'<span class="meta" style="font-size:10px">blank = global default</span></div>';
        }
        html+='<div class="stintwrap" data-key="'+key+'"><div class="stintgrid" style="grid-template-columns:150px repeat('+times.length+',minmax(84px,1fr))">';
        html+='<div class="sg-corner">stint →</div>';
        times.forEach((t,i)=>{ const wx=weatherAt(t.s,off,win); html+='<div class="sg-time"><b>'+(i+1)+'</b>'+fmtClock(t.s)+(wx?'<div style="font-size:9px;color:'+(wx.wet?'#6ea8ff':wx.night?'var(--dim)':'var(--amber)')+'">'+wx.icon+' '+wx.label+'</div>':'')+'</div>'; });
        html+='<div class="sg-label" style="font-family:Prompt;font-weight:600;color:#fff;text-transform:uppercase;font-size:11px;letter-spacing:.05em">Driving</div>';
        arr.forEach((id,i)=>{
          const t=times[i], m=(id!=null&&mem.has(id))?byId[id]:null;
          const free=m?driverFree(m,t.s,t.e):false;
          html+='<div class="sg-block'+(m?(free?'':' conflict'):' empty')+'" data-stintcell data-key="'+key+'" data-block="'+i+'" data-driver="'+(m?id:'')+'" style="--dc:'+(m?colr[id]:'transparent')+'" title="'+(m?(free?'available · drag to move or swap':'NOT available this block'):'empty · drag a driver here')+'">'+(m?esc(m.name.split(' ')[0])+(free?'':' <span class="warn">!</span>'):'+')+'</div>';
        });
        members.forEach(m=>{
          html+='<div class="sg-label"><span class="sg-dot" style="background:'+colr[m.id]+'"></span><span style="overflow:hidden;text-overflow:ellipsis">'+esc(m.name.split(' ')[0])+'</span><span class="meta">'+(count[m.id]||0)+'× · '+availBadge(m)+'</span></div>';
          times.forEach((t,i)=>{
            const free=driverFree(m,t.s,t.e), driving=arr[i]===m.id;
            html+='<div class="sg-lane '+(driving?'driving':free?'free':'busy')+'" data-lanecell data-key="'+key+'" data-block="'+i+'" data-driver="'+m.id+'" style="--dc:'+colr[m.id]+'" title="'+esc(m.name.split(' ')[0])+' · stint '+(i+1)+' · '+(free?'available':'not available')+(driving?' · driving, click to clear':' · click to assign')+'"></div>';
          });
        });
        if(fp.anyCfg){
          html+='<div class="sg-label" style="color:var(--dim);font-size:10px;text-transform:uppercase;letter-spacing:.04em">Fuel / laps</div>';
          fp.perBlock.forEach(b=>{ html+='<div style="font-size:9px;color:var(--dim);text-align:center;padding:3px 2px;border-top:1px solid #1a1a1a" title="'+b.laps+' laps · '+b.fuel+'L this stint'+(b.pit?' · pit stop':'')+'">'+(b.laps?b.laps+' · '+b.fuel+'L':'—')+(b.pit?'<br><span style="color:var(--amber)">⛽ pit</span>':'')+'</div>'; });
        }
        html+='</div></div>';
        html+='<div class="meta" style="margin-top:10px">Lanes: <span style="color:var(--green)">green = available</span> · striped = not free · solid = driving that stint. Click a lane cell to assign, drag blocks to swap, or drag names from the bank.</div></div>';
      });
    });
  });
  return html;
}

function renderContent(){
  (document.getElementById('edr-tb-app')||document.body).classList.toggle('readonly', !isAdmin());
  const model=computeModel();
  const byId={}; Object.keys(model).forEach(c=>model[c].forEach(d=>byId[d.id]=d));
  renderSummary(model);
  const el=document.getElementById('content');
  const _sx={}; el.querySelectorAll('.stintwrap[data-key]').forEach(w=>{ if(w.scrollLeft) _sx[w.dataset.key]=w.scrollLeft; });   // keep horizontal scroll across re-renders
  el.innerHTML = state.tab==='setup' ? renderSetup() : state.tab==='weekly' ? renderWeekly() : state.tab==='event' ? renderEventTab() : state.tab==='availability' ? renderAvail() : state.tab==='teams' ? renderTeams(byId) : state.tab==='stints' ? renderStints(byId) : state.tab==='instructions' ? renderInstructions() : renderDrivers(model);
  if(Object.keys(_sx).length) el.querySelectorAll('.stintwrap[data-key]').forEach(w=>{ const v=_sx[w.dataset.key]; if(v!=null) w.scrollLeft=v; });
}

function setStatus(t){ const s=document.getElementById('status'); s.textContent=t; if(t) setTimeout(()=>{if(s.textContent===t)s.textContent='';},3000); }

function syncControls(){
  document.getElementById('pace').value=state.w.pace; document.getElementById('lpace').textContent=state.w.pace;
  document.getElementById('clean').value=state.w.clean; document.getElementById('lclean').textContent=state.w.clean;
  document.getElementById('prep').value=state.w.prep; document.getElementById('lprep').textContent=state.w.prep;
  document.getElementById('propct').value=state.proPct; document.getElementById('lpro').textContent=state.proPct;
}

// ---- wire up ----
['pace','clean','prep'].forEach(k=>{
  document.getElementById(k).addEventListener('input',e=>{
    state.w[k]=+e.target.value; document.getElementById('l'+k).textContent=state.w[k]; save(); renderContent();
  });
});
document.getElementById('propct').addEventListener('input',e=>{
  state.proPct=+e.target.value; document.getElementById('lpro').textContent=state.proPct; save(); renderContent();
});
document.getElementById('gen').addEventListener('click',()=>{ if(state.teamsLocked && Object.keys(state.teams||{}).length){ state.tab='teams'; setActiveTab(); renderContent(); setStatus('Line-up is locked — unlock it on the Teams tab to regenerate.'); return; } generate(); state.tab='teams'; setActiveTab(); save(); renderContent(); });
document.getElementById('reset').addEventListener('click',()=>{ seed(SAMPLE); state.w={pace:50,clean:30,prep:20}; state.proPct=40; syncControls(); generate(); save(); renderContent(); setStatus('Reset to sample'); });
document.getElementById('imp').addEventListener('click',()=>{ document.getElementById('importbox').classList.toggle('hide'); });
document.getElementById('load').addEventListener('click',()=>{
  try{
    const arr=JSON.parse(document.getElementById('importtext').value);
    if(!Array.isArray(arr)||!arr.length) throw new Error('expected a non-empty list');
    let id=1;
    const prevByKey={}; state.drivers.forEach(d=>prevByKey[nameKey(d.name)]=d);   // keep locked car choices across imports
    state.drivers=arr.map(r=>{ const prev=prevByKey[nameKey(String(r.name||''))]; const cars=(r.cars&&typeof r.cars==='object')?r.cars:{};
      const locked=!!(prev&&prev.carLock); const keep=(locked&&prev.assignedCar&&cars[prev.assignedCar])?prev.assignedCar:null;
      return {id:id++,name:String(r.name||('Driver '+id)),cars:cars,assignedCar:keep||lastCar(cars),avail:r.avail||null,irating:(typeof r.irating==='number'?r.irating:(prev?prev.irating:null)),carLock:locked}; });
    generate(); save(); document.getElementById('importbox').classList.add('hide'); renderContent();
    setStatus('Imported '+state.drivers.length+' drivers');
  }catch(e){ setStatus('Import failed: '+e.message); }
});

document.querySelectorAll('.tab').forEach(t=>t.addEventListener('click',()=>{ state.tab=t.dataset.tab; setActiveTab(); renderContent(); }));
function setActiveTab(){
  document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.tab===state.tab));
  if(state.tab==='stints') markStintsSeen();
  paintTabBadges();
  /* the tab in the URL, so "fill in your availability: <link>#availability" from Discord lands
     on the right screen instead of the Instructions page */
  try{ if(location.hash.slice(1)!==state.tab) history.replaceState(null,'','#'+state.tab); }catch(e){}
}
/* a tick once this driver has submitted for the selected event, and a dot on Stints when the
   plan has moved since they last looked — the two things a driver actually needs to notice */
function paintTabBadges(){
  const submitted = !!(state.me && state.evsel && ((state.availStore[state.evsel]||{})[state.me]||[]).length
                       && !((_availDirty[state.evsel]||{})[state.me]));
  const changed = stintsChanged();
  document.querySelectorAll('.tab').forEach(function(t){
    const old=t.querySelector('.tabtick,.tabdot'); if(old) old.remove();
    if(t.dataset.tab==='availability' && submitted){ const s=document.createElement('span'); s.className='tabtick'; s.textContent='✓'; s.title='you have submitted for this event'; t.appendChild(s); }
    if(t.dataset.tab==='stints' && changed){ const s=document.createElement('span'); s.className='tabdot'; s.title='the stint plan changed since you last looked'; t.appendChild(s); }
  });
}
function stintSeenKey(){ return 'edrTB_stintSeen_'+(state.evsel||''); }
function stintFingerprint(){
  /* PLAN_REV is declared by the WordPress layer only — never redeclare it here, the two
     builds share one scope and a second declaration is a SyntaxError that kills the app */
  const rev=(typeof PLAN_REV==='number')?PLAN_REV:0;
  try{ return JSON.stringify(state.stintAssign||{}).length+':'+JSON.stringify(state.stintWin||{}).length+':'+rev; }
  catch(e){ return ''; }
}
function stintsChanged(){
  if(!state.evsel) return false;
  try{ const seen=localStorage.getItem(stintSeenKey()); return !!seen && seen!==stintFingerprint(); }catch(e){ return false; }
}
function markStintsSeen(){ try{ localStorage.setItem(stintSeenKey(), stintFingerprint()); }catch(e){} }
/* WP build overrides: asks the server to drop availability for long-past events */
function pruneOldEvents(){}
/* WP build overrides: the results sweep needs the iRacing proxy, which the standalone has no
   access to. Left as a no-op so the button is inert rather than throwing. */
function cacheDraft(text){ return Promise.resolve(false); }   /* WP build overrides: stores the draft for the scheduled Discord post. false = nothing was stored, so the tab shows no "saved" stamp */
function postDraftToDiscord(){ _wkMsg='Posting to Discord needs the WordPress build.'; _wkErr=true; renderContent(); }
function snapshotRatings(){ _wkMsg='Ratings snapshots need the WordPress build.'; _wkErr=true; renderContent(); }
function refreshRecap(){ RECAP_ERR='Last week\'s results need the iRacing proxy — WordPress build only.'; renderContent(); }
function refreshHistory(){ HIST_ERR='Team history needs the iRacing proxy — WordPress build only.'; renderContent(); }
function composeDraft(){ _wkMsg='Compose with AI needs the WordPress build and a Gemini key.'; _wkErr=true; renderContent(); }
/* a tab named in the URL (#availability), but only if that tab exists in this build — the
   WordPress build has Setup and the standalone does not */
function tabFromHash(){
  try{ const h=(location.hash||'').slice(1);
    return (h && document.querySelector('.tab[data-tab="'+h+'"]')) ? h : '';
  }catch(e){ return ''; }
}

/* The search box re-renders the whole tab on every keystroke, which throws focus and caret
   away with the old DOM — put both back or it is unusable after one character. */
document.getElementById('content').addEventListener('input',function(e){
  if(!e.target) return;
  /* Both write-up boxes are captured on every keystroke, and neither re-renders: the tab is
     rebuilt from a string, so a re-render replaces the textarea and drops the caret at the end.
     Only the one-line counter is refreshed. */
  if(e.target.id==='wkfinal'){ _wkFinal=e.target.value||''; wkSyncCount(); wkPersistPost(); return; }
  if(e.target.id==='wkdraft'){ _wkDraft=e.target.value||''; wkSyncCount(); wkPersistPost(); return; }
  if(!e.target.dataset||e.target.dataset.action!=='wkq') return;
  _wkQ=e.target.value||'';
  const pos=e.target.selectionStart;
  renderContent();
  const el=document.getElementById('wkq');
  if(el){ el.focus(); try{ el.setSelectionRange(pos,pos); }catch(_e){} }
});
/* Push whichever box is winning up to the server, debounced. Two reasons it cannot wait for
   the Post button: the scheduled Discord job posts the server's copy with no browser involved,
   and an edited write-up that only ever existed in one tab's memory is gone the moment that
   tab reloads. cacheDraft is a no-op in the standalone build. */
let _wkSaveT=null;
function wkPersistPost(){
  clearTimeout(_wkSaveT);
  _wkSaveT=setTimeout(function(){
    _wkSaveT=null;
    const t=wkPostText();
    if(!t||!t.trim()) return;
    /* only stamp on a write the server confirmed — the standalone build stores nothing at all,
       and in WordPress a failed write must not read back as "saved" */
    cacheDraft(t).then(function(ok){ if(ok){ _wkFinalAt=Math.round(Date.now()/1000); wkSyncCount(); } });
  }, 1200);
}
document.getElementById('content').addEventListener('keydown',e=>{
  if(e.key==='Enter' && e.target.id==='iridbox'){ const b=document.querySelector('[data-action="iridgo"]'); if(b) b.click(); }
});
document.getElementById('content').addEventListener('change',e=>{
  const a=e.target.dataset.action;
  if(e.target.dataset.avtoggle!==undefined && e.target.type==='checkbox'){
    const name=e.target.dataset.name, slot=+e.target.dataset.slot;
    if(!toggleAvail(name,slot,e.target.checked)){ e.target.checked=!e.target.checked; return; }
    renderContent(); return;
  }
  if(a==='meselect'){ state.me=e.target.value; save(); renderContent(); return; }
  if(a==='caltargets'){ _calTargets=e.target.checked; renderContent(); return; }
  if(a==='calpast'){ _calPast=e.target.checked; renderContent(); return; }
  if(!isAdmin()) return;
  if(a==='swapnote'){ if(!isAdmin())return; state.swapNote=(e.target.value||'').trim(); save(); setStatus('Swap contact saved.'); return; }
  if(a==='renamesave'){ const k=e.target.dataset.key, v=(e.target.value||'').trim(); if(v) state.teamNames[k]=v; else delete state.teamNames[k]; _renaming=null; save(); renderContent(); return; }
  if(a==='assign'){ const d=state.drivers.find(x=>x.id==e.target.dataset.id); if(d){ d.assignedCar=e.target.value; d.carLock=true; save(); renderContent(); } }   // manual choice locks it (imports keep it); padlock to unlock
  else if(a==='move'){
    const id=+e.target.dataset.id, p=e.target.value.split('|'), tc=p[0], tt=p[1], tj=+p[2];
    Object.keys(state.teams).forEach(c=>['pro','casual'].forEach(t=>{ if(state.teams[c][t]) state.teams[c][t]=state.teams[c][t].map(car=>car.filter(x=>x!==id)); }));
    if(state.teams[tc] && state.teams[tc][tt] && state.teams[tc][tt][tj]) state.teams[tc][tt][tj].push(id);
    save(); renderContent();
  }
  else if(state.stintsLocked && (a==='stintwin'||a==='stintlen'||a==='stintrace')){ setStatus('Stints are locked — unlock on the Stints tab to change block length, race or start windows.'); renderContent(); }
  else if(a==='stintwin'){ state.stint.window=+e.target.value; Object.keys(state.stintAssign).forEach(k=>{ if(!state.stintWin[k]) delete state.stintAssign[k]; }); save(); renderContent(); }   // default change replans only cars WITHOUT a per-car window
  else if(a==='stintlen'){ state.stint.len=Math.max(10,+e.target.value||60); save(); renderContent(); }
  else if(a==='stintrace'){ state.stint.race=Math.max(30,+e.target.value||360); save(); renderContent(); }
  else if(a==='fueltank'){ state.fuelCfg.tankL=Math.max(0,+e.target.value||0); save(); renderContent(); }
  else if(a==='fuelperlap'){ state.fuelCfg.fuelPerLap=Math.max(0,+e.target.value||0); save(); renderContent(); }
  else if(a==='fuelpit'){ state.fuelCfg.pitLossSec=Math.max(0,+e.target.value||0); save(); renderContent(); }
  else if(a==='cartank'||a==='carfuel'){ const car=e.target.dataset.car; if(!car)return; const bc=(state.fuelCfg.byCar[car]=state.fuelCfg.byCar[car]||{});
    const v=+e.target.value||0;
    if(a==='cartank'){ if(v>0)bc.tankL=v; else delete bc.tankL; } else { if(v>0)bc.fuelPerLap=v; else delete bc.fuelPerLap; }
    if(!Object.keys(bc).length) delete state.fuelCfg.byCar[car];
    save(); renderContent(); }
  else if(a==='wxstart'||a==='wxtemp'||a==='wxmult'||a==='wxwetfrom'||a==='wxwet'||a==='wxrain'){ const W=(state.evWeather[state.evsel]=state.evWeather[state.evsel]||{src:'manual'});
    if(a==='wxstart'){ const v=e.target.value; if(v){ const p=v.split(':'); W.startTod=(+p[0])*60+(+p[1]); } else delete W.startTod; }
    else if(a==='wxtemp'){ W.tempC=e.target.value===''?null:(+e.target.value); }
    else if(a==='wxmult'){ W.mult=+e.target.value||1; }
    else if(a==='wxwetfrom'){ W.wetFrom=e.target.value===''?null:(+e.target.value); }
    else if(a==='wxwet'){ W.wet=e.target.checked; }
    else if(a==='wxrain'){ W.rainPct=e.target.value===''?null:Math.max(0,Math.min(100,+e.target.value)); }
    save(); renderContent(); }
});
/* ---- drag to paint a run of blocks ----------------------------------------------------
   Mouse and pen only. On touch this would fight the page scroll, and the grid is several
   screens tall on a phone, so touch keeps tap-to-toggle and gets the quick-pick buttons
   instead. Cells are repainted directly during the drag and the tree is only re-rendered
   on release — re-rendering mid-drag would rip the elements out from under the pointer. */
let _dragOn=false, _dragMode=false, _dragName='', _dragDid=false;
function _dragCellAt(x,y){
  const el=document.elementFromPoint(x,y);
  return (el&&el.closest)?el.closest('button[data-avtoggle]'):null;
}
document.addEventListener('pointerdown',function(e){
  if(e.pointerType==='touch') return;
  const c=e.target.closest&&e.target.closest('button[data-avtoggle]');
  if(!c) return;
  _dragOn=true; _dragDid=false; _dragName=c.dataset.name;
  _dragMode=!c.classList.contains('on');    // paint whatever the first cell is not
});
document.addEventListener('pointermove',function(e){
  if(!_dragOn) return;
  const c=_dragCellAt(e.clientX,e.clientY);
  if(!c || c.dataset.name!==_dragName) return;
  if(c.classList.contains('on')===_dragMode) return;
  if(toggleAvail(_dragName,+c.dataset.slot,_dragMode)){ c.classList.toggle('on',_dragMode); _dragDid=true; }
});
document.addEventListener('pointerup',function(){
  if(_dragOn && _dragDid) renderContent();
  _dragOn=false;
});

document.getElementById('content').addEventListener('click',e=>{
  const delcev=e.target.closest&&e.target.closest('[data-action="delcustomev"]');
  if(delcev){ if(isAdmin()){ deleteCustomEvent(delcev.dataset.ev); renderContent(); } return; }
  if(e.target.dataset.action==='addcustomev'){ _evFormOpen=true; _evSyncMsg=''; renderContent(); return; }
  if(e.target.dataset.action==='cancelcustomev'){ _evFormOpen=false; renderContent(); return; }
  if(e.target.dataset.action==='savecustomev'){ const v=id=>{const el=document.getElementById(id);return el?el.value:'';}; const n=(v('cev_n')||'').trim(); if(!n){ setStatus('Event needs a name.'); return; } const s=v('cev_s')||new Date().toISOString().slice(0,10); const ev={n, track:(v('cev_track')||'').trim(), s, e:v('cev_e')||s, cars:(v('cev_cls')||'GT3').trim()||'GT3', cat:v('cev_cat')||'endurance', dur:+v('cev_dur')||24, special:!!(document.getElementById('cev_tgt')&&document.getElementById('cev_tgt').checked)}; addCustomEvent(ev); _evFormOpen=false; renderContent(); setStatus('Added "'+n+'" to the calendar.'); return; }
  if(e.target.dataset.action==='syncir'){ if(typeof syncIrEvents==='function'){ syncIrEvents(); } else { _evSyncMsg='iRacing sync runs on the live site (WordPress).'; renderContent(); } return; }
  if(e.target.dataset.action==='wxclear'){ delete state.evWeather[state.evsel]; save(); renderContent(); return; }
  const calRow=e.target.closest&&e.target.closest('[data-action="selev"]');
  if(calRow){ selectEvent(calRow.dataset.ev); return; }
  const filt=e.target.closest&&e.target.closest('[data-action="calfilter"]');
  if(filt){ _calFilter=filt.dataset.val; renderContent(); return; }
  if(e.target.dataset.action==='calall'){ _calAll=!_calAll; renderContent(); return; }
  if(e.target.dataset.action==='gotoevent'){ state.tab='event'; setActiveTab(); renderContent(); return; }
  if(e.target.dataset.action==='gotoavail'){ state.tab='availability'; setActiveTab(); renderContent(); return; }
  const bcell=e.target.closest&&e.target.closest('button[data-avtoggle]');
  if(bcell){ if(_dragDid){ _dragDid=false; return; }   // a drag already applied this run; don't undo its last cell
    if(toggleAvail(bcell.dataset.name,+bcell.dataset.slot)) renderContent(); return; }
  const bulk=e.target.closest&&e.target.closest('[data-bulk]');
  if(bulk){
    const nm=bulk.dataset.name, kind=bulk.dataset.bulk;
    if(kind==='prev') avCopyPrevious(nm);
    else if(kind==='period') avApplyBulk(nm, true, function(i){ return inPeriod(i, bulk.dataset.p); });
    else if(kind==='day')    avApplyBulk(nm, true, function(i){ return fmtDay(i*AV_BLOCK)===bulk.dataset.day; });
    else if(kind==='dayoff') avApplyBulk(nm, false, function(i){ return fmtDay(i*AV_BLOCK)===bulk.dataset.day; });
    return;
  }
  if(e.target.dataset.action==='wkgen'){
    if(!isAdmin()) return;
    /* cache what would POST, not what was just generated: if an edited version is sitting in the
       final box, rebuilding the draft must not quietly hand the scheduled job the raw one */
    _wkDraft=weeklyDraft(weeklyFacts());
    _wkMsg=_wkFinal.trim()?'Draft rebuilt — the final box below is untouched.':'Draft built.';
    _wkErr=false; cacheDraft(wkPostText()); save(); renderContent(); return;
  }
  if(e.target.dataset.action==='wkai'){ if(isAdmin()) composeDraft(); return; }
  if(e.target.dataset.action==='wkpdf'){ if(isAdmin()) openWeeklyBrief(); return; }
  if(e.target.dataset.action==='wkcopy'){
    if(!isAdmin()) return;
    const ta=document.getElementById('wkdraft');
    const txt=(ta&&ta.value)||'';
    if(!txt.trim()){ _wkMsg='Generate it first.'; renderContent(); return; }
    /* copy whatever is in the box, edits included — the admin may well have tweaked it */
    const done=function(ok){ _wkMsg=ok?'Copied.':'Could not copy — select the text and copy manually.'; renderContent(); };
    if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(function(){done(true);},function(){done(false);});
    else { try{ ta.select(); document.execCommand('copy'); done(true); }catch(_e){ done(false); } }
    return;
  }
  if(e.target.dataset.action==='wkseed'){
    if(!isAdmin()) return;
    const src=(document.getElementById('wkdraft')||{}).value||_wkDraft;
    if(!src.trim()){ _wkMsg='Generate the draft first.'; _wkErr=true; renderContent(); return; }
    const fin=document.getElementById('wkfinal');
    /* refuse to overwrite work already pasted in — the whole point of the second box is that
       nothing else on this tab can wipe it */
    if(fin && fin.value.trim()){ _wkMsg='The final box already has something in it — clear it first.'; _wkErr=true; renderContent(); return; }
    _wkFinal=src; _wkMsg='Draft copied into the final box.'; _wkErr=false; wkPersistPost(); renderContent(); return;
  }
  if(e.target.dataset.action==='wkfinalcopy'){
    if(!isAdmin()) return;
    const fa=document.getElementById('wkfinal');
    const txt=(fa&&fa.value)||'';
    if(!txt.trim()){ _wkMsg='The final box is empty.'; _wkErr=true; renderContent(); return; }
    const done=function(ok){ _wkMsg=ok?'Copied.':'Could not copy — select the text and copy manually.'; _wkErr=!ok; renderContent(); };
    if(navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(function(){done(true);},function(){done(false);});
    else { try{ fa.select(); document.execCommand('copy'); done(true); }catch(_e){ done(false); } }
    return;
  }
  if(e.target.dataset.action==='wkrestore'){
    if(!isAdmin()||!_wkStored||!_wkStored.text) return;
    const fin=document.getElementById('wkfinal');
    if(fin && fin.value.trim()){ _wkMsg='The final box already has something in it — clear it first.'; _wkErr=true; renderContent(); return; }
    _wkFinal=_wkStored.text; _wkFinalAt=_wkStored.at||0;
    _wkMsg='Restored the saved copy — check it is this week\'s before posting.'; _wkErr=false;
    renderContent(); return;
  }
  if(e.target.dataset.action==='wkfinalclear'){
    if(!isAdmin()) return;
    if(!_wkFinal.trim()){ _wkMsg='Already empty.'; _wkErr=false; renderContent(); return; }
    _wkFinal=''; _wkMsg='Cleared — Post to Discord will send the draft above.'; _wkErr=false; wkPersistPost(); renderContent(); return;
  }
  if(e.target.dataset.action==='wkcat'){ if(isAdmin()){ _wkCat=e.target.dataset.c; renderContent(); } return; }
  if(e.target.dataset.action==='wkpreview'){ if(isAdmin()) wkOpenPreview(); return; }
  if(e.target.dataset.action==='wkpost'){ if(isAdmin()) postDraftToDiscord(); return; }
  if(e.target.dataset.action==='wksnap'){ if(isAdmin()) snapshotRatings(); return; }
  if(e.target.dataset.action==='wkrecap'){ if(isAdmin()) refreshRecap(); return; }
  if(e.target.dataset.action==='wkhist'){ if(isAdmin()) refreshHistory(); return; }
  if(e.target.dataset.action==='wkser'){
    if(!isAdmin()) return;
    const w=weeklyState(); w.pick[e.target.dataset.n]=e.target.checked; save(); return;   // no re-render: keeps the scroll position while ticking a long list
  }
  if(e.target.dataset.action==='wkflare'){
    if(!isAdmin()) return;
    weeklyState().flare=e.target.checked; save(); return;
  }
  if(e.target.dataset.action==='wkscope'){
    if(!isAdmin()) return;
    /* re-render, unlike the tick handlers: the whole window moves, so the pick list and every
       round in it change with it */
    weeklyState().scope=(e.target.dataset.v==='this')?'this':'next'; save(); renderContent(); return;
  }
  if(e.target.dataset.action==='drvremove'){ excludeDriver(e.target.dataset.n); return; }
  if(e.target.dataset.action==='drvrestore'){ restoreDriver(e.target.dataset.k); return; }
  if(e.target.dataset.action==='avblock'){ if(isAdmin()) avSetBlock(+e.target.dataset.b); return; }
  if(e.target.dataset.action==='avprune'){ if(isAdmin()) pruneOldEvents(); return; }
  const pb=e.target.closest&&e.target.closest('[data-prefset]');
  if(pb){ const nm=pb.dataset.name; if(!canEditAvail(nm)) return; const axis=pb.dataset.prefset, val=pb.dataset.val;
    const st=(state.prefStore[state.evsel]=state.prefStore[state.evsel]||{}); const p=(st[nm]=st[nm]||{time:'any',cond:'any'}); p[axis]=val;
    (_availDirty[state.evsel]=_availDirty[state.evsel]||{})[nm]=1; _avMsg=''; _avErr=false; save(); renderContent(); return; }
  if(e.target.dataset.action==='iridgo'){ const inp=document.getElementById('iridbox'); const v=((inp&&inp.value)||'').replace(/\D/g,'');
    if(!v){ _iridMsg='Type your iRacing customer ID first.'; renderContent(); return; }
    const nm=ROSTER_IDS[v];
    if(nm){ state.me=nm; _iridMsg=''; try{ localStorage.setItem('edrTB_irid', v); }catch(_e){} save(); renderContent(); }
    else if(typeof apiGET==='function'){   // live check: new members who joined Garage 61 after this page's roster was cached
      _iridMsg='Checking Garage 61 for ID '+v+'…'; renderContent();
      apiGET('roster?lookup='+encodeURIComponent(v)).then(function(r){
        if(r&&r.name){ ROSTER_IDS[v]=r.name; state.me=r.name; _iridMsg=''; try{ localStorage.setItem('edrTB_irid', v); }catch(_e){} save(); }
        else { _iridMsg='No EDR driver found for iRacing ID '+v+' — are you on the EDR Garage 61 team with your iRacing account linked? Ask an admin if unsure.'; }
        renderContent();
      }).catch(function(){ _iridMsg='Could not reach the server to check — try again in a moment.'; renderContent(); });
    }
    else { _iridMsg='No EDR driver found for iRacing ID '+v+' — check the number, or ask an admin to link your Garage 61 account.'; renderContent(); }
    return; }
  if(e.target.dataset.action==='iridchange'){ state.me=''; _iridMsg=''; try{ localStorage.removeItem('edrTB_irid'); }catch(_e){} save(); renderContent(); return; }
  if(e.target.dataset.action==='avtickall'){ if(state.me&&setAllAvail(state.me,true)) renderContent(); return; }
  if(e.target.dataset.action==='avclear'){ if(state.me&&setAllAvail(state.me,false)) renderContent(); return; }
  const avcol=e.target.closest&&e.target.closest('[data-action="avcol"]');
  if(avcol){ if(setAllAvail(avcol.dataset.name,avcol.dataset.op==='all')) renderContent(); return; }
  if(e.target.dataset.action==='avsubmit'){
    const evk=state.evsel; if(!evk) return;
    const dirty=Object.keys(_availDirty[evk]||{});
    const names=dirty.length?dirty:(isAdmin()?Object.keys(state.availStore[evk]||{}):(state.me?[state.me]:[]));
    if(!names.length){ _avMsg='Nothing to submit — pick your name and tick your blocks first.'; _avErr=true; renderContent(); return; }
    Promise.all(names.map(function(n){ return Promise.resolve(persistAvail(evk,n)); }))
      .then(function(){
        _availDirty[evk]={};
        names.forEach(function(n){ markOwned(n); if(!isAdmin() && LOCKED_NAMES.indexOf(n)<0) LOCKED_NAMES.push(n); });
        _avMsg='Submitted — availability saved for the team. You can update it any time, from any device.'; _avErr=false;
        save(); renderContent();
      })
      .catch(function(err){ _avMsg=(err&&err.fromServer&&err.message)?err.message:'Save failed — check your connection and hit Submit again.'; _avErr=true; renderContent(); });   /* fromServer: the server refused (bad event, store full) and retrying will not help — show why */
    return;
  }
  if(e.target.dataset.action==='avrelease'){
    if(!isAdmin()) return;
    releaseLock(e.target.dataset.name);
    return;
  }
  if(e.target.dataset.action==='avadddrv'){
    if(!isAdmin()) return;
    const inp=document.getElementById('avnewdrv'); const name=(inp&&inp.value||'').trim();
    if(!name) return;
    if(!state.drivers.some(d=>d.name===name)){
      const id=state.drivers.reduce((m,d)=>Math.max(m,d.id),0)+1;
      state.drivers.push({id:id,name:name,cars:{},assignedCar:undefined,avail:null});
    }
    save(); renderContent(); return;
  }
  if(!isAdmin()) return;
  const cwBtn=e.target.closest&&e.target.closest('button[data-action="carwin"]');
  if(cwBtn){ if(!isAdmin()) return; if(state.stintsLocked){ setStatus('Stints are locked — unlock to change the start window.'); return; }
    state.stintWin[cwBtn.dataset.key]=+cwBtn.dataset.win; save(); renderContent(); return; }   // re-times the SAME stint plan — assignments are kept, conflicts recompute
  const lane=e.target.closest&&e.target.closest('[data-lanecell]');
  if(lane){ const k=lane.dataset.key,b=+lane.dataset.block,d=+lane.dataset.driver,a=state.stintAssign[k]; if(a){ a[b]=(a[b]===d)?null:d; save(); renderContent(); } return; }
  if(e.target.dataset.action==='carlock'){ if(!isAdmin())return; const d=state.drivers.find(x=>x.id==e.target.dataset.id); if(d){ d.carLock=!d.carLock; save(); renderContent(); } return; }
  if(e.target.dataset.action==='remove'){ state.drivers=state.drivers.filter(x=>x.id!=e.target.dataset.id); generate(); save(); renderContent(); }
  else if(e.target.dataset.action==='stintreset'){ if(state.stintsLocked){ setStatus('Stints are locked — unlock to auto-fill all.'); return; } state.stintAssign={}; state.stintSig=''; save(); renderContent(); }
  else if(e.target.dataset.action==='stintlock'){ if(!isAdmin())return; state.stintsLocked=!state.stintsLocked; save(); renderContent(); setStatus(state.stintsLocked?'Stints locked — auto-fill and window changes will leave them alone.':'Stints unlocked.'); }
  else if(e.target.dataset.action==='teamlock'){ if(!isAdmin())return; state.teamsLocked=!state.teamsLocked; save(); renderContent(); setStatus(state.teamsLocked?'Line-up locked — Generate/Import will leave it alone.':'Line-up unlocked.'); }
  else if(e.target.closest&&e.target.closest('[data-action="renamecar"]')){ if(!isAdmin())return; _renaming=e.target.closest('[data-action="renamecar"]').dataset.key; renderContent(); const inp=document.querySelector('#content input[data-action="renamesave"]'); if(inp){ inp.focus(); inp.select(); } }
  else if(e.target.dataset.action==='addcar'){ const c=e.target.dataset.class, t=e.target.dataset.tier||'pro'; if(!state.teams[c])state.teams[c]={pro:[],casual:[]}; state.teams[c][t].push([]); save(); renderContent(); }
  else if(e.target.dataset.action==='delcar'){ const c=e.target.dataset.class,t=e.target.dataset.tier,j=+e.target.dataset.idx; if(state.teams[c]&&state.teams[c][t]&&state.teams[c][t][j]&&!state.teams[c][t][j].length){ state.teams[c][t].splice(j,1);
      const pre=c+'|'+t+'|', nw={}; Object.keys(state.stintWin).forEach(kk=>{ if(kk.indexOf(pre)!==0){ nw[kk]=state.stintWin[kk]; return; } const idx=+kk.slice(pre.length); if(idx<j) nw[kk]=state.stintWin[kk]; else if(idx>j) nw[pre+(idx-1)]=state.stintWin[kk]; }); state.stintWin=nw;   // keep per-car window overrides aligned after the splice
      const nn={}; Object.keys(state.teamNames||{}).forEach(kk=>{ if(kk.indexOf(pre)!==0){ nn[kk]=state.teamNames[kk]; return; } const idx=+kk.slice(pre.length); if(idx<j) nn[kk]=state.teamNames[kk]; else if(idx>j) nn[pre+(idx-1)]=state.teamNames[kk]; }); state.teamNames=nn;   // keep custom names aligned too
      const na={}; Object.keys(state.stintAssign||{}).forEach(kk=>{ if(kk.indexOf(pre)!==0){ na[kk]=state.stintAssign[kk]; return; } const idx=+kk.slice(pre.length); if(idx<j) na[kk]=state.stintAssign[kk]; else if(idx>j) na[pre+(idx-1)]=state.stintAssign[kk]; }); state.stintAssign=na;   // and the stint plans themselves
      save(); renderContent(); } }
});

// ---- custom pointer drag (works in embedded previews where native drag-and-drop does not) ----
// Drag a bank chip onto a block to assign anyone; drag a block onto another to swap/move.
let _pd=null,_ghost=null;
const _stintContent=document.getElementById('content');
function _drvName(id){ const d=state.drivers.find(x=>x.id==id); return d?d.name.split(' ')[0]:'?'; }
function _ghostAt(x,y){ if(_ghost) _ghost.style.transform='translate('+(x+12)+'px,'+(y+12)+'px)'; }
_stintContent.addEventListener('pointerdown',e=>{
  if(!isAdmin()) return;
  const chip=e.target.closest&&e.target.closest('[data-bankchip]');
  const cell=e.target.closest&&e.target.closest('[data-stintcell]');
  if(chip){ _pd={kind:'bank',driver:chip.dataset.driver}; }
  else if(cell){ if(cell.dataset.driver==='') return; _pd={kind:'cell',key:cell.dataset.key,block:+cell.dataset.block,driver:cell.dataset.driver}; }
  else return;
  e.preventDefault();
  _ghost=document.createElement('div');
  _ghost.textContent=_pd.driver===''?'clear':_drvName(_pd.driver);
  _ghost.style.cssText='position:fixed;left:0;top:0;z-index:99999;pointer-events:none;background:var(--yellow);color:#0a0a0a;font-family:Prompt,sans-serif;font-weight:700;font-size:12px;padding:5px 12px;border-radius:999px;box-shadow:0 4px 14px rgba(0,0,0,.4)';
  document.body.appendChild(_ghost); _ghostAt(e.clientX,e.clientY);
});
document.addEventListener('pointermove',e=>{ if(_pd) _ghostAt(e.clientX,e.clientY); });
document.addEventListener('pointerup',e=>{
  if(_pd){
    const el=document.elementFromPoint(e.clientX,e.clientY);
    const cell=el&&el.closest&&el.closest('[data-stintcell]');
    if(cell){ const k=cell.dataset.key,b=+cell.dataset.block,a=state.stintAssign[k];
      if(a){
        if(_pd.kind==='bank'){ a[b]=_pd.driver===''?null:(+_pd.driver); save(); renderContent(); }
        else if(k===_pd.key){ const tmp=a[b]; a[b]=a[_pd.block]; a[_pd.block]=tmp; save(); renderContent(); }
        else { /* cross-car move: only if the driver is on the target car's roster, and clear the source block (no double-booking) */
          const kp=k.split('|'); const roster=state.teams[kp[0]]&&state.teams[kp[0]][kp[1]]&&state.teams[kp[0]][kp[1]][+kp[2]]; const drv=+_pd.driver;
          if(roster && roster.indexOf(drv)>=0){ a[b]=drv; const src=state.stintAssign[_pd.key]; if(src) src[_pd.block]=null; save(); renderContent(); }
        }
      }
    }
  }
  if(_ghost){ _ghost.remove(); _ghost=null; } _pd=null;
});



/* ===== EDR Team Builder — data import (WordPress plugin) ===== */
const API=(window.EDR_TB&&EDR_TB.root)||''; const NONCE=(window.EDR_TB&&EDR_TB.nonce)||'';
const CAN=!!(window.EDR_TB&&EDR_TB.can_edit);
/* Auth headers: logged-in users send the REST nonce; password-admins send X-EDR-Pass
   (verified server-side). Plain viewers send neither — a stale cached-page nonce would
   otherwise make WordPress 403 even public REST routes. */
function _hdrs(json){ const h={}; if(json) h['Content-Type']='application/json'; if(CAN) h['X-WP-Nonce']=NONCE; else if(state.pass) h['X-EDR-Pass']=state.pass; return h; }
function apiGET(p){return fetch(API+p,{headers:_hdrs(false)}).then(r=>r.json());}
function apiPOST(p,b){return fetch(API+p,{method:'POST',headers:_hdrs(true),body:JSON.stringify(b)}).then(r=>r.json());}
/* password-admin: verified by the server, never against a hash in this file */
function verifyAdminPass(p,cb){
  /* a 429 from the rate limiter carries a reason — pass it through so the unlock field can say
     "wait 10 minutes" instead of "wrong password", which would just invite more attempts */
  fetch(API+'auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pass:p})})
    .then(r=>r.json().catch(function(){return {};}).then(function(j){ return {ok:r.ok,j:j}; }))
    .then(function(x){ cb(!!(x.j&&x.j.ok), (!x.ok&&x.j&&x.j.message)?x.j.message:''); })
    .catch(function(){cb(false,'');});
}
/* after a password unlock the Setup tab is newly visible — fetch its data now
   (at boot these only load for already-admin sessions) */
function onAdminUnlocked(){
  (async function(){
    try{ TRACKS=await apiGET('tracks'); }catch(e){ TRACKS=[]; } if(!Array.isArray(TRACKS)) TRACKS=[];
    preselectNearest();
    renderContent();
    loadIracing().then(renderContent);
  })();
}
/* per-driver availability syncs through its own public route, not the plan. Still carries the
   device token (accepted and ignored server-side since the 2.4.2 advisory model) and admin
   credentials when present. Returns the fetch promise so Submit can await it and confirm. */
function persistAvail(evk,name){
  const slots=((state.availStore[evk]||{})[name])||[];
  const prefs=((state.prefStore[evk]||{})[name])||null;
  return fetch(API+'avail',{method:'POST',headers:_hdrs(true),body:JSON.stringify({ev:evk,name:name,slots:slots,prefs:prefs,token:DEV_TOKEN})})
    .then(function(r){
      return r.json().catch(function(){ return {}; }).then(function(j){
        /* flag server refusals (unrecognised event, store full) so the Submit handler shows the
           reason rather than blaming the connection and inviting a pointless retry */
        if(!r.ok){ var e=new Error((j&&j.message)||'avail save failed'); e.fromServer=true; throw e; }
        if(j&&j.locked) LOCKED_NAMES=j.locked;
        /* remember the stamp the server just wrote so "already in" is right immediately,
           without waiting for the next GET /avail */
        if(j&&j.seen){ AV_SEEN=AV_SEEN||{}; (AV_SEEN[evk]=AV_SEEN[evk]||{})[name]=j.seen; }
        return j;
      });
    });
}
/* Admin tidy-up: drop availability for events that finished long ago. This is the only way the
   server's store caps are ever reached in normal use, so it needs to be doable from the page. */
/* Kick the results sweep and watch for it to finish. It is a search per driver plus a fetch
   per subsession against a rate-limited proxy, so this can take minutes — the button returns
   at once and we poll the cached copy. */
function snapshotRatings(){
  _wkMsg='Reading ratings from Garage 61…'; _wkErr=false; renderContent();
  fetch(API+'ratings',{method:'POST',headers:_hdrs(true),body:'{}'})
    .then(function(r){ return r.json().catch(function(){return {};}).then(function(j){
      if(!r.ok) throw new Error((j&&j.message)||'ratings snapshot failed'); return j; }); })
    .then(function(j){
      RATINGS=j.movement||RATINGS;
      const n=(j.snapshot&&j.snapshot.drivers)||0;
      _wkMsg = (RATINGS&&RATINGS.ready)
        ? ('Snapshot taken for '+n+' drivers — movement available against '+RATINGS.from+'.')
        : ('Snapshot taken for '+n+' drivers. Movement needs a second week to compare against.');
      _wkErr=false; renderContent();
    })
    .catch(function(err){ _wkMsg=(err&&err.message)||'ratings snapshot failed'; _wkErr=true; renderContent(); });
}
function refreshRecap(){
  RECAP_RUNNING=true; RECAP_ERR=''; renderContent();
  /* Recap the race week immediately before the one being drafted, so the "how last week went"
     half and the "what is on" half of a draft never describe different weeks. Sent explicitly
     because the server cannot know which way the tab's next-week/this-week toggle is set; its
     own default is the same window for the 'next' case, which is what the Sunday job uses. */
  const _wkWin=draftWeekWindow();
  const _wkTo=Date.parse(_wkWin.from+'T00:00:00Z');
  const _body=JSON.stringify({from:isoDayUTC(_wkTo-7*86400000)+'T00:00:00Z', to:isoDayUTC(_wkTo)+'T00:00:00Z'});
  fetch(API+'recap/refresh',{method:'POST',headers:_hdrs(true),body:_body})
    .then(function(r){ return r.json().catch(function(){return {};}).then(function(j){
      if(!r.ok) throw new Error((j&&j.message)||'could not start the results pull'); return j; }); })
    .then(function(){ pollRecap(0); })
    .catch(function(err){ RECAP_RUNNING=false; RECAP_ERR=(err&&err.message)||'results pull failed'; renderContent(); });
}
function pollRecap(n){
  if(n>60){ RECAP_RUNNING=false; RECAP_ERR='The results pull is taking longer than expected — reopen the tab shortly.'; renderContent(); return; }
  setTimeout(function(){
    apiGET('recap').then(function(rc){
      if(rc){ RECAP=rc.recap||RECAP; RECAP_ERR=rc.error||''; RECAP_RUNNING=!!rc.running; RECAP_PROG=rc.progress||null; if(rc.progress) renderContent(); }
      if(rc && rc.running) return pollRecap(n+1);
      RECAP_RUNNING=false; renderContent();
    }).catch(function(){ pollRecap(n+1); });
  }, 5000);
}
/* Team history sweep — same shape as the recap: kick it, then poll GET /history, whose every
   read advances one slice server-side (so it finishes even where WP-Cron is dead). */
function refreshHistory(){
  HIST_RUNNING=true; HIST_ERR=''; renderContent();
  fetch(API+'history/refresh',{method:'POST',headers:_hdrs(true),body:'{}'})
    .then(function(r){ return r.json().catch(function(){return {};}).then(function(j){
      if(!r.ok) throw new Error((j&&j.message)||'could not start the history pull'); return j; }); })
    .then(function(){ pollHistory(0); })
    .catch(function(err){ HIST_RUNNING=false; HIST_ERR=(err&&err.message)||'history pull failed'; renderContent(); });
}
function pollHistory(n){
  if(n>90){ HIST_RUNNING=false; HIST_ERR='The history pull is taking longer than expected — reopen the tab shortly.'; renderContent(); return; }
  setTimeout(function(){
    apiGET('history').then(function(hh){
      if(hh){ if(hh.history) applyHistory(hh.history); HIST_ERR=hh.error||''; HIST_RUNNING=!!hh.running; HIST_PROG=hh.progress||null; renderContent(); }
      if(hh && hh.running) return pollHistory(n+1);
      HIST_RUNNING=false; renderContent();
    }).catch(function(){ pollHistory(n+1); });
  }, 5000);
}
/* Compose with AI — send the deterministic draft (the source of truth for every fact) plus the
   sanitised driver one-liners to the server, which asks Gemini to rewrite it in EDR's voice. The
   plain draft is always one click away (Generate), so a model slip is caught before anything posts. */
function composeDraft(){
  if(!isAdmin()) return;
  if(!_wkDraft || !_wkDraft.trim()){ _wkDraft=weeklyDraft(weeklyFacts()); cacheDraft(wkPostText()); }
  var plain=_wkDraft;
  var notes=Object.assign({}, DRIVER_NOTES, (weeklyState().driver||{}));
  var voice={};                                   // only the notes for drivers the draft actually names
  Object.keys(notes).forEach(function(n){ if(plain.indexOf(n)>=0) voice[n]=notes[n]; });
  _wkAI=true; _wkErr=false; _wkMsg='Composing with AI…'; renderContent();
  fetch(API+'draft/compose',{method:'POST',headers:_hdrs(true),body:JSON.stringify({draft:plain, voice:voice})})
    .then(function(r){ return r.json().catch(function(){return {};}).then(function(j){
      if(!r.ok) throw new Error((j&&j.message)||'compose failed'); return j; }); })
    .then(function(j){
      if(j&&j.text){ _wkDraft=j.text; cacheDraft(wkPostText()); _wkMsg='Composed — check it against the facts, and hit Generate to get the plain version back.'; _wkErr=false; }
      else { _wkMsg='Compose returned nothing.'; _wkErr=true; }
      _wkAI=false; renderContent();
    })
    .catch(function(err){ _wkAI=false; _wkErr=true; _wkMsg=(err&&err.message)||'compose failed'; renderContent(); });
}
/* Keep the server's copy of the draft in step with what the admin sees. The scheduled
   Discord post has no browser to render with, so whatever was last generated here IS what
   gets posted — see cacheDraft callers. */
/* Resolves true only when the server actually took it. The Weekly tab shows a "saved" stamp
   beside the final post, and that stamp is a promise about the scheduled job: it means the
   text now exists somewhere other than this browser tab. Resolving true on a failed write
   would make it a lie at exactly the moment it matters. */
function cacheDraft(text){
  if(!text||!text.trim()) return Promise.resolve(false);
  return fetch(API+'weekly/draft',{method:'POST',headers:_hdrs(true),body:JSON.stringify({text:text})})
    .then(function(r){ if(!r||!r.ok) return false;
      return r.json().catch(function(){ return {}; }).then(function(j){
        /* the server compares what it stored against what it was sent — a database still on
           3-byte utf8 eats every emoji on the way in, and the scheduled job posts that copy */
        _wkStripped = (j && j.intact === false);
        return true;
      });
    }).catch(function(){ return false; });
}
/* The final box wins over the draft. The write-up is copied out of the Team Builder, edited
   elsewhere and pasted back, so the version a human last touched is the one that goes out —
   and it is read from the DOM, not from _wkFinal, so text pasted a keystroke ago cannot be
   missed by the input handler's debounce. */
function postDraftToDiscord(){
  var fin=document.getElementById('wkfinal');
  var ta=document.getElementById('wkdraft');
  if(fin) _wkFinal=fin.value||'';
  if(ta && (ta.value||'').trim()) _wkDraft=ta.value;
  var text=wkPostText();
  if(!text.trim()){ _wkMsg='Nothing to post — generate the draft, or paste your version into the final box.'; _wkErr=true; renderContent(); return; }
  _wkMsg='Posting…'; _wkErr=false; renderContent();
  /* Send the text with the request. It is the exact string that was just previewed, so nothing
     between the preview and Discord can alter it — in particular it never goes near the options
     table, which on a 3-byte-utf8 database strips every emoji in the write-up. cacheDraft still
     runs (the scheduled job needs a stored copy) but the post no longer depends on what it kept. */
  cacheDraft(text).then(function(){
    return fetch(API+'weekly/post',{method:'POST',headers:_hdrs(true),body:JSON.stringify({text:text})})
      .then(function(r){ return r.json().catch(function(){return {};}).then(function(j){
        if(!r.ok) throw new Error((j&&j.message)||'Discord post failed'); return j; }); });
  }).then(function(j){
    _wkFinalAt=Math.round(Date.now()/1000);
    _wkMsg='Posted to Discord'+(j&&j.messages>1?(' in '+j.messages+' messages'):'')+'.'; _wkErr=false; renderContent();
  }).catch(function(err){ _wkMsg=(err&&err.message)||'Discord post failed'; _wkErr=true; renderContent(); });
}
/* Fetch the server's copy so an edited write-up is not lost to a reload — but OFFER it, never
   drop it into the final box unasked. Auto-filling looked helpful and was a trap: the stored
   copy is whatever was last posted, so after an upgrade the box silently pre-loaded LAST week's
   write-up, in the old format, and the final box wins over the draft. The result was a freshly
   generated update sitting untouched above a stale one that was what actually posted. */
function loadStoredPost(){
  return apiGET('weekly/draft').then(function(j){
    if(!j||!j.text||!String(j.text).trim()) return;
    _wkStored={text:String(j.text), at:parseInt(j.at,10)||0};
  }).catch(function(){});
}
function pruneOldEvents(){
  var days=90;
  fetch(API+'avail/prune',{method:'POST',headers:_hdrs(true),body:JSON.stringify({days:days})})
    .then(function(r){ return r.json().catch(function(){return {};}).then(function(j){
      if(!r.ok) throw new Error((j&&j.message)||'prune failed');
      return j; }); })
    .then(function(j){
      var n=(j&&j.removed&&j.removed.length)||0;
      if(n){ (j.removed||[]).forEach(function(k){ delete state.availStore[k]; delete state.prefStore[k]; if(AV_SEEN)delete AV_SEEN[k]; }); }
      _avMsg=n?('Cleared '+n+' event'+(n>1?'s':'')+' older than '+days+' days.'):('Nothing older than '+days+' days to clear.');
      _avErr=false; save(); renderContent();
    })
    .catch(function(err){ _avMsg=(err&&err.message)||'Could not clear old events.'; _avErr=true; renderContent(); });
}
function releaseLock(name){
  apiPOST('avail',{name:name,release:1}).then(function(r){
    if(r&&r.ok){ LOCKED_NAMES=LOCKED_NAMES.filter(function(n){return n!==name;}); renderContent(); }
  }).catch(function(){});
}
let lastTrackIds=[], lastTrackEv=null, _saveT=null;
function serializePlan(){ return {drivers:state.drivers,w:state.w,proPct:state.proPct,teams:state.teams,stint:state.stint,stintAssign:state.stintAssign,stintWin:state.stintWin,stintSig:state.stintSig,overrides:overrides,meta:IMPORT_META,winStart:WIN_START_MS,startOffsets:START_OFFSETS,startLabels:START_LABELS,matches:lastMatches,trackIds:lastTrackIds,trackEv:lastTrackEv,paceAt:_planPaceAt,evsel:state.evsel,evWinMin:EV_WIN_MIN,evTiming:state.evTiming,teamsLocked:state.teamsLocked,stintsLocked:state.stintsLocked,teamNames:state.teamNames,fuelCfg:state.fuelCfg,customEvents:state.customEvents,irEvents:state.irEvents,evWeather:state.evWeather,swapNote:state.swapNote,excluded:state.excluded}; }
var _postBusy=false, _postAgain=false;
function _flushPlan(){
  if(_postBusy){ _postAgain=true; return; }              // serialize: the retry below re-posts the LATEST state with the updated rev
  _postBusy=true;
  var _sent=serializePlan();
  apiPOST('plan',{plan:_sent, baseRev:PLAN_REV}).then(function(r){
    _postBusy=false;
    if(r&&r.ok&&typeof r.rev==='number'){ PLAN_REV=r.rev; _planEvsel=_sent.evsel||null; _postRetried=false; if(_postAgain){ _postAgain=false; _flushPlan(); } }
    else if(r&&r.code==='stale_plan'){ _postAgain=false; clearTimeout(_saveT); _saveT=null; refreshShared(true); }   // adopt latest; message shown after the pull actually lands
    else if(_postAgain){ _postAgain=false; _flushPlan(); }
  }).catch(function(){ _postBusy=false; if(!_postRetried){ _postRetried=true; setTimeout(_flushPlan, 1500); } else { _postAgain=false; } });
}
var _postRetried=false;
function save(){
  try{ localStorage.setItem('edrTB_local', JSON.stringify({role:state.role,me:state.me,pass:state.pass})); }catch(e){}
  if(!isAdmin()) return;
  clearTimeout(_saveT); _saveT=setTimeout(function(){ _saveT=null; _flushPlan(); }, 600);
}
var PLAN_REV=0;
var PACE_AT=0, PACE_ERR='';   /* Garage 61 pace cache: unix seconds, and why the last refresh failed */
function paceAgeLabel(){
  if(PACE_ERR) return 'pace refresh failed — '+PACE_ERR;
  if(!PACE_AT) return 'pace not pulled yet';
  var mins=Math.max(0, Math.round((Date.now()/1000-PACE_AT)/60));
  if(mins<2) return 'pace refreshed just now';
  if(mins<60) return 'pace refreshed '+mins+' minutes ago';
  var hrs=Math.round(mins/60);
  if(hrs<24) return 'pace refreshed '+hrs+' hour'+(hrs===1?'':'s')+' ago';
  var d=Math.round(hrs/24); return 'pace refreshed '+d+' day'+(d===1?'':'s')+' ago';
}
function _adoptPlan(p, keepEvsel){
  var _localEv=keepEvsel?state.evsel:null;
  state.drivers=p.drivers; state.w=p.w||state.w; state.proPct=(typeof p.proPct==='number')?p.proPct:state.proPct; state.teams=p.teams||{};
  state.stint=Object.assign(state.stint,p.stint||{}); state.stintAssign=p.stintAssign||{}; state.stintWin=p.stintWin||{}; state.stintSig=p.stintSig||'';
  if(p.overrides)overrides=p.overrides; if(p.meta)IMPORT_META=p.meta; if(p.winStart)WIN_START_MS=p.winStart;
  if(p.startOffsets&&Object.keys(p.startOffsets).length)START_OFFSETS=p.startOffsets; if(p.startLabels&&Object.keys(p.startLabels).length)START_LABELS=p.startLabels;
  if(p.evsel)state.evsel=p.evsel; if(p.evWinMin)EV_WIN_MIN=p.evWinMin; if(p.evTiming)state.evTiming=p.evTiming; state.teamsLocked=!!p.teamsLocked; state.stintsLocked=!!p.stintsLocked;
  state.teamNames=p.teamNames||{}; if(p.fuelCfg)state.fuelCfg=p.fuelCfg; state.customEvents=p.customEvents||[]; state.irEvents=p.irEvents||[]; state.evWeather=p.evWeather||{}; state.swapNote=p.swapNote||''; state.excluded=p.excluded||{};
  /* a plan saved before the name-suffix fix still holds both spellings of one driver, and
     this restores state.drivers verbatim — collapse them here or the duplicate survives
     every reload until somebody happens to run an import */
  dedupeDrivers();
  /* Race preferences live in edr_tb_prefs, written by the drivers themselves through /avail.
     The plan used to carry a second copy, which meant an admin autosave could ship a stale
     snapshot of everyone's preferences; /avail happened to be applied afterwards so it never
     bit, but the duplicate was one reordering away from silently reverting driver choices.
     Only read the legacy copy, as a fallback for plans saved before 2.4.11. */
  if(p.prefStore && !Object.keys(state.prefStore||{}).length) state.prefStore=p.prefStore;
  lastMatches=p.matches||[]; lastTrackIds=p.trackIds||[]; lastTrackEv=p.trackEv||null; _planEvsel=p.evsel||null;
  if(_localEv && _localEv!==state.evsel && calEvent(_localEv)){ state.evsel=_localEv; }   // don't yank the viewer off their selected event
  /* the adopted plan may lag the warm cache (re-apply ours) or be AHEAD of it (another device
     saved a newer refresh) — compare refresh times so an adopt can never rewind pace */
  _planPaceAt=p.paceAt||0; _paceDirty=false;
  if(_paceLast && _paceLast.key===_paceKeyNow() && _paceLast.at>_planPaceAt){ _paceDirty=mergePace(_paceLast.roster); _planPaceAt=_paceLast.at; }
}
function loadPlan(){ return apiGET('plan').then(function(r){ if(r&&typeof r.rev==='number') PLAN_REV=r.rev; var p=r&&r.plan; if(!p||!p.drivers||!p.drivers.length) return false; _adoptPlan(p); return true; }).catch(function(){return false;}); }
/* Multi-device convergence: when this tab wakes up (phone unlocked, tab refocused), pull the
   latest shared state if the server revision moved instead of sitting on stale weekend state.
   Hardened per adversarial review: monotonic rev guard, re-check for local edits when the GET
   RESOLVES (not just at entry), per-event availability merge that honours staged ticks, defer
   while an inline edit has focus, and a force mode for 409 recovery. */
var _refreshLast=0;
function _editingNow(){ try{ if(typeof _renaming!=='undefined'&&_renaming!==null) return true; var ae=document.activeElement, c=document.getElementById('content'); return !!(ae&&c&&c.contains(ae)&&/^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)); }catch(e){ return false; } }
function refreshShared(force){
  var now=Date.now();
  if(!force && now-_refreshLast<2500) return;           // visibilitychange+focus both fire on wake — one fetch is enough
  _refreshLast=now;
  if(!force && (_saveT||_postBusy)) return;             // our own save is queued/in flight; it will reconcile
  apiGET('plan').then(function(r){
    if(!(r&&r.plan&&r.plan.drivers&&r.plan.drivers.length)) return;
    var rev=(typeof r.rev==='number')?r.rev:null;
    if(rev===null) return;                              // legacy PHP (deploy skew): never blind-adopt on focus
    if(rev<=PLAN_REV && !force) return;                 // monotonic: a late stale GET must not rewind us
    if(!force && (_saveT||_postBusy)) return;           // an edit landed while this GET was in flight — let its save reconcile
    if(!force && _editingNow()){ setTimeout(function(){ refreshShared(); },4000); return; }  // don't rip an open input out from under the user
    PLAN_REV=rev;
    var _localNames=state.teamNames||{};
    _adoptPlan(r.plan, true);
    var _renamedBack=false; Object.keys(_localNames).forEach(function(k){ if(_localNames[k] && !state.teamNames[k]){ state.teamNames[k]=_localNames[k]; _renamedBack=true; } });   // a rename in flight when another device saved must survive the adopt
    if(_renamedBack && isAdmin()) save();
    if(_paceDirty && isAdmin() && state.evsel===_planEvsel) save();   // adopted plan lagged the pace cache; we're on the latest rev now, so this can't 409
    if(state.evsel){ var _ev=calEvent(state.evsel); if(_ev){ var _r0=state.stint.race; applyEventTiming(_ev); if(_r0>0) state.stint.race=_r0; } }
    apiGET('avail').then(function(av){
      if(av&&av.store){
        var dirty={}; Object.keys(_availDirty||{}).forEach(function(k){ if(Object.keys(_availDirty[k]||{}).length) dirty[k]=1; });
        Object.keys(av.store).forEach(function(evk){ if(!dirty[evk]) state.availStore[evk]=av.store[evk]; });   // never wipe staged, unsubmitted ticks — any event
        if(av.prefs) Object.keys(av.prefs).forEach(function(evk){ if(!dirty[evk]) state.prefStore[evk]=av.prefs[evk]; });
        if(av.seen) AV_SEEN=av.seen;
        LOCKED_NAMES=av.locked||[];
      }
    }).catch(function(){}).then(function(){ applyAvailToDrivers(); renderContent(); setStatus(force?'Another device updated the plan — showing the latest; re-apply your last change.':'Synced the latest plan from the server.'); });
  }).catch(function(){});
}
var IR_SEASONS=[], IR_STATUS='';
/* Next fortnight's official rounds, straight from the iRacing schedule — the weekly write-up's
   source of truth for what is on. Kept apart from IR_SEASONS on purpose: that one holds only
   weeks carrying session_times, because irMatchFor() scores across it and would otherwise
   settle on a sessionless week and stop the official-times feature working. */
var IR_WEEKS=[];
/* namespaced series key -> [{name, ...}] of who on the team actually runs it, built live from
   the history sweep (GET /history). Empty until that pull exists; the builder falls back to the
   seeded WEEKLY_SERIES figures and says so in the UI. */
var TEAM_SERIES={};
/* Fold a GET /history payload into the live globals (HISTORY + HIST_* are declared in the HTML
   core so both builds share them). TEAM_SERIES is re-keyed by the client's own seriesKey() over
   each series label, so the join to the schedule can never drift from the PHP key function — the
   one that bit this before. */
function applyHistory(h){
  HISTORY=(h&&h.tracks)?h:null;
  TEAM_SERIES={};
  if(HISTORY&&HISTORY.series){
    Object.keys(HISTORY.series).forEach(function(sk){
      var e=HISTORY.series[sk]; var k=seriesKey(e.label||'');
      if(k&&e.drivers&&e.drivers.length) TEAM_SERIES[k]=e.drivers;
    });
  }
}
function loadIracing(){
  return apiGET('iracing').then(function(r){
    if(r&&r.ok){ IR_SEASONS=r.seasons||[]; IR_WEEKS=r.weeks||[]; IR_STATUS=IR_SEASONS.length?'':'iRacing connected, but no active events expose session times right now.'; }
    else if(r&&r.reason==='not_configured'){ IR_SEASONS=[]; IR_WEEKS=[]; IR_STATUS='iRacing proxy not set in plugin Settings — using calendar/derived session times.'; }
    else { IR_SEASONS=[]; IR_WEEKS=[]; IR_STATUS=(r&&r.message)||'iRacing unavailable right now.'; }
  }).catch(function(){ IR_SEASONS=[]; IR_WEEKS=[]; IR_STATUS='iRacing unavailable right now.'; });
}
function irMatchFor(ev){
  if(!ev||!IR_SEASONS.length) return null;
  var nk=function(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');};
  var evk=nk(ev.n), evtk=nk(ev.track);
  var evDate=ev.s?Date.parse(ev.s+'T00:00:00Z'):NaN;
  var best=null,bs=-1;
  IR_SEASONS.forEach(function(se){
    var nn=nk(se.name), tk=nk(se.track), sc=0;
    // token overlap on the event name
    (ev.n.toLowerCase().match(/[a-z0-9]+/g)||[]).forEach(function(w){ if(w.length>2 && nn.indexOf(w)>=0) sc+=2; });
    if(evtk && tk && (tk.indexOf(evtk.slice(0,8))>=0 || evtk.indexOf(tk.slice(0,8))>=0)) sc+=3;
    // date proximity is decisive: an official round runs in its own calendar week. Without it,
    // same-track different-series rounds collide (Spa 24HR was auto-applied to Creventic 12H Spa).
    if(se.start_date && !isNaN(evDate)){
      var sd=Date.parse(se.start_date+'T00:00:00Z');
      if(!isNaN(sd)){ var dd=Math.abs(sd-evDate)/86400000;
        if(dd<=2) sc+=4; else if(dd<=6) sc+=2; else return;   // a week apart = a different round
      }
    }
    // race-length sanity: a 12h event must not adopt a 24h session's times
    if(se.race_min && ev.dur){ var dm=Math.abs(se.race_min-(ev.dur*60)); if(dm<=30) sc+=2; else if(dm>=120) sc-=3; }
    if(sc>bs){ bs=sc; best=se; }
  });
  return bs>=5?best:null;
}
function autoApplyTiming(){  // auto-apply official session times to the selected event (once; a manual pick or revert wins)
  try{
    if(!state.evsel || !IR_SEASONS.length) return;
    var ev=calEvent(state.evsel); if(!ev) return;
    if(state.evTiming && state.evTiming[state.evsel]) return;   // already applied / manually set / deliberately reverted — leave it
    if(state.stintsLocked) return;                              // locked stint plan: timing changes only via the manual Apply
    var se=irMatchFor(ev); if(!se || !(se.sessions&&se.sessions.length)) return;
    if(applyIrTiming(ev, se)){ applyEventTiming(ev); state.stintAssign={}; state.stintWin={}; state.stintSig=''; applyAvailToDrivers(); save(); setSetupMsg('Auto-applied official session times from "'+se.name+'".'); renderContent(); }
  }catch(e){}
}
function autoApplyWeather(){  // auto-pull: match the selected event to an iRacing season and apply its weather (manual override wins)
  try{
    if(!state.evsel || !IR_SEASONS.length) return;
    var ev=calEvent(state.evsel); if(!ev) return;
    var cur=state.evWeather[state.evsel];
    if(cur && cur.src==='manual') return;
    var se=irMatchFor(ev);
    if(se && se.weather){ applyIrWeather(ev, se); save(); if(state.tab==='stints') renderContent(); }
  }catch(e){}
}
var _selectEvent0=selectEvent; selectEvent=function(k){ _selectEvent0(k); autoApplyTiming(); autoApplyWeather(); };   // picking an event auto-applies its iRacing session times + weather
function syncIrEvents(){  // F1: pull whatever endurance events the proxy exposes and merge into the calendar
  _evSyncMsg='Syncing iRacing…'; renderContent();
  loadIracing().then(function(){
    var existing={}; CAL_EVENTS.concat(state.customEvents||[]).forEach(function(e){ existing[evKey(e)]=1; });
    // an iRacing round that MATCHES an event already on the calendar (same week/track/length —
    // the irMatchFor rules) is the SAME race under its season name: never import it as a second
    // row, it only feeds that event's official times + weather. This killed the
    // "Creventic Round 2 — 12H Spa" + "Creventic Endurance Series - 2026 Season" double-up.
    var claimed=[];
    CAL_EVENTS.concat(state.customEvents||[]).forEach(function(ev){
      if(!isTarget(ev)) return;
      var m=irMatchFor(ev); if(m && claimed.indexOf(m)<0) claimed.push(m);
    });
    var fresh=[], added=0, have=0;
    (IR_SEASONS||[]).forEach(function(se){
      if(!se.name||!se.start_date) return;
      if(claimed.indexOf(se)>=0){ have++; return; }
      var dur=se.race_min?Math.max(1,Math.round(se.race_min/60)):6;
      var isEnd=/endur|24|12\s*h|le mans|petit|creventic|global endurance|imsa|nurburg|bathurst|sebring|spa|daytona|suzuka|road america/i.test(se.name);
      /* cars used to be hardcoded 'GT3' here, which is why every synced event in the weekly
         write-up claimed to be a GT3 race. Use the season's real classes, and leave it blank
         rather than guessing when the API did not give us any. */
      var evCars=(se.cars&&se.cars.length)?se.cars.join(' // '):'';
      var ev={n:prettySeriesName(se.name), track:se.track||'', s:se.start_date, e:se.start_date, cars:evCars, cat:isEnd?'endurance':'other', dur:dur, special:isEnd, src:'iracing', raceMin:se.race_min||0};
      if(existing[evKey(ev)]){ have++; return; }
      fresh.push(ev); if(se.weather) applyIrWeather(ev, se); added++;
    });
    state.irEvents=fresh; save(); autoApplyTiming(); autoApplyWeather();
    _evSyncMsg = IR_STATUS ? IR_STATUS : ('Synced: added '+added+' iRacing event'+(added===1?'':'s')+(have?', '+have+' already on the calendar':'')+'.');
    renderContent();
  }).catch(function(){ _evSyncMsg='iRacing unavailable right now.'; renderContent(); });
}
let SEL_TRACK=0;
function preselectNearest(){
  SEL_TRACK=(lastTrackIds&&lastTrackIds[0]) || (Array.isArray(TRACKS)&&TRACKS.length?TRACKS[0].id:0);
}
const norm=s=>String(s||'').toLowerCase().replace(/[^a-z]/g,'');
function classOfCar(c){const n=String(c).toUpperCase();if(/GTP|HYBRID|LMDH/.test(n))return'GTP';if(/LMP2|P217|LMP/.test(n))return'LMP2';if(/GT4/.test(n))return'GT4';if(/GT3/.test(n))return'GT3';return'Other';}
const OVR_KEY='edrTB_overrides';
let overrides=(function(){try{return JSON.parse(localStorage.getItem(OVR_KEY))||{};}catch(e){return{};}})();
function saveOverrides(){try{localStorage.setItem(OVR_KEY,JSON.stringify(overrides));}catch(e){}}
let TRACKS=null, lastPayload=null, setupMsg='';
let IMPORT_META={window_min:1980,race_min:360,candidate_starts:[]};

function setSetupMsg(t){ setupMsg=t; if(state.tab==='setup') renderContent(); }
function computeAvail(windows){
  const wm=IMPORT_META.window_min||1980, race=IMPORT_META.race_min||360;
  const total=(windows||[]).reduce((a,w)=>a+(w[1]-w[0]),0);
  const starts=(IMPORT_META.candidate_starts||[]).filter(c=>(windows||[]).some(w=>w[0]<=c.offset&&w[1]>=c.offset+race)).map(c=>c.n);
  return {hours:Math.round(total/60*10)/10, pct:wm?Math.round(total/wm*100):0, starts, windows:windows||[]};
}
function findBySlug(roster,slug){return (roster||[]).find(r=>norm(r.name)===norm(slug));}
function buildCars(r,prefsStr){
  const cars={};
  if(r){ Object.entries(r.cars).filter(([c])=>['GTP','LMP2','GT3','GT4'].includes(classOfCar(c))).sort((a,b)=>b[1].laps-a[1].laps).forEach(([c,s])=>cars[c]=s); }
  String(prefsStr||'').split(',').map(x=>x.split(' +')[0].trim()).filter(x=>x&&!/^\d+$/.test(x)).forEach(p=>{ if(!cars[p]&&['GTP','LMP2','GT3','GT4'].includes(classOfCar(p))) cars[p]={laps:0,medianLap:null,cleanPct:0}; });
  if(r){ Object.entries(r.cars).forEach(([c,s])=>{ if(!cars[c]) cars[c]=s; }); }
  return cars;
}
let lastMatches=[];
function applyImport(payload){
  var drivers=[], id=1;
  var prevByKey={}; (state.drivers||[]).forEach(function(d){ prevByKey[nameKey(d.name)]=d; });   // keep admin-locked car choices across G61 imports
  (payload.roster||[]).forEach(function(r){
    if(isExcluded(r.name)) return;   // removed by an admin: Garage 61 must not put them back
    var prev=prevByKey[nameKey(r.name)];
    var locked=!!(prev&&prev.carLock);
    var keep=(locked&&prev.assignedCar&&r.cars&&r.cars[prev.assignedCar])?prev.assignedCar:null;
    drivers.push({id:id++, name:r.name, cars:r.cars, assignedCar:keep||lastCar(r.cars), avail:null, irating:(typeof r.irating==='number'?r.irating:(prev?prev.irating:null)), carLock:locked});
  });
  state.drivers=drivers; state.stintAssign={}; state.stintSig=''; state.stintWin={};
  dedupeDrivers();
  applyAvailToDrivers();  // in-house per-event availability is the single source of truth
  generate(); save();
}
/* ---- automatic pace -------------------------------------------------------------------
   The server keeps Garage 61 pace warm for the tracks of whichever event a viewer has open
   (/rev sends them; see edr_tb_maybe_schedule_pace). When that cache moves, every open page
   folds it in: a driver who ticks Spa availability and then practises at Spa sees their pace
   update without anyone pressing Import. Unlike applyImport this only ever touches pace —
   no Generate, no stint wipe, no new ids for existing drivers — so a settled line-up and stint
   plan never move. Admin browsers persist it, and only while viewing the event the shared plan
   is on (saving from another event would silently switch the plan to it). */
var _planEvsel=null, _paceLast=null, _pacePulling=false, _paceDirty=false, _planPaceAt=0;
function _paceKeyNow(){
  var ev=state.evsel?calEvent(state.evsel):null;
  // an admin's import for THIS event wins (manual track picker overrides must stick); otherwise
  // the event's own Garage 61 tracks. Track ids imported for another event never carry over.
  var ids=(state.evsel && lastTrackEv===state.evsel && lastTrackIds.length)?lastTrackIds:((ev&&ev.g61Tracks)||[]);
  return (ids||[]).map(Number).filter(function(x){return x>0;}).sort(function(a,b){return a-b;}).join(',');
}
function pullPace(key){
  if(_pacePulling) return; _pacePulling=true;
  apiGET('pace?tracks='+key).then(function(r){
    _pacePulling=false;
    if(!(r&&r.key===key&&r.at&&Array.isArray(r.roster))) return;   // at=0: never pulled yet, nothing to apply
    if(key!==_paceKeyNow()) return;                      // viewer switched event while this was in flight
    _paceLast={key:key, at:r.at, roster:r.roster};
    if(r.at<=_planPaceAt) return;                        // the plan already holds this refresh (or a newer one)
    var changed=mergePace(r.roster); _planPaceAt=r.at;
    if(!changed) return;
    applyAvailToDrivers();
    /* Only a tab that holds the latest plan may save: if another admin tab already saved this
       pace, our rev is behind, the save would 409 and lose any edit in flight. The adopt that
       refreshShared is about to do re-merges and saves from the current rev instead. */
    if(isAdmin() && state.evsel===_planEvsel && _revSeen.plan===PLAN_REV && !_saveT && !_postBusy) save();
    if(!_editingNow()) renderContent();
  }).catch(function(){ _pacePulling=false; });
}
function mergePace(roster){
  if(!Array.isArray(roster)) return false;             // a failed refresh keeps the previous roster server-side; an empty one means nobody has laps here
  var byKey={}, changed=false;
  (state.drivers||[]).forEach(function(d){ byKey[nameKey(d.name)]=d; });
  var seen={};
  roster.forEach(function(r){
    if(isExcluded(r.name)) return;
    var k=nameKey(r.name), d=byKey[k]; seen[k]=1;
    var cars=r.cars||{};
    if(!d){
      var id=state.drivers.reduce(function(m,x){return Math.max(m,x.id);},0)+1;
      d={id:id, name:r.name, cars:cars, assignedCar:lastCar(cars), avail:null, irating:(typeof r.irating==='number'?r.irating:null), carLock:false};
      state.drivers.push(d); byKey[k]=d; changed=true; return;
    }
    if(JSON.stringify(d.cars||{})!==JSON.stringify(cars)){ d.cars=cars; changed=true; }
    if(!d.carLock && d.assignedCar && !cars[d.assignedCar] && Object.keys(cars).length){ d.assignedCar=lastCar(cars); changed=true; }
    if(!d.assignedCar && Object.keys(cars).length){ d.assignedCar=lastCar(cars); changed=true; }
    if(typeof r.irating==='number' && d.irating!==r.irating){ d.irating=r.irating; changed=true; }
  });
  // no laps at this event's tracks: pace from the previous event's track must not linger
  (state.drivers||[]).forEach(function(d){ if(!seen[nameKey(d.name)] && Object.keys(d.cars||{}).length){ d.cars={}; changed=true; } });
  return changed;
}
async function doImport(trackIds){
  lastTrackIds=trackIds; lastTrackEv=state.evsel; setSetupMsg('Pulling Garage 61 pace…');
  try{
    const payload=await apiPOST('import',{trackIds:trackIds});
    if(payload.code){ setSetupMsg('Error: '+(payload.message||payload.code)); return; }
    lastPayload=payload;
    applyImport(payload);
    setSetupMsg('Imported pace for '+state.drivers.length+' drivers.');
    state.tab='setup'; setActiveTab(); renderContent();
  }catch(e){ setSetupMsg('Import failed: '+e.message); }
}

let SETUP_MANUAL=false;
function renderSetup(){
  const selEv=state.evsel?calEvent(state.evsel):null;
  const evTrackIds=(selEv&&selEv.g61Tracks&&!SETUP_MANUAL)?selEv.g61Tracks:null;
  let h='<div class="edr-setup">';
  h+='<div class="importbox" style="display:flex;gap:16px;flex-wrap:wrap;align-items:flex-end">';
  if(evTrackIds){
    const tnames=evTrackIds.map(function(id){ const t=(TRACKS||[]).find(x=>x.id===id); return t?(t.name+(t.variant?' - '+t.variant:'')):('#'+id); });
    h+='<div class="ctl"><label>TRACK — from the selected event</label><div style="font-size:13px;color:#fff;padding:6px 0">'+esc(selEv.n)+': '+esc(tnames.join(' + '))+'</div><span class="meta" data-s="manualtrack" style="cursor:pointer;text-decoration:underline">use the manual track picker instead</span></div>';
  } else {
    h+='<div class="ctl"><label>TRACK (Garage 61)</label><select data-s="track">'+(Array.isArray(TRACKS)?TRACKS.map(t=>'<option value="'+t.id+'"'+(t.id===SEL_TRACK?' selected':'')+'>'+esc(t.name+(t.variant?' - '+t.variant:''))+'</option>').join(''):'<option>loading...</option>')+'</select>'
      +((selEv&&selEv.g61Tracks)?'<div><span class="meta" data-s="autotrack" style="cursor:pointer;text-decoration:underline">back to the event tracks</span></div>':'')+'</div>';
  }
  h+='<button class="btn btn-amber" data-s="import">Import / Refresh now</button>';
  /* the background job keeps this warm, so say how fresh it is — an admin importing on race
     morning needs to know whether they are looking at last night's practice or last week's */
  h+='<span class="meta" style="align-self:center;color:'+(PACE_ERR?'var(--red)':'var(--dim)')+'">'+esc(paceAgeLabel())+'</span>';
  h+='<span class="meta" style="align-self:center;max-width:360px">'+esc(setupMsg||'This is the shared team plan, saved for everyone. Pick a track (or use the event\'s tracks), then Import / Refresh to pull Garage 61 pace.')+'</span>';
  h+='</div>';
  // official iRacing session start times + race length (via the proxy)
  h+='<div class="importbox"><div class="meta" style="margin-bottom:6px;text-transform:uppercase;letter-spacing:.04em">Official iRacing session times — applied automatically when a round matches; pick below to override</div>';
  if(!selEv){ h+='<div class="meta">Select a target event on the Event tab to pull its official session start times and race length.</div>'; }
  else {
    var cur=state.evTiming&&state.evTiming[evKey(selEv)];
    var match=irMatchFor(selEv);
    h+='<div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center">';
    h+='<select data-s="irsel"><option value="">(pick the matching iRacing event)</option>'+IR_SEASONS.map(function(se,i){var sel=(match&&se===match)?' selected':''; return '<option value="'+i+'"'+sel+'>'+esc(se.name)+' · '+esc(se.track)+(se.race_min?' · '+Math.round(se.race_min/60)+'h':'')+'</option>';}).join('')+'</select>';
    h+='<button class="btn btn-amber" data-s="irapply">Apply to '+esc(selEv.n)+'</button>';
    h+='<span class="meta" data-s="irrefresh" style="cursor:pointer;text-decoration:underline">refresh</span>';
    if(!match && IR_SEASONS.length) h+='<div class="meta" style="margin-top:6px;width:100%">No iRacing round matches '+esc(selEv.n)+' yet (same week + similar race length required) — rounds usually appear close to race week. Pick one manually above, or refresh.</div>';
    h+='</div>';
    if(cur&&cur.offsets) h+='<div class="meta" style="margin-top:8px;color:var(--green)">Using official times'+(cur.src?' from "'+esc(cur.src)+'"':'')+' — '+Object.keys(cur.offsets||{}).length+' starts, '+Math.round((cur.raceMin||0)/60)+'h race. <span data-s="irclear" style="cursor:pointer;text-decoration:underline;color:var(--red)">revert to calendar</span></div>';
    if(IR_STATUS) h+='<div class="meta" style="margin-top:8px">'+esc(IR_STATUS)+'</div>';
    if(!IR_SEASONS.length && !IR_STATUS) h+='<div class="meta" style="margin-top:8px">Loading iRacing…</div>';
  }
  h+='</div>';
  h+='</div>';
  return h;
}

/* delegated handlers for setup controls */
document.getElementById('content').addEventListener('click',function(e){
  const s=e.target.dataset.s;
  if(s==='manualtrack'){ SETUP_MANUAL=true; renderContent(); }
  else if(s==='autotrack'){ SETUP_MANUAL=false; renderContent(); }
  else if(s==='import'){
    const selEv=state.evsel?calEvent(state.evsel):null;
    const evIds=(selEv&&selEv.g61Tracks&&!SETUP_MANUAL)?selEv.g61Tracks:null;
    const tEl=document.querySelector('[data-s=track]');
    const ids=evIds||(tEl?[parseInt(tEl.value,10)]:[]);
    if(ids.length) doImport(ids);
  }
  else if(s==='irrefresh'){ setSetupMsg('Refreshing iRacing…'); loadIracing().then(function(){ setSetupMsg(''); renderContent(); }); }
  else if(s==='irapply'){
    const selEv=state.evsel?calEvent(state.evsel):null; const sel=document.querySelector('[data-s=irsel]');
    if(!selEv||!sel||sel.value===''){ setSetupMsg('Pick the matching iRacing event first.'); return; }
    const se=IR_SEASONS[parseInt(sel.value,10)];
    if(se && applyIrTiming(selEv, se)){ applyEventTiming(selEv); state.stintAssign={}; state.stintWin={}; state.stintSig=''; applyAvailToDrivers(); save(); setSetupMsg('Applied official session times from "'+se.name+'".'); renderContent(); }
    else setSetupMsg('That iRacing event has no session times.');
  }
  else if(s==='irclear'){
    const selEv=state.evsel?calEvent(state.evsel):null;
    if(selEv){ state.evTiming[evKey(selEv)]={src:'calendar'};   /* tombstone: blocks auto re-apply after a deliberate revert */ applyEventTiming(selEv); state.stintAssign={}; state.stintWin={}; state.stintSig=''; applyAvailToDrivers(); save(); setSetupMsg('Reverted to calendar session times.'); renderContent(); }
  }
});

async function bootSetup(){
  try{ const lp=JSON.parse(localStorage.getItem('edrTB_local'))||{}; if(lp.role) state.role=lp.role; if(lp.me) state.me=lp.me; if(lp.pass) state.pass=lp.pass; }catch(e){}
  if(CAN) state.role='admin';
  document.getElementById('rolebar').addEventListener('click',function(e){
    const b=e.target.closest&&e.target.closest('[data-role-action]');
    if(!b) return;
    const a=b.dataset.roleAction;
    if(a==='unlock') unlockAdmin();
    else if(a==='go') submitUnlock();
    else if(a==='cancel'){ _unlockOpen=false; _unlockMsg=''; renderRolebar(); }
    else lockAdmin();
  });
  document.getElementById('rolebar').addEventListener('keydown',function(e){
    if(e.key==='Enter' && e.target.id==='adminpass') submitUnlock();
  });
  renderRolebar();
  syncControls();
  state.tab = tabFromHash() || (CAN ? 'setup' : 'instructions'); setActiveTab();
  var ok=false; try{ ok=await loadPlan(); }catch(e){}
  if(state.evsel){ var _bev=calEvent(state.evsel); if(_bev){ var _br=state.stint.race; applyEventTiming(_bev); if(_br>0) state.stint.race=_br; } }  // rebuild timing globals from the restored event (don't trust persisted globals)
  try{
    const av=await apiGET('avail');
    if(av&&av.store){ state.availStore=av.store; LOCKED_NAMES=av.locked||[]; if(av.prefs)state.prefStore=av.prefs; if(av.seen)AV_SEEN=av.seen; }
    else if(av&&typeof av==='object'&&!Array.isArray(av)) state.availStore=av;  /* pre-2.1.4 server shape */
  }catch(e){}
  try{ const tr=await apiGET('roster');
    if(tr&&tr.names){ TEAM_ROSTER=tr.names; ROSTER_IDS=tr.ids||{}; }        // 2.4.7 shape: {names, ids}
    else if(Array.isArray(tr)&&tr.length) TEAM_ROSTER=tr;                    // pre-2.4.7 cache fallback
  }catch(e){}
  applyAvailToDrivers();
  if(ok && state.drivers.length && !Object.keys(state.teams||{}).length) generate();
  renderContent();
  if(isAdmin()){
    try{ var rc=await apiGET('recap'); if(rc){ RECAP=rc.recap||null; RECAP_RUNNING=!!rc.running; RECAP_ERR=rc.error||''; RECAP_PROG=rc.progress||null; } }catch(e){}
    try{ var hh=await apiGET('history'); if(hh){ applyHistory(hh.history||null); HIST_RUNNING=!!hh.running; HIST_ERR=hh.error||''; HIST_PROG=hh.progress||null; } }catch(e){}
    try{ RATINGS=await apiGET('ratings'); }catch(e){}
    await loadStoredPost();                 // the edited write-up, if one is waiting on the server
    try{ TRACKS=await apiGET('tracks'); }catch(e){ TRACKS=[]; } if(!Array.isArray(TRACKS)) TRACKS=[];
    preselectNearest();
    /* the weekly tab is fed by all four of the admin pulls above (recap, history, ratings and
       the stored post) — landing on it via #weekly used to show the pre-pull version until
       something else forced a render */
    if(state.tab==='setup'||state.tab==='weekly') renderContent();
    loadIracing().then(function(){ autoApplyTiming(); autoApplyWeather(); if(state.tab==='setup') renderContent(); });
  }
}

/* ---- live heartbeat --------------------------------------------------------------------
   Focus-only refresh meant two people planning together saw each other's work only when they
   clicked away and back. Poll the tiny /rev endpoint instead while the tab is visible, and
   only pull the full plan/avail payload when a revision actually moved — a few bytes every
   20s per open tab, which is nothing for a 30-person squad, and edits land within ~20s.

   Nothing polls while hidden (a phone left on the page all weekend costs nothing), a focus
   fires an immediate check, and repeated failures back off so a site that is down or a laptop
   that woke up on a dead connection does not hammer it. */
var REV_POLL_MS=20000, REV_BACKOFF_MAX=180000;
var _revTimer=null, _revFail=0, _revSeen={plan:null, avail:null};
function _revTick(){
  if(document.visibilityState!=='visible') return _revArm(REV_POLL_MS);
  var q=state.evsel?('?ev='+encodeURIComponent(state.evsel)):'';
  var _pk=_paceKeyNow(); if(_pk) q+=(q?'&':'?')+'tracks='+_pk;
  fetch(API+'rev'+q,{headers:{'Accept':'application/json'}})
    .then(function(r){ if(!r.ok) throw new Error('rev '+r.status); return r.json(); })
    .then(function(j){
      _revFail=0;
      var first=(_revSeen.plan===null);
      var moved=(!first) && (j.plan!==_revSeen.plan || j.avail!==_revSeen.avail);
      _revSeen.plan=j.plan; _revSeen.avail=j.avail;
      PACE_AT=j.paceAt||0; PACE_ERR=j.paceErr||'';
      if(moved) refreshShared();       // refreshShared has its own edit-in-progress guard
      if(j.paceAt && j.paceKey && j.paceKey===_paceKeyNow() && !(_paceLast && _paceLast.key===j.paceKey && _paceLast.at>=j.paceAt)) pullPace(j.paceKey);
      _revArm(REV_POLL_MS);
    })
    .catch(function(){
      _revFail++;
      _revArm(Math.min(REV_POLL_MS*Math.pow(2,_revFail), REV_BACKOFF_MAX));
    });
}
function _revArm(ms){ clearTimeout(_revTimer); _revTimer=setTimeout(_revTick, ms); }
function _revNow(){ clearTimeout(_revTimer); _revTick(); }

// ---- boot ----
document.getElementById('edr-tb-app').dataset.ready='1';
document.addEventListener('visibilitychange', function(){ if(document.visibilityState==='visible'){ refreshShared(); _revNow(); } });
window.addEventListener('pagehide', function(){ if(_saveT){ clearTimeout(_saveT); _saveT=null; try{ fetch(API+'plan',{method:'POST',headers:_hdrs(true),body:JSON.stringify({plan:serializePlan(),baseRev:PLAN_REV}),keepalive:true}); }catch(e){} } });   // a rename made just before closing the tab must not die in the 600ms debounce
window.addEventListener('focus', function(){ refreshShared(); _revNow(); });
bootSetup();
_revArm(REV_POLL_MS);

})();
